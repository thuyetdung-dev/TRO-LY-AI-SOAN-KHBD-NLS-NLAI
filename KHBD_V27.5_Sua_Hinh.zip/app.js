/* Mốc phiên bản — hiện ngay trên thanh tiêu đề. Sau nhiều vòng sửa, đã có lần trang web
   chạy bản cũ mà cả hai bên đều tưởng là bản mới, mất công đi tìm lỗi đã sửa xong rồi.
   Nhìn dòng chữ trên đầu trang là biết ngay đang chạy bản nào. */
const APP_BUILD='2026-09-14 · b27.5';
const $=id=>document.getElementById(id);let selectedFiles=[],rawMarkdown='',availableModels=[],scanTimer,draftTimer,lastValidation=null;
const fields=['subject','grade','lesson','book','periods','students','classSize','equipment','notes','tableLayout','assessmentMode','lessonTemplate','sourceMode'];
const toast=m=>{const t=$('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)};
// Escape đủ 5 ký tự đặc biệt (bao gồm dấu nháy) để dùng an toàn cả trong nội dung text lẫn trong thuộc tính HTML (title, style, stroke...).
// Trước đây hàm này chỉ escape &,<,> nên các chỗ dùng esc() để build thuộc tính (vd aria-label, style="--c:...") có thể bị phá vỡ nếu dữ liệu AI trả về chứa dấu ".
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
$('themeBtn').onclick=()=>document.body.classList.toggle('dark');
$('showKey').onclick=()=>{const i=$('apiKey');i.type=i.type==='password'?'text':'password';$('showKey').textContent=i.type==='text'?'Ẩn':'Hiện'};
$('clearKey').onclick=()=>{$('apiKey').value='';$('apiKey').type='password';$('showKey').textContent='Hiện';scanModels(false);toast('Đã xóa khóa API khỏi ô nhập')};
function modelScore(name){const n=name.toLowerCase(),version=(n.match(/gemini-(\d+(?:\.\d+)?)/)||[])[1];let score=parseFloat(version||0)*100;if(n.includes('flash'))score+=30;if(n.includes('pro'))score+=20;if(n.includes('lite'))score-=8;if(/preview|experimental|exp/.test(n))score-=12;if(n.includes('latest'))score-=4;return score}
function usableModel(m){const n=(m.name||'').toLowerCase();return n.startsWith('models/gemini-')&&(m.supportedGenerationMethods||[]).includes('generateContent')&&!/(embedding|image|imagen|veo|tts|audio|transcribe|live|computer-use|robotics)/.test(n)}
/* Giới hạn token đầu ra khác nhau theo mô hình (Gemini 1.5 chỉ 8192; 2.x tới 65536).
   Danh sách /v1beta/models đã trả về outputTokenLimit nên ta dùng luôn thay vì đoán:
   đặt cứng một con số quá cao sẽ bị API từ chối, quá thấp thì KHBD dài bị cắt giữa chừng. */
const OUTPUT_LIMITS=new Map();
/* Một KHBD đầy đủ theo mẫu tổ chuyên môn dài khoảng 70 nghìn ký tự ≈ 25-30 nghìn token.
   Trần 32768 cũ vừa đủ chặn ngay giữa bài. Nới lên hết mức mô hình cho phép (Gemini 2.x tới 65536). */
function maxTokensFor(fullName){const lim=OUTPUT_LIMITS.get(fullName);return Math.min(lim||8192,65536)}
function setModelStatus(text,state=''){$('modelStatus').textContent=text;$('modelStatus').className=`model-status ${state}`.trim()}
async function scanModels(showToast=false){const key=$('apiKey').value.trim();if(!key){availableModels=[];$('model').innerHTML='<option value="auto">Tự động dò mô hình phù hợp (Khuyên dùng)</option>';setModelStatus('Nhập API key để hệ thống tự dò mô hình đang hoạt động.');if(showToast)toast('Vui lòng nhập Gemini API key');return []}const btn=$('scanModels'),previous=$('model').value;btn.disabled=true;setModelStatus('Đang dò các mô hình có thể tạo nội dung...');try{const res=await fetch('https://generativelanguage.googleapis.com/v1beta/models',{headers:{'x-goog-api-key':key}}),data=await res.json();if(!res.ok)throw new Error(data?.error?.message||'Không lấy được danh sách mô hình');availableModels=(data.models||[]).filter(usableModel).sort((a,b)=>modelScore(b.name)-modelScore(a.name));availableModels.forEach(m=>{if(m.outputTokenLimit)OUTPUT_LIMITS.set(m.name,Number(m.outputTokenLimit))});if(!availableModels.length)throw new Error('API key này chưa có mô hình tạo nội dung phù hợp');$('model').innerHTML='<option value="auto">Tự động chọn mô hình tốt nhất (Khuyên dùng)</option>'+availableModels.map(m=>`<option value="${esc(m.name)}">${esc(m.displayName||m.name.replace('models/',''))}</option>`).join('');if([...$('model').options].some(o=>o.value===previous))$('model').value=previous;setModelStatus(`Đã tìm thấy ${availableModels.length} mô hình · ưu tiên ${availableModels[0].name.replace('models/','')}`,'ok');if(showToast)toast(`Đã tìm thấy ${availableModels.length} mô hình đang hỗ trợ`);return availableModels}catch(err){availableModels=[];$('model').innerHTML='<option value="auto">Tự động dò khi bắt đầu soạn</option>';setModelStatus(err.message||'Không thể dò mô hình','error');if(showToast)toast(err.message||'Không thể dò mô hình');return []}finally{btn.disabled=false}}
$('scanModels').onclick=()=>scanModels(true);
$('apiKey').addEventListener('input',()=>{clearTimeout(scanTimer);scanTimer=setTimeout(()=>scanModels(false),700)});
function aiIntegrationMode(){return $('aiIntegrationMode')?.value||($('includeAI').checked?'auto':'off')}
function syncAIIntegration(){const g=clampGrade($('grade').value),mode=$('aiIntegrationMode');if(g<10){mode.value='off';mode.disabled=true;mode.title='Bảng chuẩn NLAI hiện chỉ bao phủ lớp 10–12'}else{mode.disabled=false;mode.title=''}$('includeAI').checked=mode.value!=='off'}
$('grade').addEventListener('change',syncAIIntegration);
$('aiIntegrationMode').addEventListener('change',syncAIIntegration);
syncAIIntegration();
$('sampleBtn').onclick=()=>{Object.entries({subject:'Toán',grade:'12',lesson:'Bài 2. Giá trị lớn nhất và giá trị nhỏ nhất của hàm số',book:'Kết nối tri thức với cuộc sống',periods:'3',students:'Trung bình–khá',classSize:'45',equipment:'TV 32 inch, bảng phụ, máy tính cầm tay'}).forEach(([k,v])=>$(k).value=v);toast('Đã điền dữ liệu mẫu')};
const dz=$('dropZone');['dragenter','dragover'].forEach(e=>dz.addEventListener(e,x=>{x.preventDefault();dz.classList.add('drag')}));['dragleave','drop'].forEach(e=>dz.addEventListener(e,x=>{x.preventDefault();dz.classList.remove('drag')}));dz.addEventListener('drop',e=>addFiles(e.dataTransfer.files));dz.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('files').click()}});$('files').onchange=e=>addFiles(e.target.files);
/* Gemini giới hạn khoảng 20 MB cho toàn bộ một yêu cầu gửi kèm dữ liệu nội tuyến, mà mã hóa
   base64 làm dữ liệu phình thêm 1/3. Trần 40 MB của bản cũ vượt xa giới hạn đó: giáo viên
   chọn đủ 40 MB thì yêu cầu luôn bị Google từ chối, kèm thông báo lỗi khó hiểu. */
/* Giới hạn 12 MB trước đây là do gửi tài liệu kèm thẳng trong thân yêu cầu (inline): Gemini
   chỉ nhận khoảng 20 MB cho cả yêu cầu, mà mã hoá base64 làm dữ liệu phình thêm 1/3.
   Nay dùng thêm Files API của Gemini: tệp được TẢI LÊN TRƯỚC, yêu cầu soạn bài chỉ gửi kèm
   đường dẫn, nên giới hạn 20 MB kia không còn áp dụng. Tệp nhỏ vẫn gửi inline cho nhanh
   (đỡ một vòng gọi mạng); tệp lớn tự chuyển sang Files API. */
const MAX_FILE_MB=30,MAX_TOTAL_MB=60,INLINE_LIMIT_MB=8;
function addFiles(list){for(const f of list){if(f.size>MAX_FILE_MB*1024*1024){toast(`${f.name}: vượt ${MAX_FILE_MB} MB`);continue}const total=selectedFiles.reduce((s,x)=>s+x.size,0);if(total+f.size>MAX_TOTAL_MB*1024*1024){toast(`Tổng dung lượng tài liệu không được vượt ${MAX_TOTAL_MB} MB`);break}if(!selectedFiles.some(x=>x.name===f.name&&x.size===f.size))selectedFiles.push(f)}renderFiles()}
function renderFiles(){$('fileList').innerHTML=selectedFiles.map((f,i)=>`<div class="file-chip"><b>${esc(f.name)}</b><span>${(f.size/1048576).toFixed(1)} MB</span><button type="button" data-i="${i}" aria-label="Bỏ tệp">×</button></div>`).join('');$('fileList').querySelectorAll('button').forEach(b=>b.onclick=()=>{selectedFiles.splice(+b.dataset.i,1);renderFiles()})}
function values(){return Object.fromEntries(fields.map(k=>[k,$(k).value.trim()]))}
function setProgress(p,title,text){$('emptyState').hidden=true;$('result').hidden=true;$('progress').hidden=false;$('resultActions').hidden=true;$('progressBar').style.width=p+'%';$('progressTitle').textContent=title;$('progressText').textContent=text}
function bytesToBase64(buf){let bin='',arr=new Uint8Array(buf),step=0x8000;for(let i=0;i<arr.length;i+=step)bin+=String.fromCharCode(...arr.subarray(i,i+step));return btoa(bin)}
async function filePart(file){return {inlineData:{mimeType:file.type||mime(file.name),data:bytesToBase64(await file.arrayBuffer())}}}

/* ===== Tải tệp lớn lên Gemini Files API =====
   Giao thức tải nhiều bước: xin đường dẫn tải lên, đẩy dữ liệu, rồi chờ Google xử lý xong
   (tệp PDF phải ở trạng thái ACTIVE mới dùng được, nếu gửi lúc còn PROCESSING sẽ báo lỗi). */
async function uploadToFilesApi(file,key,onProgress){
  const mimeType=file.type||mime(file.name);
  const start=await fetch('https://generativelanguage.googleapis.com/upload/v1beta/files',{
    method:'POST',
    headers:{'x-goog-api-key':key,'X-Goog-Upload-Protocol':'resumable','X-Goog-Upload-Command':'start',
      'X-Goog-Upload-Header-Content-Length':String(file.size),
      'X-Goog-Upload-Header-Content-Type':mimeType,'Content-Type':'application/json'},
    body:JSON.stringify({file:{display_name:file.name}})});
  if(!start.ok)throw new Error((await start.json().catch(()=>({})))?.error?.message||`Không xin được đường dẫn tải lên (HTTP ${start.status})`);
  const uploadUrl=start.headers.get('x-goog-upload-url')||start.headers.get('X-Goog-Upload-URL');
  /* Trình duyệt chỉ đọc được tiêu đề phản hồi khi máy chủ cho phép lộ nó ra. Nếu không đọc
     được thì không thể tải kiểu này từ trình duyệt — báo rõ để còn quay về cách gửi kèm. */
  if(!uploadUrl)throw new Error('Trình duyệt không đọc được đường dẫn tải lên do Google trả về');
  const up=await fetch(uploadUrl,{method:'POST',
    /* Content-Length là "forbidden request header" trong trình duyệt: Chrome/Edge tự đặt
       từ Blob. Tự khai báo làm một số máy chặn ngay trước khi gửi tệp. */
    headers:{'X-Goog-Upload-Offset':'0','X-Goog-Upload-Command':'upload, finalize'},
    body:file});
  if(!up.ok)throw new Error(`Tải tệp lên thất bại (HTTP ${up.status})`);
  let info=(await up.json())?.file;
  if(!info?.uri)throw new Error('Google không trả về đường dẫn tệp');
  for(let i=0;i<30&&info.state==='PROCESSING';i++){
    onProgress&&onProgress(`Google đang xử lý ${file.name}...`);
    await new Promise(r=>setTimeout(r,2000));
    const st=await fetch(`https://generativelanguage.googleapis.com/v1beta/${info.name}`,{headers:{'x-goog-api-key':key}});
    info=await st.json();
  }
  if(info.state==='FAILED')throw new Error(`Google không đọc được tệp ${file.name}`);
  return {fileData:{mimeType:info.mimeType||mimeType,fileUri:info.uri}};
}

/* Chọn cách gửi cho từng tệp. Tải lên thất bại vì bất kỳ lý do gì (kể cả trình duyệt chặn
   đọc tiêu đề) thì vẫn quay về gửi kèm trực tiếp nếu tệp đủ nhỏ, để không mất luôn tài liệu. */
async function buildFileParts(key){
  const parts=[];
  for(const f of selectedFiles){
    setProgress(25,'Đang đọc tài liệu...',f.name);
    const big=f.size>INLINE_LIMIT_MB*1024*1024;
    if(big){
      try{
        setProgress(25,'Đang tải tài liệu lên Google...',`${f.name} (${(f.size/1048576).toFixed(1)} MB)`);
        parts.push(await uploadToFilesApi(f,key,t=>setProgress(28,'Đang tải tài liệu lên Google...',t)));
        continue;
      }catch(err){
        if(f.size>15*1024*1024)throw new Error(`Không tải được ${f.name} lên Google (${err.message}). Hãy tách nhỏ tệp dưới 15 MB rồi thử lại.`);
        toast(`Không tải lên được ${f.name}, chuyển sang gửi kèm trực tiếp`);
      }
    }
    parts.push(await filePart(f));
  }
  return parts;
}
function mime(n){const e=n.split('.').pop().toLowerCase();return {pdf:'application/pdf',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',txt:'text/plain',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}[e]||'application/octet-stream'}
// Phạm vi sản phẩm: lớp 6–12. NLAI hiện chỉ có bảng chuẩn được nhúng cho lớp 10–12.
function clampGrade(g){const n=parseInt(g,10);return Number.isFinite(n)?Math.min(12,Math.max(6,n)):12}
function nlsLevelForGrade(g){g=clampGrade(g);return g<=7?3:g<=9?4:5}

// Dựng khối "NGUỒN THAM CHIẾU BẮT BUỘC" nhúng thẳng bảng mã chính thức (KHÔNG để AI tự nhớ/tự bịa).
// Đây là điểm mấu chốt để tránh rủi ro AI gán sai/gán khống mã NLS, NLAI: hai văn bản
// (QĐ 2422/QĐ-BGDĐT và TT 02/2025/TT-BGDĐT) đều rất mới, mô hình AI nhiều khả năng
// KHÔNG có sẵn dữ liệu chính xác trong lúc huấn luyện nếu không được cấp trực tiếp ở đây.
function buildStandardsBlock(v){
  const grade=clampGrade(v.grade),digital=$('includeDigital').checked,ai=aiIntegrationMode()!=='off';
  if(!digital&&!ai)return '';
  let out='\n===== NGUỒN THAM CHIẾU BẮT BUỘC (KHÔNG được suy diễn/bịa mã ngoài danh sách dưới đây) =====\n';
  if(ai&&grade>=10){
    out+=`\n[BẢNG MÃ YÊU CẦU CẦN ĐẠT NĂNG LỰC AI — NLAI — Lớp ${grade}]\n`
       +`Trích Khung nội dung giáo dục AI, kèm theo Quyết định số 2422/QĐ-BGDĐT ngày 18/8/2026 của Bộ GDĐT.\n`
       +`Quy ước mã: [Lớp].[Mã chủ đề A/B/C/D+số].[Số thứ tự] — có tiền tố "MR" là nội dung MỞ RỘNG (không bắt buộc với mọi học sinh), không có "MR" là nội dung CỐT LÕI (bắt buộc).\n`
       +(AI_YCCD[grade]||'')+'\n';
  }
  if(digital){
    out+=`\n[BẢNG MÃ NĂNG LỰC SỐ — NLS — 24 năng lực thành phần, lọc theo bậc áp dụng cho lớp ${grade}]\n`
       +`Trích nguyên văn Phụ lục — Khung năng lực số cho người học (Thông tư 02/2025/TT-BGDĐT ngày 24/01/2025 của Bộ GDĐT).\n`
       +`Định dạng mã dùng ở đây: "[Miền].[Tiểu mục]-B[Số bậc][ý]" (vd 6.3-B5a = Miền 6, tiểu mục 3, Bậc 5, ý a). Đây là quy ước tự đặt để tiện tham chiếu (Thông tư gốc chỉ gọi "Bậc 1".."Bậc 8", không có ký hiệu viết tắt chính thức) — Bậc 1-2 ứng Cơ bản, 3-4 Trung cấp, 5-6 Nâng cao, 7-8 Chuyên sâu. Mục 6 "Ứng dụng trí tuệ nhân tạo" thuộc khung NLS (TT 02/2025) — KHÁC với khung NLAI (QĐ 2422) ở trên; hai hệ mã độc lập, không gộp/nhầm lẫn định dạng.\n`
       +`Phần mềm dùng Bậc ${nlsLevelForGrade(grade)} phù hợp phạm vi triển khai của lớp ${grade}. Chỉ dùng đúng mã của bậc này; mức độ nhiệm vụ được phân hóa nhưng không tự đổi bậc.\n`
       +buildNLSText([nlsLevelForGrade(grade)])+'\n';
  }
  out+='\n===== HẾT NGUỒN THAM CHIẾU BẮT BUỘC =====\n'
     +'QUY TẮC BẮT BUỘC KHI GẮN MÃ: (a) chỉ dùng đúng nguyên văn mã có trong bảng trên, tuyệt đối không tự tạo mã mới, không mượn mã của lớp/khối khác; (b) chỉ gắn mã vào một bước khi bước đó thực sự tạo ra hành vi học sinh quan sát được, khớp với đúng mô tả của mã; nếu không có, ghi "—", không cố gắn cho đủ; (c) việc lồng ghép NLS/NLAI KHÔNG được làm thay đổi hoặc gia tăng yêu cầu cần đạt của môn học đang soạn — chỉ dùng để củng cố, vận dụng; (d) TUYỆT ĐỐI không lập cột điểm/đầu điểm riêng cho NLS hoặc NLAI trong bất kỳ phần đánh giá nào của KHBD; (e) khi dùng yêu cầu cần đạt NLAI thuộc nội dung mở rộng (có tiền tố MR), phải ghi rõ đây là nội dung mở rộng, không bắt buộc.\n';
  return out;
}

/* Bản cũ chỉ khớp chữ "toán" đứng riêng nên bỏ sót "Đại số", "Hình học", "Giải tích",
   "Toán(nâng cao)" — giáo viên dạy các phân môn này mất luôn mô-đun bảng biến thiên/đồ thị. */
function isMathSubject(v){return /toán|toan|đại\s*số|dai\s*so|hình\s*học|hinh\s*hoc|giải\s*tích|giai\s*tich|lượng\s*giác|luong\s*giac|mathematics|maths?\b/i.test(v.subject||'')}
function mathRulesFor(v){if(!isMathSubject(v))return '6) Không áp dụng mô-đun biểu diễn Toán học vì môn đang soạn không phải môn Toán.';return `6) MÔ-ĐUN RIÊNG MÔN TOÁN — bốn loại hình vẽ, viết trong khối mã có nhãn mathviz.

6a) BẢNG BIẾN THIÊN: {"type":"variation","title":"...","expr":"...","points":[...],"derivative":[...],"values":[...]}
 - "points": các mốc x theo thứ tự tăng dần, luôn bắt đầu bằng "-\\\\infty" và kết thúc bằng "+\\\\infty". Gọi số mốc là N.
 - "derivative": ĐÚNG 2N-3 phần tử, XEN KẼ theo thứ tự: dấu trên khoảng 1, giá trị tại mốc 2, dấu trên khoảng 2, giá trị tại mốc 3, ... Dấu chỉ dùng "+" hoặc "-". Tại mốc mà y'=0 ghi "0"; tại mốc hàm không xác định ghi "\\\\|".
 - "values": ĐÚNG N phần tử, một giá trị y cho mỗi mốc. BẮT BUỘC TÍNH RA SỐ CỤ THỂ tại mọi điểm cực trị — để trống là lỗi, giáo viên sẽ phải tự tính lại. Tại điểm gián đoạn dùng {"left":"-\\\\infty","right":"+\\\\infty"}.
 - CHUẨN CHÍNH XÁC: các mốc và giá trị phải giữ dạng phân số/căn thức LaTeX, ví dụ "-\\\\sqrt{\\\\frac{3}{2}}", "\\\\sqrt{\\\\frac{3}{2}}", "-\\\\frac{5}{4}". KHÔNG đổi thành số gần đúng như "-1.22", "1.22", "-1.25", trừ khi tài liệu nguồn hoặc bài toán yêu cầu làm tròn.
 - "expr": BẮT BUỘC — công thức hàm số viết theo cú pháp máy tính (dùng * cho phép nhân, ^ cho luỹ thừa), ví dụ "x^3-3*x^2+2" hoặc "(-x^2+5*x-7)/(x-2)". Phần mềm dùng trường này để VẼ LUÔN ĐỒ THỊ ngay dưới bảng biến thiên, nên thiếu nó là mất hình trực quan của cả hoạt động.
 - Ví dụ đúng cho y=x^3-3x^2+2 (N=4): points ["-\\\\infty","0","2","+\\\\infty"], derivative ["+","0","-","0","+"] (đúng 5 = 2·4-3), values ["-\\\\infty","2","-2","+\\\\infty"], expr "x^3-3*x^2+2".

6b) BẢNG XÉT DẤU: {"type":"sign","title":"...","columns":[...],"rows":[{"label":"f'(x)","cells":[...]}]}
 - "columns" là các mốc x, N mốc. "cells" của mỗi hàng có ĐÚNG 2N-3 phần tử, xen kẽ y hệt quy tắc 6a: dấu khoảng 1, giá trị tại mốc 2, dấu khoảng 2, ...
 - Ví dụ đúng: columns ["-\\\\infty","1","3","+\\\\infty"], cells ["+","0","-","0","+"].
 - Đếm sai số phần tử là bảng vẽ ra lệch cột, không dùng được.

6c) ĐỒ THỊ HÀM SỐ: {"type":"graph","title":"...","xMin":-5,"xMax":5,"yMin":-5,"yMax":5,"asymptotes":[{"type":"vertical","value":3},{"type":"horizontal","value":1},{"type":"oblique","slope":1,"intercept":4}],"functions":[{"expr":"x^3-3*x","label":"y=x^3-3x","color":"#176fa8"}]}
 - "expr" viết theo cú pháp máy tính: dùng dấu * cho phép nhân (viết "3*x" chứ không phải "3x"), dùng ^ cho luỹ thừa. Dùng được sin, cos, tan, sqrt, abs, exp, log, ln, pi.
 - Chọn xMin/xMax/yMin/yMax bao trọn các điểm cực trị và giao điểm cần quan sát.
 - "asymptotes": bắt buộc với hàm phân thức hoặc hàm có tiệm cận. Tính chính xác trước khi ghi: tiệm cận đứng dùng {"type":"vertical","value":a} cho $x=a$; tiệm cận ngang dùng {"type":"horizontal","value":b} cho $y=b$; tiệm cận xiên dùng {"type":"oblique","slope":m,"intercept":n} cho $y=mx+n$. Chỉ ghi các tiệm cận thực sự tồn tại, không đưa đồng thời ngang và xiên nếu không đúng.
 - BẮT BUỘC có ít nhất một đồ thị khi bài học có bất kỳ nội dung nào sau đây: nhận biết tính đơn điệu hoặc cực trị QUA HÌNH ẢNH ĐỒ THỊ, khảo sát và vẽ đồ thị hàm số, tương giao đồ thị, hoặc khi sách giáo khoa có hình vẽ đồ thị ở phần tương ứng. Yêu cầu cần đạt "nhận biết qua hình ảnh đồ thị" mà bản soạn không có đồ thị nào thì chưa dạy được mục tiêu đó.

6d) HÌNH KHỐI KHÔNG GIAN: {"type":"solid","title":"Hình lập phương ABCD.A'B'C'D'","shape":"hinh-lap-phuong","points":[{"name":"M","between":["B","C"],"ratio":0.5}],"vectors":[{"from":"A","to":"B"}],"segments":[{"from":"A","to":"C'"}],"planes":[["A","B","C","D"]]}
 - "shape" chọn một trong: "hinh-hop" (dùng luôn cho hình lập phương, hình hộp chữ nhật, lăng trụ tứ giác — đỉnh A, B, C, D, A', B', C', D'), "tu-dien" (đỉnh A, B, C, D), "hinh-chop-tu-giac" (S.ABCD), "hinh-chop-tam-giac" (S.ABC), "lang-tru-tam-giac" (ABC.A'B'C').
 - "points": điểm phụ nằm TRÊN một cạnh, ratio 0.5 là trung điểm. "vectors": mũi tên vectơ, CHỈ CẦN "from" và "to" — KHÔNG ghi thêm nhãn tên vectơ lên hình, vì tên đỉnh đã có sẵn nên ghi thêm chỉ làm hình rối. "segments": đoạn thẳng phụ như đường chéo. "planes": mặt cần tô nền để làm nổi mặt phẳng đang xét.
 - Phần mềm TỰ TÍNH nét khuất cho cả cạnh, vectơ lẫn đoạn phụ, tự đặt tên đỉnh và tự chọn góc nhìn — chỉ cần khai đúng tên đỉnh có sẵn của khối, không cần mô tả gì thêm.
 - BẮT BUỘC: hoạt động nào dựa trên một hình vẽ của sách giáo khoa (câu chữ kiểu "quan sát Hình 2.2", "cho hình lập phương ABCD.A'B'C'D'", "cho tứ diện ABCD", "cho hình chóp S.ABCD") thì PHẢI kèm một khối mathviz "solid" đặt ngay dưới đoạn dẫn. Học sinh và giáo viên không thể làm việc với một hình chỉ được tả bằng lời.

QUY TẮC CHUNG: mỗi khối mathviz đặt ngay dưới dòng văn bản dẫn vào nó. Chỉ dùng khi đúng nội dung bài, không ép dùng cho mọi bài Toán. Nhưng với bài về tính đơn điệu, cực trị hay khảo sát hàm số thì bảng biến thiên và đồ thị là bắt buộc; với bài hình học không gian thì mỗi hoạt động dựa trên hình của sách phải có hình khối kèm theo. Không được thay hình bằng lời mô tả suông.`}
function promptFor(v){const grade=clampGrade(v.grade);return `Bạn là chuyên gia hàng đầu về xây dựng Kế hoạch bài dạy tại Việt Nam. Hãy soạn KHBD năm học 2026–2027, tuyệt đối dựa trên tài liệu nguồn nếu có.
THÔNG TIN: Môn ${v.subject}; lớp ${grade}; bài ${v.lesson}; bộ sách ${v.book}; số tiết ${v.periods||'hãy xác định từ SGV/tài liệu'}; học sinh ${v.students}; sĩ số ${v.classSize}; thiết bị ${v.equipment}. Ghi chú: ${v.notes||'không'}.
YÊU CẦU BẮT BUỘC:
1) Ghi rõ căn cứ xác định số tiết; nếu nguồn thiếu thì ghi “đề xuất” và không bịa trang sách.
2) Bám sát ĐÚNG khung dưới đây — không tự đổi tên đề mục, không bỏ mục nào, không gộp mục. Bốn kiểu hoạt động (Khởi động, Hình thành kiến thức mới, Luyện tập, Vận dụng) là bắt buộc; riêng số lượng "Hoạt động 1, 2, 3..." bên trong mục Hình thành kiến thức mới do nội dung bài quyết định. Mọi hoạt động đều phải có đủ bốn phần a) Mục tiêu, b) Nội dung, c) Sản phẩm, d) Tổ chức thực hiện. Tiến trình phải CHIA THEO TỪNG TIẾT bằng các dòng "TIẾT 1: ...", "TIẾT 2: ..." cho đủ số tiết được giao:
${KHBD_TEMPLATE_5512}
3) Mục d) Tổ chức thực hiện của các "Hoạt động 1, 2, 3..." thuộc phần HÌNH THÀNH KIẾN THỨC MỚI phải xuất một khối mã lessonflow chứa JSON hợp lệ, đúng 4 rows, tuyệt đối không dùng bảng Markdown. Riêng HOẠT ĐỘNG KHỞI ĐỘNG, HOẠT ĐỘNG LUYỆN TẬP và HOẠT ĐỘNG VẬN DỤNG thì viết bốn bước theo văn xuôi, mỗi bước là một đề mục in đậm, KHÔNG dùng lessonflow — đúng như giáo án mẫu của tổ chuyên môn. Mỗi row dùng schema: {"step":"Bước 1: Chuyển giao nhiệm vụ","duration":3,"goalIds":["MT1"],"teacherActions":["GV ..."],"studentActions":["HS ..."],"product":["SP1: <VIẾT RA nội dung kiến thức hoặc lời giải đầy đủ>"],"assessment":["TC1: tiêu chí và cách thu thập minh chứng"],"competency":["Mã: hành vi quan sát được"],"sourceTag":"Theo nguồn: <tên tệp và mục cụ thể>" hoặc "AI đề xuất"} (nhãn phải bắt đầu đúng bằng chữ "Theo nguồn:" hoặc "AI đề xuất"). Tên bốn bước phải đúng nguyên văn: "Bước 1: Chuyển giao nhiệm vụ", "Bước 2: Thực hiện nhiệm vụ", "Bước 3: Báo cáo, thảo luận", "Bước 4: Kết luận, nhận định". TRƯỜNG "product" LÀ CHỖ QUAN TRỌNG NHẤT CỦA CẢ BẢN KẾ HOẠCH: nó phải chứa nội dung kiến thức chính xác, diễn đạt phù hợp để dạy học — định nghĩa, định lí, kết luận, chú ý và lời giải chi tiết từng bước của mọi hoạt động/ví dụ/luyện tập được nhắc tới; không sao chép kéo dài tài liệu nguồn. Mỗi phần tử bắt đầu bằng mã SP1, SP2... rồi mới đến nội dung. Dừng ở "SP1: Kết luận về tính đơn điệu" là SAI; phải viết hẳn: "SP1: Cho hàm số $y=f(x)$ có đạo hàm trên khoảng $K$. Nếu $f'(x)>0$ với mọi $x \\in K$ thì hàm số đồng biến trên $K$; nếu $f'(x)<0$ với mọi $x \\in K$ thì hàm số nghịch biến trên $K$." Phần tử product của bước 3 và bước 4 thường dài vài câu trở lên. Giáo viên phải có đủ dữ liệu để triển khai hoạt động, đồng thời vẫn đối chiếu nguồn trước khi dạy. Khối đầy đủ có dạng {"type":"lessonflow","rows":[...]}. duration là số phút nguyên dương; goalIds chỉ được dùng mã mục tiêu đã khai báo; sản phẩm phải có mã SP; tiêu chí phải có mã TC. Mỗi công thức trong JSON đặt giữa $...$ và gạch chéo ngược LaTeX viết thành hai gạch chéo ngược để JSON hợp lệ.
Bảng phải tách rõ việc GV làm và HS làm, thể hiện câu hỏi/nhiệm vụ, cách tổ chức, thời lượng, phân hoá cho ${v.students}, phù hợp ${v.classSize} HS và thiết bị ${v.equipment}. Sản phẩm dự kiến phải đặt song song với từng bước, có nội dung/đáp án/kiến thức chốt cụ thể. assessment phải nêu phương pháp/công cụ, minh chứng và tiêu chí quan sát được. competency chỉ gắn khi có hành vi quan sát được; nếu không phát sinh ghi "—".
${buildStandardsBlock(v)}
4) ${$('includeDigital').checked?'Đề xuất NLS ở Bậc '+nlsLevelForGrade(grade)+' chỉ khi có hành vi số quan sát được; nếu không phù hợp ghi “—”.':'Không tích hợp NLS.'} ${aiIntegrationMode()==='required'&&grade>=10?'BẮT BUỘC thiết kế ít nhất một hoạt động trong đó học sinh sử dụng, kiểm chứng hoặc phản biện AI; gắn mã NLAI đúng lớp '+grade+'.':aiIntegrationMode()==='auto'&&grade>=10?'Chỉ đề xuất NLAI khi hoạt động thực sự phù hợp. Nếu không phù hợp, ghi “Không đề xuất tích hợp NLAI cho bài này” và không gắn mã hình thức.':'Không tích hợp NLAI'+(grade<10?' vì phần mềm chưa có bảng NLAI chuẩn cho lớp này.':'.')}
5) Mọi công thức nội dòng bắt buộc đặt giữa $...$; công thức riêng dòng đặt giữa $$...$$. Tuyệt đối không in lệnh LaTeX trần như \\frac, \\sqrt, \\lim ngoài dấu phân cách. QUAN TRỌNG — lỗi hay gặp cần tránh: bên trong $...$/$$...$$ PHẢI giữ nguyên dấu gạch chéo ngược "\" của mọi lệnh LaTeX (vec, in, mathbb, cdot, perp, Leftrightarrow, frac, widehat, overrightarrow...) ở TẤT CẢ các phần của tài liệu, kể cả các gạch đầu dòng văn xuôi ở mục a) Mục tiêu/b) Nội dung/c) Sản phẩm (không chỉ bên trong khối lessonflow). Viết ĐÚNG: "$\\vec{a} = k\\vec{b}$ ($k \\in \\mathbb{R}$, $\\vec{b} \\neq \\vec{0}$)"; "$\\widehat{AOB}$"; "$\\vec{IA}+\\vec{IB}+\\vec{IC}+\\vec{ID}=\\vec{0}$". KHÔNG được viết thành "$veca = kvecb$ ($k in mathbbR$)" hay "$vecIA+vecIB=vec0$" (thiếu dấu \\ sẽ làm hỏng công thức khi hiển thị).
${mathRulesFor(v)}
7) ĐÁNH MÃ VÀ LIÊN KẾT: Mọi mục tiêu dùng mã MT1, MT2... và động từ quan sát được. Mọi sản phẩm dùng SP1, SP2...; mọi tiêu chí dùng TC1, TC2... Sau phần Mục tiêu, tạo bảng Markdown "MA TRẬN LIÊN KẾT MỤC TIÊU – HOẠT ĐỘNG – SẢN PHẨM – ĐÁNH GIÁ" gồm 4 cột: Mục tiêu | Hoạt động | Sản phẩm | Tiêu chí/công cụ. Không để mục tiêu nào thiếu hoạt động, sản phẩm hoặc tiêu chí tương ứng.
8) THỜI LƯỢNG: Mỗi row lessonflow có duration. Ngay dưới tiêu đề của MỌI hoạt động viết văn xuôi (Khởi động, Luyện tập, Vận dụng, kiểm tra đầu giờ...) phải có một dòng riêng “(Thời lượng: N phút)”. Mỗi tiết 45 phút; tiến trình phải chia đủ số dòng "TIẾT n:" bằng đúng số tiết được giao và tổng các duration lessonflow cộng với thời lượng hoạt động văn xuôi trong từng TIẾT phải đúng 45 phút, không chỉ đúng tổng toàn bài. Tổng thời lượng toàn bài phải đúng ${v.periods?Number(v.periods)*45:'số tiết đề xuất × 45'} phút; cuối Tiến trình ghi "Tổng thời lượng: ... phút". Nếu giao vận dụng ngoài giờ, duration ghi thời gian giao nhiệm vụ trên lớp, không cộng thời gian HS làm ở nhà.
9) CÔNG CỤ ĐÁNH GIÁ: ${v.assessmentMode==='day-du'?'Cuối KHBD tạo phụ lục công cụ đánh giá phù hợp (bảng kiểm hoặc rubric), có tiêu chí TC, 3 mức Chưa đạt/Đạt/Tốt và minh chứng; không tạo đầu điểm riêng cho NLS/NLAI.':v.assessmentMode==='co-ban'?'Trong từng bước nêu câu hỏi/cách đánh giá, đáp án hoặc tiêu chí cơ bản; không cần phụ lục rubric.':'Không tạo phụ lục đánh giá riêng, nhưng vẫn phải có assessment trong từng bước.'}
10) DẤU VẾT NGUỒN: ${v.sourceMode==='strict'?'KHÓA NGUỒN TUYỆT ĐỐI: chỉ sử dụng thông tin có trong tài liệu đính kèm/nội dung bổ sung; không tự thêm yêu cầu cần đạt, số tiết, kiến thức, bài tập hoặc dữ kiện. Phần không xác định được phải ghi “Chưa đủ dữ liệu nguồn – giáo viên bổ sung”, tuyệt đối không suy diễn.':$('traceSources').checked?'Trong sourceTag và các dữ kiện quan trọng, ghi “Theo nguồn: tên tệp/mục” nếu thật sự có trong tài liệu; phần do AI bổ sung phải ghi “AI đề xuất”. Không được gắn nhãn “Theo nguồn” nếu không xác định được tài liệu.':'Không bắt buộc gắn nhãn nguồn trong từng nội dung.'} Cuối bài tạo mục “DẤU VẾT NGUỒN VÀ TRÁCH NHIỆM GIẢI TRÌNH”. Chỉ mô tả phạm vi tài liệu đã dùng; không được tuyên bố “trích dẫn chính xác nguyên văn”, “đối chiếu tuyệt đối” hoặc khẳng định đã kiểm chứng từng trang khi hệ thống chưa có bằng chứng đối chiếu đoạn-với-đoạn.
10.1) MẪU CHUYÊN MÔN: ${v.lessonTemplate==='math'?'Ưu tiên lập luận, biểu diễn toán học, bài tập phân hóa và kiểm tra đáp án.':v.lessonTemplate==='science'?'Ưu tiên tiến trình khám phá/thí nghiệm, an toàn, quan sát và xử lí dữ liệu.':v.lessonTemplate==='language'?'Ưu tiên đọc–viết–nói–nghe, ngữ liệu, giao tiếp và sản phẩm ngôn ngữ.':v.lessonTemplate==='project'?'Ưu tiên vấn đề thực tiễn, thiết kế, chế tạo, thử nghiệm, cải tiến và rubric sản phẩm.':'Tự chọn phương pháp đặc thù phù hợp môn học; không áp dụng máy móc mẫu của môn khác.'}
11) TRÍCH DẪN SÁCH: chỉ được ghi số trang, số hiệu bài tập, số hiệu hoạt động (HĐ1, Ví dụ 2, Luyện tập 3, Bài 1.5...) khi con số đó THỰC SỰ NHÌN THẤY trong tài liệu đính kèm. Nếu không đọc được số trang trong tài liệu, ghi "SGK — bài <tên bài>" và KHÔNG kèm số trang. Bịa số trang là lỗi nghiêm trọng vì giáo viên sẽ mở sách theo chỉ dẫn đó trước mặt học sinh.
12) ĐỘ DÀI: một kế hoạch bài dạy đạt yêu cầu cho ${v.periods||"số tiết đề xuất"} tiết thường dài hàng chục nghìn ký tự vì phải chép đủ kiến thức và lời giải. Không rút gọn, không viết tắt nội dung bằng nhãn, không dùng dấu ba chấm để lược bỏ. Nếu buộc phải chọn giữa ngắn gọn và đầy đủ nội dung dạy học, luôn chọn đầy đủ.
12.1) ĐÁNH MÃ LIÊN TỤC CHO CẢ BÀI: MT và SP đánh số một mạch từ đầu đến cuối kế hoạch. TUYỆT ĐỐI KHÔNG bắt đầu lại từ SP1 ở mỗi hoạt động — nếu SP1 xuất hiện ở hai hoạt động với hai nội dung khác nhau thì ma trận liên kết đầu bài không còn truy được về đâu. Riêng mã TIÊU CHÍ thì được phép dùng lại: một tiêu chí đánh giá như "TC2: quan sát thái độ hợp tác nhóm" hoàn toàn có thể dùng cho nhiều hoạt động, chỉ cần mỗi mã TC luôn ứng với ĐÚNG MỘT nội dung tiêu chí trong cả bài; đừng lấy cùng một mã TC đặt cho hai tiêu chí khác nhau.
12.2) CỘT NLS/NLAI (trường competency) CHỈ được ghi mã năng lực số dạng 1.1-B5b hoặc mã năng lực AI dạng 12.A1.3, kèm hành vi quan sát được; nếu hoạt động không phát sinh hành vi số thì ghi đúng một dấu "—". TUYỆT ĐỐI KHÔNG ghi năng lực đặc thù môn học ("Tư duy và lập luận toán học", "Giao tiếp toán học", "Mô hình hoá toán học"...) vào cột này — những năng lực đó thuộc mục I. Mục tiêu. Mọi mã NLS đã nêu ở mục Mục tiêu đều phải xuất hiện lại ở ít nhất một bước trong tiến trình, nếu không thì đừng nêu.
12.3) MỤC NĂNG LỰC AI: tuân thủ đúng chế độ ở yêu cầu 4; không tự gắn mã NLAI chỉ để đủ hình thức.
12.4) KÝ HIỆU TẬP HỢP VÀ KHOẢNG — đây là chỗ hay sai nhất, đã có bản in ra giấy bị lỗi:
 - Tập xác định viết $D = \\mathbb{R} \\setminus \\{2\\}$ (có dấu gạch chéo ngược ở cả \\setminus lẫn hai ngoặc nhọn). KHÔNG viết R\\{2\\}, không viết mathbbR.
 - Khoảng vô hạn viết $(-\\infty; 0)$ và $(2; +\\infty)$ — nhớ giữ dấu gạch chéo ngược của \\infty ngay cả khi sau nó là dấu chấm phẩy.
 - Căn bậc ba viết $\\sqrt[3]{x}$; hàm mũ viết $e^{-t}$ với mũ đặt trong ngoặc nhọn.
12.6) Nếu chế độ ở yêu cầu 4 là BẮT BUỘC, mục "Năng lực AI (NLAI)" phải nêu ít nhất một mã theo Quyết định 2422 kèm hành vi quan sát được và gắn mã đó vào ít nhất một bước. Nếu là ĐỀ XUẤT KHI PHÙ HỢP, được phép không dùng mã nhưng phải nêu ngắn gọn lý do sư phạm.
12.7) BẢNG BIẾN THIÊN: trường points và values ghi bằng LaTeX bình thường ($\\dfrac{3-\\sqrt3}{3}$), phần mềm tự tính ra số để dựng đồ thị. Trường expr phải là biểu thức thuần, KHÔNG có dấu nhân "*" và không có "y=" ở đầu.
12.5) MỌI CÔNG THỨC PHẢI CÂN ĐỐI DẤU NGOẶC. Trước khi trả lời, tự rà lại từng cặp $...$: số dấu "(" phải bằng số dấu ")", "{" bằng "}", "[" bằng "]". Một công thức thiếu dấu đóng là một dòng vô nghĩa trên bản in mà giáo viên phải sửa tay.
13) Câu hỏi phải chính xác; tự giải và kiểm tra đáp án hai lần. Không sao chép máy móc giáo án tham khảo; không bịa dữ kiện từ nguồn. Đầu ra bằng Markdown, không mở đầu xã giao, phong cách ${$('style').value}.`}
const MAX_MODEL_ATTEMPTS=3; // Giới hạn số mô hình thử tuần tự, tránh giáo viên phải chờ hàng chục phút nếu key có nhiều model nhưng đều lỗi.

/* ===== Gọi Gemini theo lối truyền dòng (viết lại ở b16) =====

   MÂU THUẪN CỦA BẢN b15: prompt bắt mô hình viết "hàng chục nghìn ký tự" và hạn mức
   token đã nới tới 65536 (≈ 25–30 nghìn token), trong khi lượt gọi lại dùng
   :generateContent — phải chờ VIẾT XONG TOÀN BỘ mới trả về — và flow.js cắt ngang ở
   đúng 120 giây. Một bài dài như thế thường mất 2–5 phút. Nghĩa là ở chính cấu hình mà
   phần mềm tự đặt ra, lỗi "AI phản hồi quá 120 giây" là chuyện THƯỜNG TRỰC dù mọi thứ
   đều đang chạy đúng.

   NAY: dùng :streamGenerateContent?alt=sse. Nội dung về tới đâu nhận tới đó, nên:
   - Đồng hồ đếm ngược được đặt lại mỗi lần có dữ liệu mới. Chỉ ngắt khi mô hình IM LẶNG
     quá lâu — tức là hỏng thật — chứ không ngắt vì bài dài.
   - Giáo viên nhìn thấy số ký tự tăng dần, biết máy đang chạy chứ không treo.
   Bản vá fetch trong flow.js bắt theo chuỗi ':generateContent' nên không chạm vào
   ':streamGenerateContent' — hai cơ chế không giẫm chân nhau.

   Vẫn giữ đường không truyền dòng làm dự phòng cho trình duyệt không đọc được luồng. */
const STREAM_IDLE_MS=90000;   // im lặng quá 90 giây mới coi là hỏng
const STREAM_TOTAL_MS=600000; // trần tuyệt đối 10 phút cho một lượt
/* Đường dự phòng không truyền dòng vẫn đi qua bản vá fetch của flow.js. Trần 120 giây cũ
   quá chật cho một KHBD dài, nên nới đúng bằng trần của đường truyền dòng. */
window.AI_TIMEOUT_MS=STREAM_TOTAL_MS;

/* Token suy nghĩ của Gemini 2.5 trở lên ĐƯỢC TÍNH VÀO maxOutputTokens. Không đặt trần thì
   mô hình có thể tiêu một phần lớn hạn mức vào suy nghĩ rồi bị cắt giữa bài, báo MAX_TOKENS,
   và thông báo lỗi lại khuyên giáo viên "giảm số tiết" — quy sai nguyên nhân. Mô hình đời
   cũ không biết trường này nên chỉ gửi khi tên mô hình cho thấy có suy luận, và nếu vẫn bị
   từ chối thì thử lại đúng mô hình đó mà bỏ trường đi. */
function thinkingFor(model){return /gemini-(?:2\.5|[3-9])/i.test(model)?{thinkingBudget:4096}:null}

/* ===== b26: XIN AI VIẾT TIẾP KHI BÀI BỊ CẮT =====
   VÌ SAO: trước đây gặp MAX_TOKENS là phần mềm báo lỗi và bắt soạn lại từ đầu — bỏ đi toàn bộ
   phần đã viết, tốn thêm vài phút chờ và vẫn có thể bị cắt y hệt. Bài 6 tiết của môn Toán gần
   như chắc chắn vượt hạn mức một lượt. Nay phần mềm giữ phần đã có rồi xin mô hình viết tiếp,
   giống hệt cách người ta bảo "viết tiếp đi" thay vì "viết lại từ đầu".
   Hai hàm dưới đây cố ý viết THUẦN (không đụng mạng, không đụng DOM) để kiểm thử được ngoài
   trình duyệt — phần gọi API thì môi trường kiểm thử không có fetch nên không chạm tới được. */
const MAX_VIET_TIEP=3;
/* Gemini đôi khi trả finishReason=STOP dù văn bản mới chỉ có phần đầu. Không thể chỉ tin
   finishReason; phải nhìn cấu trúc KHBD trước khi coi là hoàn chỉnh. */
function planLooksComplete(text){
  const s=String(text||''),p=deaccent(s);
  if(s.length<4000||!balancedFences(s))return false;
  return /iii\. tien trinh day hoc/.test(p)
    &&/huong dan ve nha/.test(p)
    &&/dieu chinh sau bai day/.test(p)
    &&/dau vet nguon va trach nhiem giai trinh/.test(p);
}
function promptVietTiep(){
  return `Phần kế hoạch bài dạy ở trên bị DỪNG GIỮA CHỪNG, KHÔNG phải vì đã viết xong. Hãy VIẾT TIẾP, nối liền mạch từ đúng ký tự cuối cùng.
- TUYỆT ĐỐI KHÔNG chào hỏi, không xin lỗi, không tóm tắt, không mở đầu lại, không lặp lại bất kỳ phần nào đã viết.
- Bắt đầu ngay bằng ký tự tiếp theo của văn bản. Nếu đang viết dở một khối mã lessonflow hay mathviz thì viết tiếp đúng cú pháp JSON rồi đóng khối lại cho hợp lệ.
- Viết cho tới HẾT bài, không được bỏ sót các mục cuối: HOẠT ĐỘNG LUYỆN TẬP, HOẠT ĐỘNG VẬN DỤNG, HƯỚNG DẪN VỀ NHÀ, ĐIỀU CHỈNH SAU BÀI DẠY, PHỤ LỤC CÔNG CỤ ĐÁNH GIÁ và DẤU VẾT NGUỒN VÀ TRÁCH NHIỆM GIẢI TRÌNH.
- Giữ nguyên mọi quy tắc đã dặn ở đầu: mã MT/SP/TC đánh tiếp chứ không đánh lại từ 1, công thức đặt trong $...$, gạch chéo ngược LaTeX viết thành hai gạch trong JSON.`;
}
/* Nối phần viết tiếp vào phần đã có, cắt bỏ chỗ mô hình chép lại.
   VÌ SAO cần cắt: dù đã dặn "đừng lặp lại", mô hình vẫn hay chép lại vài dòng cuối cho liền
   mạch, có khi chép lại cả một đoạn dài. Nối thẳng thì bản kế hoạch có đoạn lặp — lỗi này khó
   thấy hơn cả việc bị cắt, vì bản in trông vẫn đầy đủ. */
function noiTiepVanBan(daCo,moi){
  const a=String(daCo??''),b=String(moi??'');
  if(!a)return b;
  if(!b.trim())return a;
  /* 1. Phần mới mở đầu đúng bằng đoạn đuôi của phần cũ — trường hợp thường gặp nhất.
        Ngưỡng 20 ký tự thì bỏ sót ca mô hình chỉ chép lại vài chữ ("...của hàm" + "hàm số trên
        khoảng K"), nên hạ xuống 6 NHƯNG bắt buộc đoạn chồng phải chứa khoảng trắng, tức từ hai
        chữ trở lên. Một chữ đơn lẻ trùng nhau là chuyện ngẫu nhiên rất dễ gặp, cắt theo nó sẽ
        ăn mất chữ thật của bài. */
  const tran=Math.min(1200,a.length,b.length);
  for(let n=tran;n>=6;n--){
    const duoi=a.slice(-n);
    if((n>=20||/\s/.test(duoi))&&b.startsWith(duoi))return a+b.slice(n);
  }
  /* 2. Mô hình chép lại một đoạn rồi mới viết tiếp: tìm đuôi phần cũ nằm ĐÂU ĐÓ trong phần mới.
        Dò đuôi dài trước rồi ngắn dần, để bắt được điểm nối xa nhất mà vẫn chắc chắn. */
  const dau=b.slice(0,8000);
  for(let n=Math.min(400,a.length);n>=60;n-=20){
    const duoi=a.slice(-n),vt=dau.indexOf(duoi);
    if(vt>=0)return a+b.slice(vt+duoi.length);
  }
  /* 3. Không tìm được chỗ chồng lấn thì NỐI THẲNG, tuyệt đối không chèn thêm ký tự nào.
        VÌ SAO: bản đầu tự chèn một dấu xuống dòng cho "gọn", nhưng phần bị cắt thường đứt ngay
        GIỮA MỘT TỪ ("...đồng bie" + "n trên R") — chèn vào là vỡ chữ. Thiếu một khoảng trắng
        thì mắt thường còn đọc được, chứ vỡ chữ thì hỏng hẳn. */
  return a+b;
}

function requestBody(fullName,model,parts,withThinking,truoc){
  const cfg={temperature:.25,maxOutputTokens:maxTokensFor(fullName)};
  const th=withThinking?thinkingFor(model):null;
  if(th)cfg.thinkingConfig=th;
  /* b26: "truoc" là các lượt đã trao đổi (phần AI đã viết + lệnh viết tiếp). Gửi kèm thì mô
     hình thấy đúng chỗ nó dừng, không phải đoán. Rỗng thì đây là lượt soạn đầu tiên. */
  const contents=[{role:'user',parts},...(Array.isArray(truoc)?truoc:[])];
  return JSON.stringify({contents,generationConfig:cfg});
}

/* Đọc luồng SSE. Trả về {text, finish}. */
async function readSSE(res,onGrow){
  const reader=res.body.getReader(),dec=new TextDecoder();
  let buf='',text='',finish='';
  for(;;){
    const {done,value}=await reader.read();
    if(done)break;
    onGrow&&onGrow(0);
    buf+=dec.decode(value,{stream:true});
    let nl;
    while((nl=buf.indexOf('\n'))>=0){
      const line=buf.slice(0,nl).trim();buf=buf.slice(nl+1);
      if(!line.startsWith('data:'))continue;
      const payload=line.slice(5).trim();
      if(!payload||payload==='[DONE]')continue;
      let obj;try{obj=JSON.parse(payload)}catch(_){continue}
      if(obj.error)throw new Error(obj.error.message||'Google trả về lỗi giữa luồng');
      const c=obj.candidates?.[0];
      if(c?.finishReason)finish=c.finishReason;
      /* Bỏ các phần "thought": đó là ghi chép suy luận của mô hình, không phải giáo án. */
      const t=(c?.content?.parts||[]).filter(x=>!x.thought).map(x=>x.text||'').join('');
      if(t){text+=t;onGrow&&onGrow(text.length)}
    }
  }
  return {text,finish};
}

async function generateOnce(fullName,model,parts,key,withThinking,onGrow,truoc){
  const ctrl=new AbortController();
  let idle=null;
  const hard=setTimeout(()=>ctrl.abort(),STREAM_TOTAL_MS);
  const arm=()=>{clearTimeout(idle);idle=setTimeout(()=>ctrl.abort(),STREAM_IDLE_MS)};
  arm();
  try{
    const base=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}`;
    const res=await fetch(`${base}:streamGenerateContent?alt=sse`,{
      method:'POST',signal:ctrl.signal,
      headers:{'Content-Type':'application/json','x-goog-api-key':key},
      body:requestBody(fullName,model,parts,withThinking,truoc)});
    if(!res.ok){
      const data=await res.json().catch(()=>({}));
      const e=new Error(data?.error?.message||`Lỗi HTTP ${res.status}`);e.status=res.status;throw e;
    }
    if(!res.body||typeof res.body.getReader!=='function'){
      /* Trình duyệt không đọc được luồng: quay về cách cũ, vẫn có ích hơn là báo hỏng. */
      const r2=await fetch(`${base}:generateContent`,{method:'POST',signal:ctrl.signal,
        headers:{'Content-Type':'application/json','x-goog-api-key':key},
        body:requestBody(fullName,model,parts,withThinking,truoc)});
      const d2=await r2.json();
      if(!r2.ok){const e=new Error(d2?.error?.message||`Lỗi HTTP ${r2.status}`);e.status=r2.status;throw e}
      const c=d2.candidates?.[0];
      return {text:(c?.content?.parts||[]).filter(x=>!x.thought).map(x=>x.text||'').join('\n'),
              finish:c?.finishReason||''};
    }
    return await readSSE(res,n=>{arm();if(n)onGrow&&onGrow(n)});
  }catch(err){
    if(err.name==='AbortError')
      throw new Error(`AI ngừng phản hồi quá ${Math.round(STREAM_IDLE_MS/1000)} giây. Hãy bớt tài liệu đính kèm, giảm số tiết hoặc chọn mô hình khác ở mục nâng cao.`);
    if(err instanceof TypeError)throw new Error('Không kết nối được tới Google. Kiểm tra Internet rồi thử lại.');
    throw err;
  }finally{clearTimeout(idle);clearTimeout(hard)}
}

/* 429 là hết hạn ngạch, 500/503 là Google quá tải — cả hai đều là trạng thái NHẤT THỜI.
   Bản b15 gặp hai lỗi này liền chuyển sang mô hình dự phòng, nhưng các mô hình dùng CHUNG
   một hạn ngạch nên cũng 429 nốt, rồi báo một thông báo gộp khó hiểu. Chờ rồi thử lại
   đúng mô hình đó có ích hơn nhiều, nhất là với khoá miễn phí. */
const RETRY_DELAYS=[4000,12000];
const wait=ms=>new Promise(r=>setTimeout(r,ms));

async function callGemini(v,key){
  const parts=[{text:promptFor(v)},...(await buildFileParts(key))];
  if(!availableModels.length)await scanModels(false);
  const selected=$('model').value;
  const allCandidates=selected!=='auto'
    ?[selected,...availableModels.map(m=>m.name).filter(n=>n!==selected)]
    :availableModels.map(m=>m.name);
  if(!allCandidates.length)throw new Error('Không tìm thấy mô hình Gemini đang hoạt động cho API key này');
  const candidates=allCandidates.slice(0,MAX_MODEL_ATTEMPTS),skipped=allCandidates.length-candidates.length;
  const errors=[];
  for(let i=0;i<candidates.length;i++){
    const fullName=candidates[i],model=fullName.replace(/^models\//,'');
    setProgress(48+Math.min(i,4)*5,'Đang soạn bài...',`Mô hình ${model}${i?` (dự phòng ${i}/${candidates.length-1})`:''}`);
    let withThinking=true;
    for(let attempt=0;attempt<=RETRY_DELAYS.length;attempt++){
      try{
        const onGrow=n=>setProgress(Math.min(92,55+Math.floor(n/1200)),'Đang soạn bài...',
          `${model} · đã nhận ${n.toLocaleString('vi-VN')} ký tự`);
        let {text,finish}=await generateOnce(fullName,model,parts,key,withThinking,onGrow);
        if(!text)throw new Error('Mô hình không trả về nội dung');
        /* b26 — BỊ CẮT THÌ XIN VIẾT TIẾP, KHÔNG BẮT SOẠN LẠI.
           MAX_TOKENS nghĩa là mô hình đã viết hết hạn mức một lượt chứ không phải mô hình lỗi;
           đổi sang mô hình dự phòng cũng bị cắt y hệt. Trước đây phần mềm báo lỗi và vứt bỏ toàn
           bộ phần đã viết — với bài 5–6 tiết môn Toán thì gần như lần nào cũng vậy. Nay giữ phần
           đã có rồi gửi tiếp một lượt "viết tiếp từ chỗ đang dừng", tối đa 3 lượt. */
        let luot=0;
        while(!['SAFETY','RECITATION','BLOCKLIST','PROHIBITED_CONTENT','SPII'].includes(finish)
          &&(finish==='MAX_TOKENS'||!planLooksComplete(text))&&luot<MAX_VIET_TIEP){
          luot++;
          setProgress(Math.min(94,80+luot*4),'Bài dài, đang xin AI viết tiếp...',
            `${model} · lượt viết tiếp ${luot}/${MAX_VIET_TIEP} · đã có ${text.length.toLocaleString('vi-VN')} ký tự`);
          const truoc=[{role:'model',parts:[{text}]},{role:'user',parts:[{text:promptVietTiep()}]}];
          const tiep=await generateOnce(fullName,model,parts,key,withThinking,
            n=>setProgress(Math.min(96,82+luot*4),'Bài dài, đang xin AI viết tiếp...',
              `${model} · lượt ${luot}/${MAX_VIET_TIEP} · thêm ${n.toLocaleString('vi-VN')} ký tự`),truoc);
          if(!tiep.text)break;                 /* không viết thêm được thì dừng, giữ phần đã có */
          const truocKhiNoi=text.length;
          text=noiTiepVanBan(text,tiep.text);
          finish=tiep.finish;
          if(text.length<=truocKhiNoi)break;   /* không dài thêm: tránh lặp vô ích */
        }
        if(finish==='MAX_TOKENS')
          throw new Error(`Bài soạn dài hơn hạn mức của ${model} (${maxTokensFor(fullName)} token). Đã tự xin viết tiếp ${MAX_VIET_TIEP} lượt mà vẫn chưa hết bài. Hãy giảm số tiết mỗi lần soạn, chọn phong cách “Gọn, dễ triển khai”, hoặc tách bài thành 2 lần soạn.`);
        if(!planLooksComplete(text))
          throw new Error(`Phản hồi của ${model} dừng sớm dù máy chủ báo đã xong. Phần mềm đã tự xin viết tiếp ${MAX_VIET_TIEP} lượt nhưng KHBD vẫn thiếu phần cuối; đang chuyển sang mô hình dự phòng.`);
        if(['SAFETY','RECITATION','BLOCKLIST','PROHIBITED_CONTENT','SPII'].includes(finish))
          throw new Error(`Phản hồi bị chặn (${finish}). Hãy giảm số tài liệu hoặc tạo lại.`);
        setModelStatus(`Đang dùng ${model}`,'ok');
        if([...$('model').options].some(o=>o.value===fullName))$('model').value=fullName;
        return text;
      }catch(err){
        const msg=err.message||'';
        /* Mô hình đời cũ không biết thinkingConfig: thử lại ngay, cùng mô hình, bỏ trường đó. */
        if(withThinking&&err.status===400&&/thinking|Unknown name|Invalid JSON payload/i.test(msg)){
          withThinking=false;attempt--;continue;
        }
        const transient=err.status===429||err.status===500||err.status===503||/quota|rate limit|overloaded|try again/i.test(msg);
        if(transient&&attempt<RETRY_DELAYS.length){
          const s=Math.round(RETRY_DELAYS[attempt]/1000);
          setProgress(50,'Google đang bận...',`${model} · chờ ${s} giây rồi thử lại (lần ${attempt+1}/${RETRY_DELAYS.length})`);
          await wait(RETRY_DELAYS[attempt]);
          continue;
        }
        /* Có những lỗi mà thử mô hình dự phòng chắc chắn cũng hỏng y hệt: bài quá dài so với
           hạn mức, khóa API sai/hết hạn, hoặc nội dung bị chặn. Dừng ngay, đừng bắt chờ thêm. */
        if(/hạn mức|API key not valid|API_KEY_INVALID|PERMISSION_DENIED|bị chặn/i.test(msg))throw err;
        errors.push(`${model}: ${msg}`);
        break;
      }
    }
  }
  throw new Error(`Đã thử ${candidates.length} mô hình nhưng đều chưa phản hồi${skipped?` (còn ${skipped} mô hình chưa thử, hãy chọn thủ công ở mục nâng cao)`:''}. ${errors.slice(0,2).join(' · ')}`);
}
function fallback(v){const p=v.periods||'…',g=clampGrade(v.grade);return `# KẾ HOẠCH BÀI DẠY\n## ${v.subject.toUpperCase()} ${g} — ${v.lesson}\n**Bộ sách:** ${v.book}  \n**Thời lượng:** ${p} tiết ${v.periods?'':'(cần xác định từ SGV)'}  \n**Đối tượng:** ${v.students}; **Sĩ số:** ${v.classSize}  \n**Thiết bị:** ${v.equipment}\n\n> Đây là khung dự thảo tạo không dùng AI (chưa gắn mã NLS/NLAI vì không tra được bảng mã ở chế độ này). Hãy bổ sung API key miễn phí để hệ thống đọc sâu tài liệu, tạo nội dung đặc thù và gắn đúng mã NLS/NLAI theo lớp ${g}.\n\n## I. MỤC TIÊU\n### 1. Về kiến thức\n- Nội dung kiến thức cốt lõi của bài ${v.lesson} theo đúng yêu cầu cần đạt của chương trình môn học.\n### 2. Về năng lực\n- Năng lực chung: tự chủ và tự học; giao tiếp và hợp tác; giải quyết vấn đề và sáng tạo.\n- Năng lực đặc thù môn học cần phát triển qua bài học.\n### 3. Về phẩm chất\n- Chăm chỉ, trung thực, trách nhiệm trong học tập và hợp tác.\n\n## II. THIẾT BỊ DẠY HỌC VÀ HỌC LIỆU\n- Giáo viên: SGK, SGV, phiếu học tập, ${v.equipment}.\n- Học sinh: SGK, vở ghi, dụng cụ học tập.\n\n## III. TIẾN TRÌNH DẠY HỌC\n### 1. Hoạt động 1: Xác định vấn đề/nhiệm vụ học tập/Mở đầu\na) Mục tiêu — b) Nội dung — c) Sản phẩm — d) Tổ chức thực hiện (Giao nhiệm vụ → Thực hiện nhiệm vụ → Báo cáo, thảo luận → Kết luận, nhận định).\n\n### 2. Hoạt động 2: Hình thành kiến thức mới\na) Mục tiêu — b) Nội dung — c) Sản phẩm — d) Tổ chức thực hiện (4 bước như trên).\n\n### 3. Hoạt động 3: Luyện tập\na) Mục tiêu — b) Nội dung: hệ thống câu hỏi/bài tập phân hoá cho học sinh ${v.students} — c) Sản phẩm: đáp án, lời giải — d) Tổ chức thực hiện (4 bước như trên).\n\n### 4. Hoạt động 4: Vận dụng\na) Mục tiêu — b) Nội dung: vận dụng kiến thức vào tình huống thực tiễn — c) Sản phẩm: báo cáo — d) Tổ chức thực hiện: thường giao ngoài giờ học trên lớp, nộp báo cáo vào thời điểm phù hợp.\n\n*(Đánh giá thường xuyên được lồng ngay trong mục d) Tổ chức thực hiện của từng hoạt động — hỏi–đáp, viết, thực hành, sản phẩm học tập — theo đúng Phụ lục IV, Công văn 5512/BGDĐT-GDTrH; không lập cột điểm/đầu điểm riêng cho NLS/NLAI.)*\n\n## ĐIỀU CHỈNH SAU BÀI DẠY\n........................................................................`}
// Phòng hờ: model đôi khi làm mất dấu "\" của lệnh LaTeX khi viết văn xuôi (mục a/b/c ngoài
// bảng tổ chức thực hiện) — ví dụ "$\vec{a}=k\vec{b}$" bị trả về thành "$veca=kvecb$". Bên trong
// bảng (JSON lessonflow) hầu như không gặp vì model phải giữ đúng cú pháp JSON. Đây chỉ là lưới an
// toàn, KHÔNG thay thế việc dặn model giữ đúng "\" ngay trong prompt (xem promptFor()).
/* ===== Vá lệnh LaTeX bị mất dấu gạch chéo ngược (viết lại ở b17) =====

   LỖI CỦA b16, ĐÚNG NHƯ BẢN IN GIÁO VIÊN ĐÁNH DẤU BÚT ĐỎ:
   Điều kiện nhận diện cũ đòi ngay sau tên lệnh phải là một trong { khoảng trắng ( ) + - = , .
   và HẾT. Nhưng trong tiếng Việt, khoảng và tập hợp gần như luôn viết kèm dấu CHẤM PHẨY:
   "(-\infty; 0)". Dấu ";" không có trong danh sách, nên "(- infty; 0)" KHÔNG được vá và in
   ra nguyên chữ "infty" giữa bài — trong khi "(- infty)" thì lại vá được. Cùng lý do,
   "sqrt[3]{...}" hỏng vì sau "sqrt" là dấu "[", và "setminus", "cup", "to", "lim" thì
   không hề có trong danh sách lệnh.

   NAY dùng đúng quy tắc của chính LaTeX: một tên lệnh kết thúc ở ký tự KHÔNG PHẢI CHỮ CÁI,
   bất kể ký tự đó là gì. Nhờ vậy dấu ";" "[" "]" "|" "^" "_" đều được xử lý mà không phải
   liệt kê. Đổi lại phải cẩn thận hai chỗ:
   - Bên trong \text{...} và \mathrm{...} là văn xuôi, không được vá (nếu không "in", "to"
     trong một câu tiếng Anh sẽ bị biến thành lệnh).
   - Sau \setminus hoặc \backslash, cặp ngoặc nhọn phải là ngoặc HIỂN THỊ \{...\} chứ không
     phải ngoặc gộp nhóm, nếu không ℝ∖{2} in ra thành "ℝ∖2". */
const LATEX_CMDS=[
  /* Lệnh dài đặt trước lệnh ngắn để phép so khớp không cắt cụt tên. */
  'overrightarrow','overleftarrow','longrightarrow','leftrightarrow','Leftrightarrow',
  'displaystyle','varepsilon','varnothing','underbrace','overbrace','Rightarrow',
  'rightarrow','leftarrow','Leftarrow','widetilde','widehat','overline','underline',
  'setminus','backslash','emptyset','triangle','parallel','subseteq','supseteq',
  'nrightarrow','therefore','because','partial','nabla','forall','exists','nexists',
  'mathbb','mathrm','mathbf','mathcal','approx','equiv','propto','notin','subset',
  'supset','infty','angle','sqrt','frac','dfrac','tfrac','left','right','quad','qquad',
  'times','cdot','perp','cong','prime','circ','boxed','text','limits','nolimits',
  'mathop','operatorname','arcsin','arccos','arctan','sinh','cosh','tanh',
  'log','ln','lg','exp','lim','max','min','sup','inf','deg','det','dim','gcd',
  'sin','cos','tan','cot','sec','csc','vec','hat','bar','dot','ddot',
  'sum','prod','int','iint','oint','cup','cap','land','lor','neg','ldots','cdots','dots',
  'alpha','beta','gamma','delta','theta','lambda','sigma','omega','varphi','phi','psi',
  'Delta','Gamma','Omega','Sigma','Lambda','Theta','Phi','Psi','Pi','Xi',
  'leq','geq','neq','le','ge','ne','pm','mp','to','in','ni','pi','mu','nu','xi','rho','tau'
];
const vecBareRe=/(^|[^\\}])vec(0|[A-Z][A-Za-z']{0,3}|[a-z]'?)\b/g;
const repairVecBare=s=>s.replace(vecBareRe,(m,pre,arg)=>pre+'\\vec{'+arg+'}');
/* Tên lệnh kết thúc ở ký tự không phải chữ cái — đúng quy tắc LaTeX. */
const latexCmdRe=new RegExp('(^|[^\\\\a-zA-Z])('+LATEX_CMDS.join('|')+')(?![a-zA-Z])','g');
/* Chỗ nào là văn xuôi thì che lại trước khi vá, trả về sau. */
const TEXT_ARG_RE=/\\?(text|mathrm|operatorname)\s*\{[^{}]*\}/g;
function repairLatex(s){
  const kho=[];
  let t=String(s).replace(TEXT_ARG_RE,m=>`\u0000${kho.push(m)-1}\u0000`);
  t=repairVecBare(t).replace(latexCmdRe,(m,pre,cmd)=>pre+'\\'+cmd);
  /* ℝ \setminus {2} phải thành ℝ \setminus \{2\} thì mới in ra cặp ngoặc nhọn. */
  t=t.replace(/\\(setminus|backslash)\s*\{([^{}]*)\}/g,(m,cmd,inner)=>`\\${cmd}\\{${inner}\\}`);
  /* Vạch đôi tại điểm gián đoạn: mọi cách viết đều đưa về một ký hiệu. */
  t=t.replace(/\\\|/g,'\\|');
  return t.replace(/\u0000(\d+)\u0000/g,(m,i)=>kho[+i]);
}
function inline(s){return esc(s).replace(/&lt;br\s*\/?&gt;/gi,'<br>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>').replace(/`(.+?)`/g,'<code>$1</code>').replace(/\$\$([^$]+)\$\$/g,(m,g1)=>`<span class="math-display">\\[${repairLatex(g1)}\\]</span>`).replace(/\$([^$]+)\$/g,(m,g1)=>`<span class="math">\\(${repairLatex(g1)}\\)</span>`)}
function mdToHtml(md){const specs=[];md=md.replace(/```mathviz\s*([\s\S]*?)```/gi,(_,json)=>{const id=specs.push(json.trim())-1;return `\n@@MATHVIZ_${id}@@\n`});const lines=md.replace(/```[a-z]*\n?/g,'').replace(/```/g,'').split('\n');let out='',list=false;for(let i=0;i<lines.length;i++){let l=lines[i].trimEnd(),mv=l.trim().match(/^@@MATHVIZ_(\d+)@@$/);if(mv){if(list){out+='</ul>';list=false}out+=`<div class="mathviz" data-spec="${encodeURIComponent(specs[+mv[1]])}"></div>`;continue}if(l.startsWith('|')&&i+1<lines.length&&/^\|?[\s:|-]+\|?$/.test(lines[i+1].trim())){if(list){out+='</ul>';list=false}const rows=[];rows.push(l);i+=2;while(i<lines.length&&lines[i].trim().startsWith('|')){rows.push(lines[i].trim());i++}i--;out+='<table>';rows.forEach((r,ri)=>{const cells=r.replace(/^\||\|$/g,'').split('|');out+=`<tr>${cells.map(c=>`<${ri?'td':'th'}>${inline(c.trim())}</${ri?'td':'th'}>`).join('')}</tr>`});out+='</table>';continue}if(/^#{1,3} /.test(l)){if(list){out+='</ul>';list=false}const n=l.match(/^#+/)[0].length;out+=`<h${n}>${inline(l.slice(n+1))}</h${n}>`}else if(/^[-*] /.test(l)){if(!list){out+='<ul>';list=true}out+=`<li>${inline(l.slice(2))}</li>`}else if(/^\d+\. /.test(l)){if(list){out+='</ul>';list=false}out+=`<p>${inline(l)}</p>`}else if(l.startsWith('> ')){if(list){out+='</ul>';list=false}out+=`<blockquote>${inline(l.slice(2))}</blockquote>`}else if(!l){if(list){out+='</ul>';list=false}}else{if(list){out+='</ul>';list=false}out+=`<p>${inline(l)}</p>`}}if(list)out+='</ul>';return out}
/* ===== Bộ đọc biểu thức (viết lại ở b16) =====
   LỖI CỦA BẢN b15: hàm cũ thay "pi" thành "Math.PI" RỒI mới kiểm tra chuỗi bằng một biểu
   thức chính quy chỉ chấp nhận chữ thường, nên mọi hàm có số pi đều bị loại ngay tại cửa —
   sin(pi*x), cos(2pi x) không vẽ được một nét nào. Bản cũ cũng không biết ln, log cơ số,
   e^x, cot và |x|, tức là gần như toàn bộ chương Hàm số mũ – lôgarit và chương Lượng giác
   đều không có đồ thị.
   NAY: đọc biểu thức bằng bộ phân tích cú pháp đệ quy, tự dựng chuỗi JavaScript từ những
   mảnh do chính nó sinh ra, nên vừa đúng vừa không thể bị chèn mã. Quy ước Việt Nam:
   log là lôgarit thập phân, ln là lôgarit tự nhiên, log_2(x) hoặc log(2,x) là cơ số 2. */
const EXPR_FUNCS={sin:'Math.sin',cos:'Math.cos',tan:'Math.tan',sinh:'Math.sinh',cosh:'Math.cosh',
  tanh:'Math.tanh',asin:'Math.asin',arcsin:'Math.asin',acos:'Math.acos',arccos:'Math.acos',
  atan:'Math.atan',arctan:'Math.atan',sqrt:'Math.sqrt',abs:'Math.abs',exp:'Math.exp',
  ln:'Math.log',log:'Math.log10',lg:'Math.log10',floor:'Math.floor',ceil:'Math.ceil',
  round:'Math.round',sign:'Math.sign',cbrt:'Math.cbrt'};
const EXPR_CONSTS={pi:'Math.PI',e:'Math.E'};

function compileExpr(expr){
  let src=String(expr||'').toLowerCase()
    .replace(/[−–—]/g,'-').replace(/[×⋅·]/g,'*').replace(/[÷]/g,'/')
    .replace(/\\left|\\right|\\,|\\;|\\!/g,'')
    .replace(/\\(dfrac|frac|tfrac)\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g,'(($2)/($3))')
    .replace(/\\sqrt\s*\[([^\]]*)\]\s*\{([^{}]*)\}/g,'(($2)^(1/($1)))')
    .replace(/\\sqrt\s*\{([^{}]*)\}/g,'sqrt($1)')
    /* \sqrt3 viết tắt không ngoặc — bảng biến thiên do AI sinh dùng rất nhiều. */
    .replace(/\\sqrt\s*([0-9]+(?:\.[0-9]+)?)/g,'sqrt($1)')
    .replace(/\\/g,'')
    .replace(/\s+/g,'');
  src=src.replace(/^y=|^f\(x\)=|^y\(x\)=/,'');
  src=src.replace(/\bt\b/g,'x');
  if(!src)throw Error('Biểu thức rỗng');

  /* --- Tách token --- */
  const toks=[];
  for(let i=0;i<src.length;){
    const c=src[i];
    if(/[0-9.]/.test(c)){let j=i;while(j<src.length&&/[0-9.]/.test(src[j]))j++;toks.push({t:'num',v:src.slice(i,j)});i=j;continue}
    if(/[a-z]/.test(c)){let j=i;while(j<src.length&&/[a-z0-9_]/.test(src[j]))j++;toks.push({t:'id',v:src.slice(i,j)});i=j;continue}
    if('+-*/^(),|'.includes(c)){toks.push({t:c});i++;continue}
    if(c==='{'){toks.push({t:'('});i++;continue}
    if(c==='}'){toks.push({t:')'});i++;continue}
    throw Error('Ký tự không hợp lệ: '+c);
  }

  let p=0,barDepth=0;
  const peek=()=>toks[p];
  const eat=t=>{if(!toks[p]||toks[p].t!==t)throw Error('Thiếu "'+t+'"');return toks[p++]};
  /* Dấu "|" đang đóng một cặp trị tuyệt đối thì KHÔNG được hiểu là mở một atom mới,
     nếu không "|x|" bị đọc thành "|x| * |…" rồi báo thiếu vế. */
  const startsAtom=k=>!!k&&(k.t==='num'||k.t==='id'||k.t==='('||(k.t==='|'&&barDepth===0));

  function parseExpr(){
    let s=parseTerm();
    while(peek()&&(peek().t==='+'||peek().t==='-')){const op=toks[p++].t;s+=op+parseTerm()}
    return s;
  }
  function parseTerm(){
    let s=parseUnary();
    for(;;){
      const k=peek();
      if(!k)break;
      if(k.t==='*'||k.t==='/'){p++;s+=k.t+parseUnary();continue}
      /* Nhân ngầm: 2x, 2sin(x), x(x+1), (x+1)(x-1), 2pi */
      if(startsAtom(k)){s+='*'+parseUnary();continue}
      break;
    }
    return s;
  }
  function parseUnary(){
    const k=peek();
    if(k&&(k.t==='-'||k.t==='+')){p++;return (k.t==='-'?'-':'')+parseUnary()}
    return parsePower();
  }
  function parsePower(){
    const base=parseAtom();
    if(peek()&&peek().t==='^'){p++;return 'Math.pow('+base+','+parseUnary()+')'}
    return base;
  }
  function parseAtom(){
    const k=peek();
    if(!k)throw Error('Biểu thức thiếu vế');
    if(k.t==='num'){p++;if(!/^\d*\.?\d+$/.test(k.v))throw Error('Số không hợp lệ: '+k.v);return '('+k.v+')'}
    if(k.t==='('){p++;const inner=parseExpr();eat(')');return '('+inner+')'}
    if(k.t==='|'){p++;barDepth++;const inner=parseExpr();barDepth--;eat('|');return 'Math.abs('+inner+')'}
    if(k.t==='id'){
      p++;
      let name=k.v,base=null;
      const m=/^log_?(\d+(?:\.\d+)?)$/.exec(name);
      if(m){name='log';base=m[1]}
      if(name==='x')return 'x';
      if(EXPR_CONSTS[name])return EXPR_CONSTS[name];
      if(name==='log'&&peek()&&peek().t==='id'&&/^\d+$/.test(peek().v)){/* không xảy ra */}
      if(EXPR_FUNCS[name]||base!==null){
        /* sin^2(x): mũ đặt ngay sau tên hàm */
        let expo=null;
        if(peek()&&peek().t==='^'){p++;expo=parseAtom()}
        let arg;
        if(peek()&&peek().t==='('){p++;arg=parseExpr();
          if(peek()&&peek().t===','){p++;const second=parseExpr();eat(')');
            if(name==='log')return 'Math.log('+second+')/Math.log('+arg+')';
            throw Error('Hàm '+name+' không nhận hai đối số')}
          eat(')');
        } else arg=parsePower();
        let out;
        if(base!==null)out='Math.log('+arg+')/Math.log('+base+')';
        else out=EXPR_FUNCS[name]+'('+arg+')';
        if(name==='cot')out='(1/Math.tan('+arg+'))';
        return expo?'Math.pow('+out+','+expo+')':out;
      }
      if(name==='cot'||name==='sec'||name==='csc'){
        let arg;
        if(peek()&&peek().t==='('){p++;arg=parseExpr();eat(')')}else arg=parsePower();
        return name==='cot'?'(1/Math.tan('+arg+'))':name==='sec'?'(1/Math.cos('+arg+'))':'(1/Math.sin('+arg+'))';
      }
      throw Error('Chưa hỗ trợ ký hiệu "'+k.v+'"');
    }
    throw Error('Ký hiệu bất ngờ');
  }

  const js=parseExpr();
  if(p<toks.length)throw Error('Thừa ký tự ở cuối biểu thức');
  /* Chốt an toàn: chuỗi dựng ra chỉ gồm các mảnh do chính bộ đọc sinh. */
  if(!/^[0-9x+\-*/(),.\sMath.a-z0-9_]*$/.test(js.replace(/Math\.[A-Za-z0-9]+/g,'')))
    throw Error('Biểu thức không an toàn');
  const f=new Function('x','"use strict";return ('+js+')');
  if(!Number.isFinite(f(0.37))&&!Number.isFinite(f(1.7))&&!Number.isFinite(f(-1.3))&&!Number.isFinite(f(2.9)))
    throw Error('Biểu thức không cho giá trị số');
  return f;
}
/* b17: đưa mọi cách viết vạch đôi tại điểm gián đoạn về cùng một ký hiệu, nếu không "\|"
   in ra nguyên văn giữa hàng đạo hàm như trong bản giáo viên đánh dấu. */
/* b20 — VÌ SAO tách thành hàm riêng: quy tắc nhận dạng này trước đây nằm rải hai chỗ, một bản
   trong wrapMathCell (dùng cho màn hình) và một bản so sánh chuỗi trong buildVariationPrintSVG
   (dùng cho ảnh xuất Word). Hai bản lệch nhau nên cùng một bảng biến thiên hiện đúng khi In/PDF
   mà hỏng khi xuất Word. Nay chỉ còn MỘT nơi định nghĩa, sửa một chỗ là cả hai đường cùng đổi.
   Nhận cả \| (LaTeX), ||, //, │ và ký tự ‖ sẵn có; KHÔNG nhận một gạch đứng đơn "|" vì đó là
   cách viết trị tuyệt đối, nhận nhầm sẽ nuốt mất nội dung ô.
   Cho phép NHIỀU dấu gạch ngược liền nhau: tuỳ chỗ mà chuỗi tới đây đã qua JSON.parse hay
   chưa, nên cùng một ô có thể mang "\|" hoặc "\\|". Phép kiểm mới ở test.html bắt được đúng
   ca thứ hai này — nếu chỉ nhận một gạch thì bảng vẫn hỏng khi khối JSON không được giải mã. */
const VACH_DOI=/^\s*(?:\\+\||\|\||\/\/|‖|││|\\+Vert|\\+parallel)\s*$/;
const laVachDoi=v=>VACH_DOI.test(String(v??''));
const wrapMathCell=v=>{const s=String(v??'').trim().replace(/\\\||\|\||\/\//g,'‖');if(!s)return '';if(/^[+\-0↗↘↑↓∞‖]+$/.test(s))return esc(s);return s.includes('$')?inline(s):`$${esc(s)}$`};
// Nhãn đặt trong foreignObject để MathJax vẫn xử lý được $...$ bên trong SVG (phân số, chỉ số dưới...).
function svgLabel(cx,cy,content,anchor,w,h){w=w||100;h=h||24;const x=anchor==='start'?cx:anchor==='end'?cx-w:cx-w/2;const justify=anchor==='start'?'flex-start':anchor==='end'?'flex-end':'center';return `<foreignObject x="${x}" y="${cy-h/2}" width="${w}" height="${h}" style="overflow:visible"><div xmlns="http://www.w3.org/1999/xhtml" class="vt-label" style="justify-content:${justify}">${content}</div></foreignObject>`}
// Dựng bảng biến thiên dạng sơ đồ đường gấp khúc (đúng chuẩn SGK) từ schema {points,derivative,values}.
// points: N mốc x (thường có -∞/+∞ ở 2 đầu). derivative: đúng 2N-3 phần tử, xen kẽ dấu-khoảng/giá trị-tại-điểm.
// values: N giá trị y tương ứng từng điểm trong "points"; một phần tử có thể là {left,right} để biểu diễn
// điểm gián đoạn/tiệm cận (vd hàm phân thức) — khi đó vẽ dấu ngắt "‖" và tách 2 nhãn giá trị trái/phải.
function coerceLen(arr,n,fill){arr=Array.isArray(arr)?arr.slice():[];while(arr.length<n)arr.push(fill);if(arr.length>n)arr.length=n;return arr}

/* ===== Bảng xét dấu vẽ theo chuẩn SGK =====
   LỖI ĐÃ SỬA: bảng xét dấu trước đây dựng bằng <table> thường, mỗi "cells" là một <td>.
   Nhưng bảng xét dấu KHÔNG phải bảng thường: các dấu nằm XEN KẼ giữa và tại các mốc.
   Với N mốc thì có N-1 khoảng và N-2 mốc trong, tổng cộng 2N-3 ô dấu — nhiều hơn số cột
   tiêu đề. Hệ quả: thead có N ô còn tbody có 1+2N-3 ô, trình duyệt tự kéo giãn, bảng lệch
   hẳn và các mốc phình to như trong ảnh giáo viên gửi. Nay vẽ bằng SVG với đúng hình học
   xen kẽ: mốc nằm trên vạch dọc, dấu khoảng nằm giữa hai vạch. */

/* Từ bảng biến thiên suy ra luôn đồ thị. Giáo viên phản ánh bản soạn "chỉ có công thức và lời
   nói, không có hình ảnh trực quan": mô hình chịu viết bảng biến thiên nhưng gần như không bao
   giờ tự thêm khối đồ thị. Nay chỉ cần nó khai báo thêm "expr" trong chính khối bảng biến thiên
   là phần mềm vẽ luôn đồ thị bên dưới — bớt được một việc mà mô hình hay quên. */
/* Nhãn hiển thị: bỏ dấu * mà AI hay chèn ("x^3-3*x^2+2*x+1"), vì SGK không viết dấu nhân
   giữa hệ số và biến. */
/* Nhãn hiển thị: bỏ cặp *...* kiểu markdown mà AI hay bọc quanh nhãn (bản in hiện ra
   nguyên hai dấu sao), rồi bỏ dấu nhân giữa hệ số và biến vì SGK không viết dấu đó. */
const nhanGon=t=>String(t||'').trim().replace(/^\*+|\*+$/g,'')
  .replace(/([0-9a-zA-Z)\}])\s*\*\s*(?=[0-9a-zA-Z(\\])/g,'$1').trim();
function graphFromVariation(spec){
  const expr=String(spec.expr||'').trim();
  if(!expr)return null;
  /* b18 — GỐC CỦA ĐỒ THỊ VẼ TRÊN TRỤC TUNG -160..60 MÀ GIÁO VIÊN CHỤP LẠI.
     Mốc trong bảng biến thiên hầu như luôn là biểu thức LaTeX: \dfrac{3-\sqrt3}{3},
     1-\dfrac{2\sqrt3}{9}... Number() của mấy chuỗi đó là NaN, nên b17 coi như KHÔNG CÓ mốc
     nào, rơi về khung mặc định [-5; 5] rồi lấy phân vị mẫu — với hàm bậc ba thì tại x=-5
     giá trị đã là -209, thế là cả đường cong bẹp thành một nét ngang sát trục hoành.
     Nay dùng chính bộ đọc biểu thức của phần mềm để tính mốc ra số. */
  const soTuLatex=p=>{
    const t=String(p??'').trim();
    if(!t||/infty|∞/i.test(t))return NaN;
    const n=Number(t.replace(',','.'));
    if(Number.isFinite(n))return n;
    try{const v=compileExpr(t)(0);return Number.isFinite(v)?v:NaN}catch(_){return NaN}
  };
  const nums=(spec.points||[]).map(soTuLatex).filter(Number.isFinite);
  /* b17: bản in của giáo viên có đồ thị y = x^4-3x^2+1 vẽ trên trục tung 0..55, hai cực tiểu
     -5/4 bị bẹp dí sát trục hoành, nhìn không ra hình. Nguyên nhân kép:
     1) Đệm trục hoành cũ cộng thêm HẲN 2 đơn vị mỗi bên. Với ba nghiệm nằm gọn trong
        [-1,22; 1,22] thì khung kéo ra tới [-4; 4], mà tại x=4 hàm bậc bốn đã lên tới 209.
     2) Miền tung độ cũ đọc từ spec.values, nhưng bảng biến thiên ghi giá trị dưới dạng
        "-5/4" và "+∞" — Number("-5/4") là NaN, nên toàn bộ bị bỏ và rơi về mặc định ±5,
        rồi bộ tự nới lại kéo lên theo giá trị ở rìa.
     Nay: đệm trục hoành theo tỉ lệ, và tính thẳng giá trị hàm TẠI CÁC ĐIỂM CỰC TRỊ để lấy
     miền tung độ — không phụ thuộc vào cách AI viết phân số nữa. */
  let xMin=-5,xMax=5,f0=null;
  try{f0=compileExpr(expr)}catch(_){}
  /* b19: hàm ĐƠN ĐIỆU (bảng biến thiên chỉ có -∞ và +∞) thì không có mốc nào, b18 rơi về
     [-5; 5] — với y = -2x³+3x²-5x thì miền giá trị trải hơn 500 đơn vị và đồ thị thành một
     vạch dọc trong bản in. Nay lấy điểm uốn làm tâm và chỉ nhìn quanh đó vài đơn vị. */
  if(!nums.length&&f0){
    const dd=x=>{const h=1e-3;return (f0(x+h)-2*f0(x)+f0(x-h))/(h*h)};
    let tam=0,truoc=null;
    for(let x=-6;x<=6;x+=0.25){const v=dd(x);
      if(!Number.isFinite(v))continue;
      if(Math.abs(v)<1e-9){tam=x;break}
      if(truoc!==null&&truoc*v<0){tam=x-0.125;break}
      truoc=v}
    xMin=tam-2.5;xMax=tam+2.5;
  }
  if(nums.length){
    const lo=Math.min(...nums),hi=Math.max(...nums),span=hi-lo;
    const pad=Math.max(span*0.55,1);
    xMin=lo-pad;xMax=hi+pad;
    if(span===0){xMin=lo-3;xMax=lo+3}
  }
  let yMin=-5,yMax=5;const f=f0;
  if(f){
    const moc=[];
    nums.forEach(x=>{const y=f(x);if(Number.isFinite(y))moc.push(y)});
    if(moc.length){
      const lo=Math.min(...moc),hi=Math.max(...moc),span=hi-lo;
      const pad=Math.max(span*0.6,Math.abs(hi)*0.35,1);
      yMin=lo-pad;yMax=hi+pad;
    }else{
      /* Không có mốc hữu hạn (ví dụ hàm phân thức chỉ có tiệm cận): lấy phân vị của mẫu
         để điểm sát tiệm cận đứng không kéo bẹt cả đường cong. */
      const mau=[];
      for(let i=0;i<=400;i++){const y=f(xMin+(xMax-xMin)*i/400);if(Number.isFinite(y)&&Math.abs(y)<1e9)mau.push(y)}
      if(mau.length>8){mau.sort((a,b)=>a-b);
        const q=t=>mau[Math.floor((mau.length-1)*t)];
        const lo=q(.08),hi=q(.92),pad=Math.max((hi-lo)*.25,1);
        yMin=lo-pad;yMax=hi+pad;}
    }
  }
  const r=v=>Math.round(v*100)/100;
  return {type:'graph',title:'Đồ thị '+nhanGon(spec.funcLabel||('y = '+expr)),
    xMin:r(xMin),xMax:r(xMax),yMin:r(yMin),yMax:r(yMax),autoFit:false,
    asymptotes:spec.asymptotes||[],functions:[{expr,label:nhanGon(spec.funcLabel||('y='+expr))}]};
}
function buildSignSVG(spec){
  const pts=(spec.columns||spec.points||[]).map(x=>String(x??''));
  const N=pts.length;
  if(N<2)return null;
  const rows=(spec.rows||[]).map(r=>({label:r.label??'',cells:coerceLen(r.cells,2*N-3,'')}));
  if(!rows.length)return null;
  /* Chuẩn SGK: không đóng khung, không kẻ cột tại nghiệm; chỉ một vạch dọc sau
     cột nhãn và các đường ngang phân hàng. Dấu khoảng nằm giữa hai mốc. */
  const W=760,leftLabel=62,rightPad=18,xStart=leftLabel+28,xEnd=W-rightPad-10,plotW=xEnd-xStart;
  const xAt=i=>xStart+(N===1?0:i*(plotW/(N-1)));
  const bandX=40,bandRow=46,padTop=8;
  const H=padTop+bandX+bandRow*rows.length+8;
  const rowTop=k=>padTop+bandX+bandRow*k;
  let svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(spec.title||'Bảng xét dấu')}">`;
  svg+=`<line x1="${leftLabel}" y1="${padTop}" x2="${leftLabel}" y2="${H-8}" class="vt-frame"/>`;
  for(let k=0;k<rows.length;k++){const y=rowTop(k);
    svg+=`<line x1="8" y1="${y}" x2="${W-rightPad}" y2="${y}" class="vt-frame"/>`}
  // nhãn hàng bên trái
  svg+=svgLabel(20,padTop+bandX/2,'$x$','middle',28,20);
  rows.forEach((r,k)=>{svg+=svgLabel(20,rowTop(k)+bandRow/2,wrapMathCell(r.label),'middle',30,20)});
  // các mốc trên hàng x
  pts.forEach((p,i)=>{svg+=svgLabel(xAt(i),padTop+bandX/2,wrapMathCell(p),'middle',120,22)});
  // dấu: chỉ số chẵn là dấu trên khoảng, chỉ số lẻ là giá trị tại mốc trong
  const discontinuities=new Set();
  rows.forEach((r,k)=>{
    const cy=rowTop(k)+bandRow/2;
    /* String(undefined) trả về chuỗi "undefined" chứ không phải chuỗi rỗng, nên nếu thiếu ô
       thì bảng in ra chữ "undefined" giữa bài. Phải dùng ?? '' trước khi ép kiểu. */
    for(let i=0;i<N-1;i++){const v=r.cells[2*i];
      if(String(v??'').trim())svg+=svgLabel((xAt(i)+xAt(i+1))/2,cy,wrapMathCell(v),'middle',80,22)}
    for(let i=1;i<=N-2;i++){const v=r.cells[2*i-1],sv=String(v??'').trim();
      if(/^\\?\|$/.test(sv))discontinuities.add(i);
      else if(sv)svg+=svgLabel(xAt(i),cy,wrapMathCell(v),'middle',60,22)}
  });
  discontinuities.forEach(i=>{svg+=`<line x1="${xAt(i)-3}" y1="${padTop+2}" x2="${xAt(i)-3}" y2="${H-10}" class="vt-discontinuity"/>`+
    `<line x1="${xAt(i)+3}" y1="${padTop+2}" x2="${xAt(i)+3}" y2="${H-10}" class="vt-discontinuity"/>`});
  return svg+'</svg>';
}
/* ===== Bảng biến thiên dạng ẢNH để đưa vào tệp Word (thêm ở b19) =====

   VÌ SAO: giáo viên khoanh nguyên bảng biến thiên trong tệp Word và ghi "BBT xuất ra dạng
   Word bị lỗi — đề nghị BBT nên ở dạng ảnh như đồ thị thì không bị lỗi". Bảng biến thiên
   dựng bằng ô bảng Word không bao giờ ra đúng: mũi tên phải nằm CHÉO giữa hai mốc, vạch
   đôi phải cắt dọc cả ba hàng, và chiều rộng các khoảng phải tỉ lệ — ô bảng không làm được
   ba việc đó.

   VÌ SAO KHÔNG DÙNG LẠI ẢNH TRÊN MÀN HÌNH: bản trên màn hình dựng nhãn bằng <foreignObject>
   để MathJax vẽ công thức. Trình duyệt TỪ CHỐI vẽ foreignObject lên canvas, nên không thể
   đổi sang PNG. Vì vậy ở đây dựng một bản riêng chỉ dùng <text>, kèm bộ đổi LaTeX sang ký
   tự Unicode cho các nhãn ngắn thường gặp trong bảng biến thiên. */

const SIEU_SO={'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','+':'⁺','-':'⁻','n':'ⁿ'};
const DUOI_SO={'0':'₀','1':'₁','2':'₂','3':'₃','4':'₄','5':'₅','6':'₆','7':'₇','8':'₈','9':'₉'};
const KY_HIEU={infty:'∞',pm:'±',mp:'∓',times:'×',cdot:'·',to:'→',rightarrow:'→',
  alpha:'α',beta:'β',gamma:'γ',delta:'δ',Delta:'Δ',theta:'θ',lambda:'λ',mu:'μ',pi:'π',
  sigma:'σ',omega:'ω',varphi:'φ',phi:'φ',le:'≤',ge:'≥',leq:'≤',geq:'≥',ne:'≠',neq:'≠',
  approx:'≈',in:'∈',notin:'∉',cup:'∪',cap:'∩',setminus:'∖',backslash:'∖',
  varnothing:'∅',emptyset:'∅',forall:'∀',exists:'∃',sqrt:'√',mathbb:'',mathrm:'',text:''};

/* Đổi một nhãn LaTeX ngắn sang chuỗi ký tự thường, đủ dùng cho ô của bảng biến thiên. */
function texToPlain(t){
  let s=String(t??'').trim();
  if(!s)return '';
  s=s.replace(/^\$+|\$+$/g,'');
  if(typeof repairLatex==='function')s=repairLatex(s);
  s=s.replace(/\\left|\\right|\\,|\\;|\\!|\\quad|\\qquad/g,'');
  for(let i=0;i<4;i++)
    s=s.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g,(m,a,b)=>
      (/[+\-]/.test(a)?`(${a})`:a)+'/'+(/[+\-]/.test(b)?`(${b})`:b));
  s=s.replace(/\\sqrt\s*\{([^{}]*)\}/g,(m,a)=>'√'+(/[+\-\/]/.test(a)?`(${a})`:a))
     .replace(/\\sqrt\s*([0-9a-zA-Z])/g,'√$1');
  s=s.replace(/\^\s*\{([^{}]*)\}|\^\s*([0-9a-zA-Z+\-])/g,(m,a,b)=>
    [...(a||b)].map(c=>SIEU_SO[c]||c).join(''));
  s=s.replace(/_\s*\{([^{}]*)\}|_\s*([0-9a-zA-Z])/g,(m,a,b)=>{
    const t=a||b;return [...t].every(c=>DUOI_SO[c])?[...t].map(c=>DUOI_SO[c]).join(''):t});
  s=s.replace(/\\([a-zA-Z]+)/g,(m,n)=>KY_HIEU[n]!==undefined?KY_HIEU[n]:n);
  return s.replace(/[{}]/g,'').replace(/\s+/g,' ').trim();
}

/* Dựng bảng biến thiên bằng <text> và đường kẻ — đưa thẳng sang PNG được. */
function buildVariationPrintSVG(spec){
  const pts=(Array.isArray(spec.points)?spec.points:[]).map(texToPlain);
  const N=pts.length;
  if(N<2)return null;
  const dau=(spec.derivative||[]).map(texToPlain);
  /* b20 — VÌ SAO giữ thêm bản GỐC: texToPlain đổi mọi tên lệnh gồm chữ cái thành chữ thường,
     nên "\Vert" biến thành "Vert" và không còn nhận ra là vạch đôi nữa. Nhận dạng phải soi
     chuỗi trước khi nó bị biến dạng; đây đúng là kiểu lỗi chỉ lộ ra khi thử trên trường hợp biên. */
  const dauGoc=(spec.derivative||[]).map(v=>String(v??''));
  const gt=(spec.values||[]).map(v=>(v&&typeof v==='object')
    ?{left:texToPlain(v.left),right:texToPlain(v.right)}:texToPlain(v));
  const doRong=Math.max(24,...pts.map(t=>t.length),
    ...gt.map(v=>typeof v==='object'?Math.max(v.left.length,v.right.length):String(v).length));
  const colNhan=64,khoang=Math.max(96,doRong*7);
  const p=18,le=34;
  const W=p*2+colNhan+le*2+khoang*(N-1);
  const hX=40,hD=40,hY=86,H=p*2+hX+hD+hY+(spec.title?30:0);
  const y0=p+(spec.title?30:0),y1=y0+hX,y2=y1+hD,y3=y2+hY;
  const X=i=>p+colNhan+le+khoang*i;
  const giua=i=>(X(i)+X(i+1))/2;
  let g=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`+
    `<style>.bbt{font:16px/1 "Times New Roman",Georgia,serif;fill:#123252}`+
    `.bbt-i{font:italic 16px/1 "Times New Roman",Georgia,serif;fill:#123252}`+
    `.bbt-t{font:bold 15px/1 "Segoe UI",Arial,sans-serif;fill:#123252}`+
    `.bbt-l{stroke:#123252;stroke-width:1.1;fill:none}`+
    `.bbt-a{stroke:#176fa8;stroke-width:1.6;fill:none}</style>`+
    `<rect width="${W}" height="${H}" fill="#ffffff"/>`;
  if(spec.title)g+=`<text x="${W/2}" y="${p+16}" text-anchor="middle" class="bbt-t">${esc(texToPlain(spec.title))}</text>`;
  /* Khung ngoài và hai đường kẻ ngang chia ba hàng x, y', y. */
  g+=`<rect x="${p}" y="${y0}" width="${W-2*p}" height="${y3-y0}" class="bbt-l"/>`+
     `<line x1="${p}" y1="${y1}" x2="${W-p}" y2="${y1}" class="bbt-l"/>`+
     `<line x1="${p}" y1="${y2}" x2="${W-p}" y2="${y2}" class="bbt-l"/>`+
     `<line x1="${p+colNhan}" y1="${y0}" x2="${p+colNhan}" y2="${y3}" class="bbt-l"/>`;
  g+=`<text x="${p+colNhan/2}" y="${(y0+y1)/2+6}" text-anchor="middle" class="bbt-i">x</text>`+
     `<text x="${p+colNhan/2}" y="${(y1+y2)/2+6}" text-anchor="middle" class="bbt-i">y'</text>`+
     `<text x="${p+colNhan/2}" y="${(y2+y3)/2+6}" text-anchor="middle" class="bbt-i">y</text>`;
  pts.forEach((t,i)=>g+=`<text x="${X(i)}" y="${(y0+y1)/2+6}" text-anchor="middle" class="bbt">${esc(t)}</text>`);
  /* Hàng dấu: dấu trên các khoảng, còn 0 hoặc vạch đôi ngay tại mốc. */
  /* Quy ước của mảng derivative: chỉ số CHẴN là dấu trên một khoảng, chỉ số LẺ là ký hiệu
     ngay tại một mốc (số 0 hoặc vạch đôi). Tính nhầm chỗ này thì số 0 và vạch đôi trôi
     sang giữa khoảng — đúng kiểu bảng biến thiên "bị lỗi" trong tệp Word. */
  /* b20 — VÌ SAO phải nhận nhiều cách viết: bản in ra Word của bài "Khảo sát sự biến thiên"
     hiện nguyên văn hai ký tự "\|" giữa hàng y' và KHÔNG có vạch đôi nào, trong khi bản
     In/PDF trên màn hình vẽ đúng. Nguyên nhân: bản màn hình lọc qua wrapMathCell (dòng ~535)
     vốn đã đưa \| , || , // về ‖, còn bản ảnh này chỉ so sánh đúng hai chuỗi '‖' và '||'.
     texToPlain không đụng tới "\|" vì quy tắc thay lệnh LaTeX chỉ nhận tên gồm CHỮ CÁI,
     mà "|" không phải chữ cái — nên chuỗi đi thẳng ra <text>. Nay dùng chung một hàm nhận
     dạng cho cả hai đường vẽ, để hai bản không bao giờ lệch nhau nữa. */
  const veVachDoi=x=>`<line x1="${x-2}" y1="${y1+6}" x2="${x-2}" y2="${y3-6}" class="bbt-l"/>`+
    `<line x1="${x+2}" y1="${y1+6}" x2="${x+2}" y2="${y3-6}" class="bbt-l"/>`;
  const daVe=new Set();
  dau.forEach((t,i)=>{
    if(!t)return;
    const taiMoc=i%2===1;
    const x=taiMoc?X((i+1)/2):giua(i/2);
    if(laVachDoi(t)||laVachDoi(dauGoc[i])){g+=veVachDoi(x);if(taiMoc)daVe.add((i+1)/2)}
    else g+=`<text x="${x}" y="${(y1+y2)/2+6}" text-anchor="middle" class="bbt">${esc(t)}</text>`;
  });
  /* VÌ SAO vẽ thêm ở đây: một giá trị dạng {left,right} tự nó đã là điểm gián đoạn, kể cả khi
     AI quên ghi ký hiệu vạch đôi ở hàng y'. Bản màn hình vẽ vạch dựa vào chính values nên vẫn
     đúng; bản ảnh trước đây chỉ dựa vào derivative nên mất vạch. Set daVe chặn vẽ chồng hai lần. */
  gt.forEach((v,i)=>{
    if(v&&typeof v==='object'&&!daVe.has(i)&&i>0&&i<N-1){g+=veVachDoi(X(i));daVe.add(i)}
  });
  /* Hàng giá trị: mốc ở hai mép, mũi tên chéo nối giữa — đúng lối vẽ của SGK. */
  const cao=(v,i)=>{
    const so=parseFloat(String(v).replace(',','.').replace('∞','Infinity').replace('−','-'));
    return so;
  };
  const veGt=(v,i)=>{
    const x=X(i);
    if(v&&typeof v==='object'){
      /* Tại điểm gián đoạn, giới hạn trái viết SÁT BÊN TRÁI vạch đôi và giới hạn phải sát
         bên phải — viết chồng lên vạch như bản đầu thì đọc không ra. */
      const tren=/^[+]?∞/.test(v.left)?y2+22:y3-12, duoi=/^[+]?∞/.test(v.right)?y2+22:y3-12;
      g+=`<text x="${x-8}" y="${tren}" text-anchor="end" class="bbt">${esc(v.left)}</text>`+
         `<text x="${x+8}" y="${duoi}" text-anchor="start" class="bbt">${esc(v.right)}</text>`;
      return;
    }
    const t=String(v??'');
    const tren=/^[+]?∞/.test(t),duoi=/^[−-]∞/.test(t);
    const yy=tren?y2+22:duoi?y3-10:(y2+y3)/2+6;
    g+=`<text x="${x}" y="${yy}" text-anchor="middle" class="bbt">${esc(t)}</text>`;
  };
  const mocY=i=>{
    const v=gt[i];const t=(v&&typeof v==='object')?v.right:String(v??'');
    return /^[+]?∞/.test(t)?y2+16:/^[−-]∞/.test(t)?y3-16:(y2+y3)/2;
  };
  const mocYTrai=i=>{
    const v=gt[i];const t=(v&&typeof v==='object')?v.left:String(v??'');
    return /^[+]?∞/.test(t)?y2+16:/^[−-]∞/.test(t)?y3-16:(y2+y3)/2;
  };
  /* b20 — VÌ SAO phải lùi mũi tên tại điểm gián đoạn: nhãn giới hạn trái được đặt ở X-8 với
     text-anchor="end", tức nó CHIẾM chỗ về phía trái của X-8, trong khi mũi tên trước đây luôn
     kết thúc ở X-22 — nằm gọn trong vùng chữ. Trong bản Word của giáo viên, đầu mũi tên đè lên
     "-∞" và ăn mất dấu trừ, đọc ra thành "∞". Chừa thêm chỗ đúng bằng bề ngang ước lượng của
     nhãn (khoảng 7,2 px một ký tự, như doRong ở trên đã dùng), chỉ tại mốc gián đoạn. */
  const rongNhan=t=>Math.min(64,String(t??'').length*7.2+6);
  const lui=(i,ben)=>{
    const v=gt[i];
    if(!(v&&typeof v==='object'))return 22;
    return 22+rongNhan(ben==='trai'?v.left:v.right);
  };
  for(let i=0;i<N-1;i++){
    const x0=X(i),x1=X(i+1),ya=mocY(i),yb=mocYTrai(i+1);
    let la=lui(i,'phai'),lb=lui(i+1,'trai');
    /* VÌ SAO có bước co lại này — BÀI HỌC CỦA b18: một ràng buộc hình học mới, khi gặp trường
       hợp biên (ở đây là nhãn giá trị rất dài), có thể ăn hết chỗ và làm nét vẽ biến mất hẳn.
       Nếu chỗ chừa hai bên vượt quá bề ngang khoảng thì co đều cả hai theo tỉ lệ, giữ cho mũi
       tên còn tối thiểu 16 px. Thà mũi tên ngắn và chạm nhẹ vào nhãn, còn hơn mất mũi tên. */
    const conLai=(x1-x0)-la-lb, TOI_THIEU=16;
    if(conLai<TOI_THIEU){
      const cho=Math.max(0,(x1-x0)-TOI_THIEU), tong=la+lb;
      if(tong>0){const k=cho/tong;la*=k;lb*=k}
    }
    const a=x0+la,b=x1-lb;
    if(b>a)g+=`<path d="M${a} ${ya} L${b} ${yb}" class="bbt-a" marker-end="url(#mb)"/>`;
  }
  g+=`<defs><marker id="mb" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,1 L10,5 L0,9 z" fill="#176fa8"/></marker></defs>`;
  gt.forEach(veGt);
  return g+'</svg>';
}

/* ===== HÌNH KHỐI KHÔNG GIAN (thêm ở b21) =====
   VÌ SAO cần: bản in Bài 6 "Vectơ trong không gian" của giáo viên không có LẤY MỘT HÌNH NÀO.
   Kiểm chứng: cả tệp Word lẫn bản IN/PDF của bài đó đều chứa 0 ảnh, trong khi nội dung liên
   tục nhắc "quan sát Hình 2.2", "cho hình lập phương ABCD.A'B'C'D'", "cho tứ diện ABCD".
   Nguyên nhân: phần mềm mới chỉ dựng được ba loại hình — đồ thị hàm số, bảng biến thiên và
   bảng xét dấu — tức là toàn bộ mảng GIẢI TÍCH. Bài hình học không gian rơi vào khoảng trống.
   Với môn Toán, hoạt động dựa trên hình mà không có hình thì giáo viên không dạy được.

   CÁCH DỰNG: phép chiếu song song như SGK. Điều đáng nói nhất là cách xác định NÉT ĐỨT:
   không đoán theo từng khối, mà TÍNH. Với một khối lồi, một cạnh bị che khi và chỉ khi cả hai
   mặt kề nó đều quay lưng lại người xem. Quy tắc đó đúng cho mọi khối lồi nên hình hộp, tứ
   diện, hình chóp và lăng trụ đều ra đúng bằng cùng một đoạn mã, không cần bảng tra thủ công
   dễ sai. Pháp tuyến được tự động lật cho hướng ra ngoài bằng cách so với tâm khối, nên thứ tự
   liệt kê đỉnh của mỗi mặt không ảnh hưởng kết quả.

   MỘT ĐƯỜNG VẼ DUY NHẤT cho cả màn hình và tệp Word — đây là bài học trực tiếp của b20, khi
   bảng biến thiên có hai đường vẽ riêng và chúng lệch nhau. Hình khối chỉ dùng <text>, không
   dùng foreignObject, nên đổi thẳng sang PNG được và hai nơi không thể khác nhau. */
const SOLID_KHOI={
  'hinh-hop':{d:['A','B','C','D','A2','B2','C2','D2'],
    v:{A:[0,0,0],B:[1.7,0,0],C:[1.7,1.05,0],D:[0,1.05,0],
       A2:[0,0,1.25],B2:[1.7,0,1.25],C2:[1.7,1.05,1.25],D2:[0,1.05,1.25]},
    m:[['A','B','C','D'],['A2','B2','C2','D2'],['A','B','B2','A2'],
       ['B','C','C2','B2'],['C','D','D2','C2'],['D','A','A2','D2']]},
  /* VÌ SAO toạ độ tứ diện và chóp tam giác đặt như thế này: nếu đỉnh phía sau chiếu LỌT VÀO
     TRONG tam giác mặt trước thì nó bị che hoàn toàn và CẢ BA cạnh nối tới nó đều thành nét
     đứt — đúng về hình học nhưng không phải lối vẽ của SGK, nhìn rất khó đọc. Đã đo lại: với
     bộ số dưới đây đỉnh sau nhô hẳn ra ngoài nên chỉ còn ĐÚNG MỘT cạnh đứt, như hình trong sách. */
  'tu-dien':{d:['A','B','C','D'],
    v:{B:[0,0,0],C:[1.75,0,0],D:[1.0,1.35,0],A:[0.6,0.45,1.15]},
    m:[['B','C','D'],['A','B','C'],['A','C','D'],['A','D','B']]},
  'hinh-chop-tu-giac':{d:['S','A','B','C','D'],
    v:{A:[0,0,0],B:[1.75,0,0],C:[2.25,1.1,0],D:[0.5,1.1,0],S:[1.12,0.55,1.6]},
    m:[['A','B','C','D'],['S','A','B'],['S','B','C'],['S','C','D'],['S','D','A']]},
  'hinh-chop-tam-giac':{d:['S','A','B','C'],
    v:{A:[0,0,0],B:[1.75,0,0],C:[1.0,1.35,0],S:[0.6,0.45,1.25]},
    m:[['A','B','C'],['S','A','B'],['S','B','C'],['S','C','A']]},
  'lang-tru-tam-giac':{d:['A','B','C','A2','B2','C2'],
    v:{A:[0,0,0],B:[1.75,0,0],C:[0.95,1.1,0],
       A2:[0,0,1.4],B2:[1.75,0,1.4],C2:[0.95,1.1,1.4]},
    m:[['A','B','C'],['A2','B2','C2'],['A','B','B2','A2'],['B','C','C2','B2'],['C','A','A2','C2']]}
};
/* Bí danh: mô hình viết tên khối theo nhiều kiểu, chấp nhận hết thay vì bắt nhớ đúng một chuỗi. */
const SOLID_BIDANH={'hinh-lap-phuong':'hinh-hop','lap-phuong':'hinh-hop','hop':'hinh-hop',
  'hinh-hop-chu-nhat':'hinh-hop','lang-tru-tu-giac':'hinh-hop','tudien':'tu-dien','tu-dien-deu':'tu-dien',
  'chop-tu-giac':'hinh-chop-tu-giac','hinh-chop':'hinh-chop-tu-giac','chop-tam-giac':'hinh-chop-tam-giac',
  'hinh-chop-tam-giac-deu':'hinh-chop-tam-giac','lang-tru':'lang-tru-tam-giac','hinh-lang-tru':'lang-tru-tam-giac'};
/* Tên đỉnh có dấu phẩy (A', B'...) được đưa về khoá nội bộ A2, B2 để tra bảng cho gọn. */
const solidKhoa=t=>String(t??'').trim().replace(/[′']/g,'2').replace(/\s+/g,'');
const solidHien=t=>String(t??'').trim().replace(/'/g,'′').replace(/2$/,'′');

function buildSolidSVG(spec){
  /* VÌ SAO phải bỏ dấu cả chuỗi: bản đầu chỉ gạt dấu ở chữ "Hình" đứng đầu, nên "Hình hộp chữ
     nhật" thành "hinh-hộp-chữ-nhật" và không tra được bảng — phép kiểm ngược đã bắt đúng ca này.
     Mô hình viết tên khối bằng tiếng Việt có dấu là chuyện bình thường, không thể bắt nó nhớ
     đúng một chuỗi không dấu. */
  const ten=(typeof deaccent==='function'?deaccent(String(spec.shape||spec.khoi||'')):String(spec.shape||spec.khoi||''))
    .trim().toLowerCase().replace(/[\s_]+/g,'-');
  const key=SOLID_KHOI[ten]?ten:(SOLID_BIDANH[ten]||'');
  const mau=SOLID_KHOI[key];
  if(!mau)return null;
  /* Đổi tên đỉnh theo yêu cầu: {"A":"M"} — dùng khi bài đặt tên khác SGK. */
  const doiTen=spec.labels||spec.ten||{};
  const nhan=k=>solidHien(doiTen[solidHien(k)]||doiTen[k]||k);

  const P={};Object.keys(mau.v).forEach(k=>P[k]=mau.v[k].slice());
  /* Điểm phụ trên cạnh: {"name":"M","between":["B","C"],"ratio":0.5} — trung điểm là mặc định. */
  const phu=[];
  (Array.isArray(spec.points)?spec.points:[]).forEach(p=>{
    const a=solidKhoa(p.between&&p.between[0]),b=solidKhoa(p.between&&p.between[1]);
    if(!P[a]||!P[b])return;
    const t=Number.isFinite(+p.ratio)?+p.ratio:0.5, ten=solidKhoa(p.name||'');
    if(!ten)return;
    P[ten]=[0,1,2].map(i=>P[a][i]+(P[b][i]-P[a][i])*t);
    phu.push(ten);
  });

  /* Phép chiếu song song: trục sâu nghiêng 40°, hệ số 0,55 như lối vẽ hình không gian của SGK. */
  const K=0.55,GOC=40*Math.PI/180,CX=Math.cos(GOC),SX=Math.sin(GOC),DV=92;
  const chieu=p=>[(p[0]+K*CX*p[1])*DV,-(p[2]+K*SX*p[1])*DV];
  /* Vectơ từ vật tới mắt, suy ra từ chính phép chiếu ở trên (xem chú thích đầu mục). */
  const MAT=[K*CX,-1,K*SX];
  const tru=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
  const cheo=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
  const cham=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
  const dinhKhoi=mau.d.map(k=>P[k]);
  const tam=[0,1,2].map(i=>dinhKhoi.reduce((s,p)=>s+p[i],0)/dinhKhoi.length);

  /* Mặt nào quay về phía người xem. Pháp tuyến tự lật ra ngoài bằng cách so với tâm khối,
     nên không phụ thuộc thứ tự liệt kê đỉnh — chỗ này nếu làm sai thì nét đứt sẽ đảo ngược hết. */
  const matHuong=mau.m.map(f=>{
    const q=f.map(k=>P[k]);
    let n=cheo(tru(q[1],q[0]),tru(q[2],q[0]));
    const tf=[0,1,2].map(i=>q.reduce((s,p)=>s+p[i],0)/q.length);
    if(cham(n,tru(tf,tam))<0)n=n.map(x=>-x);
    return cham(n,MAT)>0;
  });
  /* Cạnh khuất = cả hai mặt kề đều quay lưng. Đúng cho mọi khối lồi. */
  const canh=new Map();
  mau.m.forEach((f,i)=>{
    for(let j=0;j<f.length;j++){
      const a=f[j],b=f[(j+1)%f.length],id=[a,b].sort().join('|');
      if(!canh.has(id))canh.set(id,{a,b,hien:false});
      if(matHuong[i])canh.get(id).hien=true;
    }
  });
  /* b22 — VECTƠ VÀ ĐOẠN PHỤ CŨNG PHẢI THEO NÉT KHUẤT.
     VÌ SAO: thầy cô khoanh bút đỏ ba vectơ trên hình lập phương và ghi "vẽ nét đứt đoạn",
     kèm mũi tên chỉ sang cạnh khuất bên cạnh: "nó giống cái này". Đúng — vectơ $\vec{AD}$ nằm
     ĐÚNG TRÊN cạnh khuất AD mà lại vẽ nét liền, $\vec{AC}$ là đường chéo của mặt đáy đang quay
     lưng, $\vec{AD'}$ là đường chéo của mặt bên trái cũng quay lưng. Vẽ liền hết thì hình sai
     quy ước và học sinh đọc ra một khối khác hẳn.
     Quy tắc suy ra từ chính quy tắc cạnh khuất ở trên, nên hai thứ không thể lệch nhau: một
     đoạn nối hai điểm của khối bị che khi MỌI mặt chứa cả hai điểm đó đều quay lưng. Nếu không
     có mặt nào chứa cả hai (đường chéo xuyên lòng khối như AC′) thì đoạn nằm trong lòng khối và
     vẫn nhìn thấy — đúng như SGK vẫn vẽ AC′ nét liền. */
  const matChua={};
  mau.m.forEach((f,i)=>f.forEach(k=>{(matChua[k]=matChua[k]||new Set()).add(i)}));
  /* Điểm phụ nằm trên một cạnh thì thuộc đúng các mặt chứa cả hai đầu cạnh đó. */
  (Array.isArray(spec.points)?spec.points:[]).forEach(p=>{
    const t=solidKhoa(p.name||''),a=solidKhoa(p.between&&p.between[0]),b=solidKhoa(p.between&&p.between[1]);
    if(!P[t]||!matChua[a]||!matChua[b])return;
    matChua[t]=new Set([...matChua[a]].filter(i=>matChua[b].has(i)));
  });
  const doanKhuat=(u,v)=>{
    const A=matChua[u],B=matChua[v];
    if(!A||!B)return false;
    const chung=[...A].filter(i=>B.has(i));
    if(!chung.length)return false;              /* xuyên lòng khối — vẫn thấy */
    return chung.every(i=>!matHuong[i]);        /* mọi mặt chứa nó đều quay lưng */
  };

  /* Khung ảnh: lấy bao lồi của mọi điểm rồi chừa lề cho nhãn đỉnh và tiêu đề. */
  const moiDiem=Object.keys(P).map(k=>chieu(P[k]));
  const xs=moiDiem.map(p=>p[0]),ys=moiDiem.map(p=>p[1]);
  const LE=34,tieuDe=spec.title?30:0;
  const x0=Math.min(...xs)-LE,y0=Math.min(...ys)-LE-tieuDe;
  let W=Math.max(...xs)-Math.min(...xs)+LE*2,H=Math.max(...ys)-Math.min(...ys)+LE*2+tieuDe;
  /* VÌ SAO nới theo tiêu đề: khung ảnh vốn chỉ tính theo bao lồi của hình, nên một tiêu đề dài
     như "Hình chóp S.ABCD có đáy là hình bình hành" bị cắt cụt hai đầu — đã thấy ở lần dựng thử.
     Ước lượng 8,2 px một ký tự cho cỡ chữ 15 px in đậm, chỉ NỚI RỘNG chứ không bao giờ thu hẹp. */
  if(spec.title){
    const rongTieuDe=texToPlain(spec.title).length*9.4+30;
    if(rongTieuDe>W)W=rongTieuDe;
  }
  const lech=(W-(Math.max(...xs)-Math.min(...xs)+LE*2))/2;
  const toa=k=>{const p=chieu(P[k]);return [p[0]-x0+lech,p[1]-y0]};

  let g=`<svg xmlns="http://www.w3.org/2000/svg" width="${W.toFixed(1)}" height="${H.toFixed(1)}" `+
    `viewBox="0 0 ${W.toFixed(1)} ${H.toFixed(1)}">`+
    `<style>.hk{stroke:#123252;stroke-width:1.6;fill:none;stroke-linecap:round}`+
    `.hk-k{stroke:#123252;stroke-width:1.2;fill:none;stroke-dasharray:6 4;opacity:.75}`+
    `.hk-n{font:italic 16px/1 "Times New Roman",Georgia,serif;fill:#123252}`+
    `.hk-t{font:bold 15px/1 "Segoe UI",Arial,sans-serif;fill:#123252}`+
    `.hk-v{stroke:#c0392b;stroke-width:2.1;fill:none}`+
    `.hk-v-k{stroke:#c0392b;stroke-width:1.9;fill:none;stroke-dasharray:6 4}`+
    `.hk-vn{font:italic bold 15px/1 "Times New Roman",Georgia,serif;fill:#c0392b}`+
    `.hk-m{fill:#176fa8;fill-opacity:.13;stroke:none}</style>`+
    `<rect width="${W.toFixed(1)}" height="${H.toFixed(1)}" fill="#ffffff"/>`;
  if(spec.title)g+=`<text x="${(W/2).toFixed(1)}" y="20" text-anchor="middle" class="hk-t">${esc(texToPlain(spec.title))}</text>`;

  /* Mặt được tô nền để làm nổi mặt phẳng đang xét, vẽ TRƯỚC các cạnh để không che nét. */
  (Array.isArray(spec.planes)?spec.planes:[]).forEach(f=>{
    const q=(Array.isArray(f)?f:f.face||[]).map(solidKhoa).filter(k=>P[k]);
    if(q.length<3)return;
    g+=`<polygon class="hk-m" points="${q.map(k=>toa(k).map(n=>n.toFixed(1)).join(',')).join(' ')}"/>`;
  });
  /* Nét đứt vẽ trước nét liền, để chỗ giao nhau nét liền nằm trên như hình vẽ tay của SGK. */
  [...canh.values()].filter(c=>!c.hien).forEach(c=>{
    const a=toa(c.a),b=toa(c.b);
    g+=`<line x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${b[0].toFixed(1)}" y2="${b[1].toFixed(1)}" class="hk-k"/>`;
  });
  [...canh.values()].filter(c=>c.hien).forEach(c=>{
    const a=toa(c.a),b=toa(c.b);
    g+=`<line x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${b[0].toFixed(1)}" y2="${b[1].toFixed(1)}" class="hk"/>`;
  });
  /* Đoạn thẳng phụ do bài yêu cầu (đường chéo, trung tuyến...). */
  (Array.isArray(spec.segments)?spec.segments:[]).forEach(s=>{
    const a=solidKhoa(s.from),b=solidKhoa(s.to);
    if(!P[a]||!P[b])return;
    const p=toa(a),q=toa(b);
    /* dash khai báo tay vẫn được tôn trọng; không khai thì tự tính theo mặt khuất. */
    const dut=s.dash===undefined?doanKhuat(a,b):!!s.dash;
    g+=`<line x1="${p[0].toFixed(1)}" y1="${p[1].toFixed(1)}" x2="${q[0].toFixed(1)}" y2="${q[1].toFixed(1)}" class="${dut?'hk-k':'hk'}"/>`;
  });
  /* Vectơ: mũi tên màu đỏ như SGK, lùi 4 px mỗi đầu để không dính vào chữ tên đỉnh. */
  const vecto=(Array.isArray(spec.vectors)?spec.vectors:[]).filter(v=>P[solidKhoa(v.from)]&&P[solidKhoa(v.to)]);
  vecto.forEach((v,i)=>{
    const p=toa(solidKhoa(v.from)),q=toa(solidKhoa(v.to));
    const dx=q[0]-p[0],dy=q[1]-p[1],L=Math.hypot(dx,dy)||1,u=[dx/L,dy/L],lui=Math.min(9,L/3);
    const a=[p[0]+u[0]*lui,p[1]+u[1]*lui],b=[q[0]-u[0]*lui,q[1]-u[1]*lui];
    /* Thân vectơ đứt theo mặt khuất, nhưng ĐẦU MŨI TÊN luôn vẽ đặc — nếu để đứt cả đầu thì
       không còn đọc ra là vectơ nữa, đó là điều thầy cô cần thấy rõ nhất trên hình. */
    const dut=v.dash===undefined?doanKhuat(solidKhoa(v.from),solidKhoa(v.to)):!!v.dash;
    g+=`<line x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${b[0].toFixed(1)}" y2="${b[1].toFixed(1)}" class="${dut?'hk-v-k':'hk-v'}" marker-end="url(#mhk)"/>`;
    /* b24 — MẶC ĐỊNH KHÔNG GHI KÝ HIỆU VECTƠ LÊN HÌNH.
       VÌ SAO: thầy cô khoanh đỏ ba nhãn trên tứ diện và ghi "bỏ ký hiệu vectơ trên cạnh, nhìn
       nó rối quá — bỏ ở tất cả các hình vẽ". Đúng vậy: khi hai vectơ xuất phát từ cùng một đỉnh
       và chiếu gần trùng nhau (AD với AC trên tứ diện), hai nhãn chồng lên nhau thành một đám
       chữ đỏ không đọc được. Tên đỉnh đã có sẵn trên hình nên người đọc tự biết mũi tên nào là
       vectơ nào; ghi thêm chỉ làm rối.
       Vẫn bật lại được khi thật sự cần, bằng "vectorLabels": true cho cả hình hoặc "showLabel":
       true cho riêng một vectơ. */
    const hienNhan=v.showLabel===undefined?spec.vectorLabels===true:!!v.showLabel;
    if(hienNhan&&v.label){
    /* VÌ SAO tự vẽ dấu mũi tên: texToPlain không biết lệnh \vec nên nhãn "$\vec{a}$" in thẳng
       ra chữ "veca" — đã thấy tận mắt ở lần dựng thử đầu tiên. Ký tự tổ hợp Unicode (a⃗) thì
       phụ thuộc phông, in ra Word dễ lệch. Nên vẽ chữ rồi gạch một mũi tên ngắn ngay trên đầu:
       cách này không phụ thuộc phông nào cả. */
    const coVec=/\\(vec|overrightarrow)\b/.test(String(v.label||''));
    const nh=v.label?texToPlain(String(v.label).replace(/\\(vec|overrightarrow)\s*/g,'')):'';
    if(nh){
      const gx=(a[0]+b[0])/2-u[1]*13,gy=(a[1]+b[1])/2+u[0]*13;
      g+=`<text x="${gx.toFixed(1)}" y="${(gy+5).toFixed(1)}" text-anchor="middle" class="hk-vn">${esc(nh)}</text>`;
      if(coVec){
        const w=Math.max(7,nh.length*4.2);
        g+=`<line x1="${(gx-w).toFixed(1)}" y1="${(gy-12).toFixed(1)}" x2="${(gx+w).toFixed(1)}" y2="${(gy-12).toFixed(1)}" `+
           `stroke="#c0392b" stroke-width="1.3" marker-end="url(#mhk2)"/>`;
      }
    }
    }
  });
  if(vecto.length)g+=`<defs><marker id="mhk" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6.5" markerHeight="6.5" orient="auto-start-reverse"><path d="M0,1 L10,5 L0,9 z" fill="#c0392b"/></marker>`+
    `<marker id="mhk2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse"><path d="M0,1 L10,5 L0,9 z" fill="#c0392b"/></marker></defs>`;
  /* Nhãn đỉnh đẩy ra NGOÀI theo hướng từ tâm hình tới đỉnh, nếu không chữ sẽ nằm đè lên cạnh. */
  /* Nhãn đỉnh phải đẩy ra NGOÀI, nếu không chữ nằm đè lên cạnh — đã thấy nhãn B′ dính vào
     đúng góc hình ở lần dựng thử. Cách cộng vector các cạnh kề KHÔNG đủ: ở đỉnh có ba cạnh
     toả đều (B′ của hình hộp) tổng gần triệt tiêu và nhãn lại rơi vào giữa. Nay quét 24 hướng
     rồi chọn hướng nằm giữa KHE RỘNG NHẤT giữa các cạnh kề — đúng cách người ta ghi nhãn bằng
     tay. Hướng ra xa tâm hình được cộng thêm một chút điểm để phá thế hoà. */
  const tamAnh=[(Math.max(...xs)+Math.min(...xs))/2-x0+lech,(Math.max(...ys)+Math.min(...ys))/2-y0];
  const ke={};
  [...canh.values()].forEach(c=>{(ke[c.a]=ke[c.a]||[]).push(c.b);(ke[c.b]=ke[c.b]||[]).push(c.a)});
  (Array.isArray(spec.segments)?spec.segments:[]).forEach(s=>{
    const a=solidKhoa(s.from),b=solidKhoa(s.to);
    if(P[a]&&P[b]){(ke[a]=ke[a]||[]).push(b);(ke[b]=ke[b]||[]).push(a)}
  });
  (Array.isArray(spec.points)?spec.points:[]).forEach(p=>{
    const t=solidKhoa(p.name||'');if(!P[t])return;
    ke[t]=(ke[t]||[]).concat([solidKhoa(p.between&&p.between[0]),solidKhoa(p.between&&p.between[1])].filter(k=>P[k]));
  });
  const gocCanh=(k,p)=>(ke[k]||[]).map(q=>{const t=toa(q);return Math.atan2(t[1]-p[1],t[0]-p[0])});
  mau.d.concat(phu).forEach(k=>{
    const p=toa(k),gc=gocCanh(k,p);
    const raNgoai=Math.atan2(p[1]-tamAnh[1],p[0]-tamAnh[0]);
    let tot=raNgoai,diem=-Infinity;
    for(let i=0;i<24;i++){
      const th=-Math.PI+i*Math.PI/12;
      let d=Math.PI;
      gc.forEach(a=>{let x=Math.abs(th-a);if(x>Math.PI)x=2*Math.PI-x;if(x<d)d=x});
      let x=Math.abs(th-raNgoai);if(x>Math.PI)x=2*Math.PI-x;
      const s=d+(Math.PI-x)*0.18;          /* thưởng nhẹ cho hướng quay ra ngoài hình */
      if(s>diem){diem=s;tot=th}
    }
    g+=`<text x="${(p[0]+Math.cos(tot)*16).toFixed(1)}" y="${(p[1]+Math.sin(tot)*16+5).toFixed(1)}" text-anchor="middle" class="hk-n">${esc(nhan(k))}</text>`;
  });
  return g+'</svg>';
}

function buildVariationSVG(spec){
  const points=Array.isArray(spec.points)?spec.points:[];
  const N=points.length;
  if(N<2)return null;
  // Model đôi khi đếm lệch 1-2 phần tử trong "derivative"/"values" — tự đệm/cắt cho khớp thay vì
  // bỏ cuộc và báo lỗi ngay, để vẫn dựng được một sơ đồ có ích (có thể thiếu 1 dấu, còn hơn trắng trang).
  const deriv=coerceLen(spec.derivative,2*N-3,'');
  const values=coerceLen(spec.values,N,'');
  /* LỖI ĐÃ SỬA: bản cũ so sánh giá trị với đúng ký tự '+∞'. Nhưng mô hình trả về LaTeX
     "+\\infty", nên phép so sánh LUÔN trượt: vô cực không được ghim lên đỉnh/đáy khung mà bị
     tính như một mức bình thường, làm toàn bộ bảng lệch chiều — đúng hiện tượng trong ảnh. */
  const INF_POS=/^\+?\s*(\\infty|∞|infty|inf)$/i, INF_NEG=/^-\s*(\\infty|∞|infty|inf)$/i;
  const isPosInf=x=>INF_POS.test(String(x??'').trim());
  const isNegInf=x=>INF_NEG.test(String(x??'').trim());
  /* Hình học theo bảng biến thiên SGK: một cột nhãn x/y'/y, không đóng khung ngoài
     và không kẻ vạch dọc tại mọi điểm tới hạn. Chỉ điểm gián đoạn mới có hai vạch. */
  const W=760,leftLabel=62,rightPad=18,xStart=leftLabel+28,xEnd=W-rightPad-10,plotW=xEnd-xStart;
  const xAt=i=>xStart+(N===1?0:i*(plotW/(N-1)));
  const bandX=38,bandDeriv=44,bandVal=124,padTop=8,padBot=8;
  const yTop=padTop,derivTopY=yTop+bandX,valTopY=derivTopY+bandDeriv,valBotY=valTopY+bandVal,H=valBotY+padBot;
  const intervalSign=i=>deriv[2*i];
  let arriveLevel=[0],departLevel=[0];
  for(let i=0;i<N-1;i++){const s=intervalSign(i),d=s==='+'?1:s==='-'?-1:0,nextArrive=departLevel[i]+d;arriveLevel.push(nextArrive);const v=values[i+1];departLevel.push(v&&typeof v==='object'?(isPosInf(v.right)?nextArrive+3:isNegInf(v.right)?nextArrive-3:nextArrive):nextArrive)}
  const allLv=arriveLevel.concat(departLevel),minL=Math.min(...allLv),maxL=Math.max(...allLv),span=Math.max(1,maxL-minL);
  const yForLevel=lv=>valBotY-26-((lv-minL)/span)*(bandVal-52);
  const valLabel=i=>{const v=values[i];return (v&&typeof v==='object')?null:String(v)};
  const yArrive=i=>{const v=valLabel(i);if(isPosInf(v))return valTopY+16;if(isNegInf(v))return valBotY-16;return yForLevel(arriveLevel[i])};
  const yDepart=i=>{const v=valLabel(i);if(isPosInf(v))return valTopY+16;if(isNegInf(v))return valBotY-16;return yForLevel(departLevel[i])};
  const arrowId='vtArrow'+(++GRAPH_UID);
  let svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(spec.title||'Bảng biến thiên')}">`;
  svg+=`<defs><marker id="${arrowId}" markerWidth="7" markerHeight="7" refX="6.2" refY="3.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L7,3.5 L0,7 Z" class="vt-arrow"/></marker></defs>`;
  svg+=`<line x1="${leftLabel}" y1="${yTop}" x2="${leftLabel}" y2="${valBotY}" class="vt-frame"/>`;
  svg+=`<line x1="8" y1="${derivTopY}" x2="${W-rightPad}" y2="${derivTopY}" class="vt-frame"/>`;
  svg+=`<line x1="8" y1="${valTopY}" x2="${W-rightPad}" y2="${valTopY}" class="vt-frame"/>`;
  svg+=svgLabel(20,(yTop+derivTopY)/2,'$x$','middle',28,20);
  svg+=svgLabel(20,(derivTopY+valTopY)/2,`$y'$`,'middle',28,20);
  svg+=svgLabel(20,(valTopY+valBotY)/2,'$y$','middle',28,20);
  points.forEach((p,i)=>{svg+=svgLabel(xAt(i),(yTop+derivTopY)/2,wrapMathCell(p),'middle',110,20)});
  for(let i=0;i<N-1;i++){const s=intervalSign(i);if(s)svg+=svgLabel((xAt(i)+xAt(i+1))/2,(derivTopY+valTopY)/2,wrapMathCell(s),'middle',60,20)}
  for(let i=1;i<N-1;i++){const v=deriv[2*i-1];if(!/^\\?\|$/.test(String(v??'').trim())&&v!==undefined)svg+=svgLabel(xAt(i),(derivTopY+valTopY)/2,wrapMathCell(v),'middle',60,20)}
  for(let i=0;i<N-1;i++){const inset=14,x1=xAt(i)+inset,x2=xAt(i+1)-inset,y1=yDepart(i),y2=yArrive(i+1);
    svg+=`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="vt-path" marker-end="url(#${arrowId})"/>`}
  points.forEach((p,i)=>{const v=values[i],anchor=i===0?'start':(i===N-1?'end':'middle');if(v&&typeof v==='object'){const yL=isPosInf(v.left)?valTopY+16:isNegInf(v.left)?valBotY-16:yArrive(i),yR=isPosInf(v.right)?valTopY+16:isNegInf(v.right)?valBotY-16:yDepart(i),midY=(yL+yR)/2;svg+=svgLabel(xAt(i)-8,yL-14,wrapMathCell(v.left),'end',80,20);svg+=svgLabel(xAt(i)+8,yR-14,wrapMathCell(v.right),'start',80,20);/* Điểm gián đoạn: SGK vẽ hai vạch dọc song song chạy suốt hàng y (dấu ‖), không phải hai
   gạch xiên ngắn ở giữa như bản cũ — nhìn vào không ra ký hiệu gián đoạn. */
svg+=`<line x1="${xAt(i)-3}" y1="${derivTopY+2}" x2="${xAt(i)-3}" y2="${valBotY-2}" class="vt-discontinuity"/>`+
     `<line x1="${xAt(i)+3}" y1="${derivTopY+2}" x2="${xAt(i)+3}" y2="${valBotY-2}" class="vt-discontinuity"/>`}else{
    /* Nếu mô hình không tính ra giá trị cực trị, bản cũ để trống — người đọc tưởng bảng đã đủ.
       SGK dùng dấu "?" cho ô chưa điền, nên hiện "?" để giáo viên biết còn phải bổ sung. */
    const shown=String(v??'').trim()||'?';
    svg+=svgLabel(xAt(i)+(i===0?6:i===N-1?-6:0),yArrive(i)-14,wrapMathCell(shown),anchor,90,20)}});
  svg+='</svg>';
  return svg;
}

/* Tách riêng bộ vẽ đồ thị (trước đây nằm lọt trong renderMathViz) để docx-export.js dùng lại
   được khi xuất Word, thay vì phải chép lại toàn bộ mã vẽ. Nhân tiện sửa ba lỗi:
   1) id="plotClip" bị đặt cứng: hai đồ thị trở lên trong cùng một bài dùng chung một id,
      trình duyệt lấy id đầu tiên nên đồ thị sau bị cắt sai vùng.
   2) `+s.xMin||-5` trả về -5 khi xMin đúng bằng 0, vì 0 là giá trị falsy — mọi đồ thị khai
      báo xMin:0 hoặc yMin:0 đều bị vẽ sai miền. Dùng ?? và kiểm tra hữu hạn.
   3) Trục toạ độ không có số nào, giáo viên không đọc được giá trị. Nay có vạch chia.
   opt.standalone = true: nhúng kèm xmlns và CSS để SVG tự đứng một mình (dùng để đổi ra ảnh PNG). */
let GRAPH_UID=0;
const GRAPH_CSS='.plot-bg{fill:#fff;stroke:#b7c9d4}.grid-line{stroke:#dfe9ee;stroke-width:1}'
  +'.axis{stroke:#263d4c;stroke-width:1.7}.plot-path{fill:none;stroke-width:2.6;stroke-linecap:round;stroke-linejoin:round}'
  +'.asymptote{fill:none;stroke:#c4473a;stroke-width:1.8;stroke-dasharray:8 6}.asymptote-label{font:italic 12px Arial,sans-serif;fill:#a9342a}'
  +'.tick{font:11px Arial,sans-serif;fill:#40566b}';
/* Nắn một số về giá trị "đẹp" khi nó chỉ lệch vì sai số tính xấp xỉ: số nguyên trước, rồi
   tới các phân số mẫu nhỏ thường gặp trong SGK. Lệch nhiều thì giữ nguyên. */
function snapNice(x){
  if(!Number.isFinite(x))return x;
  if(Math.abs(x)<1e-4)return 0;
  for(const q of [1,2,3,4,5,6,8,10,12]){
    const r=Math.round(x*q)/q;
    if(Math.abs(x-r)<Math.max(1e-3,Math.abs(x)*1e-4))return r;
  }
  return Math.round(x*1e4)/1e4;
}
/* Dựng nhãn đường thẳng theo lối viết của SGK: bỏ hệ số 1, gộp dấu, bỏ hạng tử 0. */
function nhanDuongThang(a,b){
  const he=a===1?'x':a===-1?'-x':`${a}x.axis-name{font:italic 600 15px/1 'Times New Roman',Georgia,serif;fill:#123252}`;
  return b?`y=${he}${b>0?'+':'-'}${Math.abs(b)}`:`y=${he}`;
}
function inferAsymptotes(s){
  const explicit=Array.isArray(s.asymptotes)?s.asymptotes.filter(Boolean):[];
  if(explicit.length)return explicit;
  const expr=String(s.functions?.[0]?.expr||'').replace(/\s+/g,'');
  if(!expr.includes('/'))return [];
  const out=[];
  /* Tự nhận mẫu mẫu số bậc nhất (x-a) hoặc (x+a), phổ biến trong chương khảo sát. */
  const m=expr.match(/\/\(?x([+-])(\d+(?:\.\d+)?)\)?$/i);
  if(m)out.push({type:'vertical',value:m[1]==='-'?Number(m[2]):-Number(m[2])});
  /* Ước lượng phần đa thức khi |x| rất lớn. Với phân thức bậc tử không vượt quá
     bậc mẫu + 1, kết quả cho đúng tiệm cận ngang hoặc xiên; làm tròn nhiễu số. */
  try{const f=compileExpr(expr),M=1e5,a=(f(2*M)-f(M))/M,b=f(M)-a*M;
    if(Number.isFinite(a)&&Number.isFinite(b)){
      /* b17: bản in của giáo viên ghi nhãn "y=-1x+2.99998" và "y=1x+4.00024". Con số lẻ là
         nhiễu của phép tính xấp xỉ, còn "1x" thì không ai viết trong SGK. Nắn về số gọn khi
         đã rất sát một phân số đơn giản; phần chữ để hàm dựng nhãn lo. */
      const aa=snapNice(a),bb=snapNice(b);
      if(Math.abs(aa)<1e4&&Math.abs(bb)<1e7)out.push(aa===0?{type:'horizontal',value:bb}:{type:'oblique',slope:aa,intercept:bb});
    }}catch(_){}
  return out;
}
/* Nới miền tung độ khi dữ liệu AI khai báo khung quá hẹp. Dùng phân vị thay vì
   min/max tuyệt đối để các điểm sát tiệm cận đứng không ép toàn bộ đường cong
   thành một nét gần như nằm ngang. Miền do giáo viên/AI khai báo chỉ được nới,
   không bị thu lại. */
function fitGraphYRange(s,x0,x1,y0,y1){
  if(s.autoFit===false)return {y0,y1};
  const values=[];
  for(const fn of s.functions||[]){
    let f;try{f=compileExpr(fn.expr)}catch(_){continue}
    for(let i=0;i<=1000;i++){
      const y=f(x0+(x1-x0)*i/1000);
      if(Number.isFinite(y)&&Math.abs(y)<1e9)values.push(y);
    }
  }
  if(values.length<5)return {y0,y1};
  values.sort((a,b)=>a-b);
  const q=p=>values[Math.max(0,Math.min(values.length-1,Math.floor((values.length-1)*p)))];
  const lo=q(.02),hi=q(.98),oldSpan=y1-y0;
  let next0=Math.min(y0,lo),next1=Math.max(y1,hi);
  if(next0===y0&&next1===y1)return {y0,y1};
  const pad=Math.max((next1-next0)*.07,oldSpan*.04,0.25);
  if(lo<y0)next0-=pad;
  if(hi>y1)next1+=pad;
  return {y0:next0,y1:next1};
}
function buildGraphSVG(s,opt){
  opt=opt||{};
  const num=(v,d)=>{const n=Number(v);return Number.isFinite(n)?n:d};
  /* ===== Bộ dựng khung vẽ (viết lại lần cuối ở b19) =====

     b18 đã ép hai trục dùng chung MỘT hệ số quy đổi để ô lưới thành hình vuông. Đúng ý
     "1 ô = 1 đơn vị", nhưng lại sinh ra một tai nạn: hàm y = -2x³+3x²-5x đơn điệu, miền
     giá trị trải 500 đơn vị trong khi miền hoành độ chỉ 10 — hệ số chung bị miền tung độ
     ép xuống 0,86 px/đơn vị, vùng vẽ còn ĐÚNG 8,5 PIXEL BỀ NGANG. Đó là cái vạch dọc
     trong ảnh giáo viên chụp.

     Bài toán thật ra là: không thể vừa giữ 1 đơn vị y = 1 đơn vị x, vừa có hình cân đối,
     khi hệ số góc của hàm lên tới vài chục. SGK giải bằng cách nén trục tung lại và ghi
     rõ số trên trục.
     NAY làm đúng như vậy, theo hai chế độ:
     - Hai miền chênh nhau không quá 4 lần → MỘT bước chia dùng chung, tức 1 ô = 1 đơn vị
       (hoặc 2, 5...) trên CẢ HAI TRỤC. Đây là chế độ thường gặp: y=x², các hàm phân thức.
     - Chênh quá 4 lần → mỗi trục một bước chia riêng, nhưng Ô LƯỚI VẪN LÀ HÌNH VUÔNG và
       số trên trục nói rõ mỗi ô là bao nhiêu đơn vị. Hình luôn cân đối, không còn vạch dọc.
     Thêm hệ trục Oxy có mũi tên và nhãn O, x, y đúng như giáo viên vẽ tay lên bản in. */
  const W=760,p=44,PLOT_H_MAX=430,CELL_MIN=24;
  let x0=num(s.xMin,-5),x1=num(s.xMax,5),y0=num(s.yMin,-5),y1=num(s.yMax,5);
  if(x1<=x0){x0=-5;x1=5}
  if(y1<=y0){y0=-5;y1=5}
  ({y0,y1}=fitGraphYRange(s,x0,x1,y0,y1));
  /* Nới chiều hẹp hơn cho hình lấp đầy khung, tối đa 1,8 lần — chỉ MỞ RỘNG tầm nhìn chứ
     không bao giờ cắt bớt nội dung. Thiếu bước này thì đồ thị y=(x+1)/(x-2) chỉ chiếm 185
     trên 672 pixel bề ngang, đúng chỗ giáo viên ghi "đồ thị nên to ra ở trục hoành". */
  const TI_LE=PLOT_H_MAX/(W-2*p);
  {
    const rx0=x1-x0,ry0=y1-y0;
    if(ry0>rx0*TI_LE){
      const muon=Math.min(ry0/TI_LE,rx0*1.8),bu=(muon-rx0)/2;
      if(bu>0){x0-=bu;x1+=bu}
    }else if(ry0<rx0*TI_LE){
      const muon=Math.min(rx0*TI_LE,ry0*1.8),bu=(muon-ry0)/2;
      if(bu>0){y0-=bu;y1+=bu}
    }
  }
  const rx=x1-x0,ry=y1-y0;
  const step=r=>{const raw=r/12,pow=Math.pow(10,Math.floor(Math.log10(raw)||0));const m=raw/pow;return (m<1.5?1:m<3.5?2:m<7.5?5:10)*pow};
  const canDoi=Math.max(rx,ry)/Math.min(rx,ry)<=4;
  const sx=canDoi?step(Math.max(rx,ry)):step(rx);
  const sy=canDoi?sx:step(ry);
  let cell=Math.min((W-2*p)/(rx/sx),PLOT_H_MAX/(ry/sy));
  if(!Number.isFinite(cell)||cell<CELL_MIN)cell=CELL_MIN;
  const plotW=(rx/sx)*cell,plotH=(ry/sy)*cell;
  const kx=cell/sx,ky=cell/sy;
  const H=Math.round(plotH)+2*p,L=p+Math.max(0,((W-2*p)-plotW)/2),R=L+plotW,B=p+plotH;
  const X=x=>L+(x-x0)*kx,Y=y=>B-(y-y0)*ky;
  const uid='plotClip'+(++GRAPH_UID);
  let svg=`<svg ${opt.standalone?`xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" `:''}viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(s.title||'Đồ thị hàm số')}">`;
  if(opt.standalone)svg+=`<style>${GRAPH_CSS}</style><rect width="${W}" height="${H}" fill="#ffffff"/>`;
  svg+=`<defs><clipPath id="${uid}"><rect x="${L}" y="${p}" width="${plotW}" height="${plotH}"/></clipPath>`+
       `<marker id="ar${uid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">`+
       `<path d="M0,1 L10,5 L0,9 z" fill="#123252"/></marker></defs>`;
  svg+=`<rect x="${L}" y="${p}" width="${plotW}" height="${plotH}" class="plot-bg"/>`;
  for(let k=Math.ceil(x0/sx)*sx;k<=x1+1e-9;k+=sx)svg+=`<line x1="${X(k).toFixed(2)}" y1="${p}" x2="${X(k).toFixed(2)}" y2="${B}" class="grid-line"/>`;
  for(let k=Math.ceil(y0/sy)*sy;k<=y1+1e-9;k+=sy)svg+=`<line x1="${L}" y1="${Y(k).toFixed(2)}" x2="${R}" y2="${Y(k).toFixed(2)}" class="grid-line"/>`;
  /* Hệ trục Oxy: mũi tên ở đầu trục và nhãn O, x, y — giáo viên đã vẽ tay bổ sung đúng
     chỗ này trên bản in, nghĩa là thiếu nó thì hình chưa đọc được như một đồ thị. */
  const coOy=x0<=0&&x1>=0, coOx=y0<=0&&y1>=0;
  if(coOx)svg+=`<line x1="${L}" y1="${Y(0).toFixed(2)}" x2="${(R+14).toFixed(2)}" y2="${Y(0).toFixed(2)}" class="axis" marker-end="url(#ar${uid})"/>`+
    `<text x="${(R+20).toFixed(2)}" y="${(Y(0)+4).toFixed(2)}" class="axis-name">x</text>`;
  if(coOy)svg+=`<line x1="${X(0).toFixed(2)}" y1="${B}" x2="${X(0).toFixed(2)}" y2="${p-14}" class="axis" marker-end="url(#ar${uid})"/>`+
    `<text x="${(X(0)+7).toFixed(2)}" y="${p-16}" class="axis-name">y</text>`;
  if(coOx&&coOy)svg+=`<text x="${(X(0)-11).toFixed(2)}" y="${(Y(0)+15).toFixed(2)}" class="axis-name">O</text>`;
  const fmtTick=v=>Math.abs(v)<1e-9?'':(Math.round(v*1000)/1000).toString().replace('.',',');
  const baseY=coOx?Y(0):B, baseX=coOy?X(0):L;
  for(let k=Math.ceil(x0/sx)*sx;k<=x1+1e-9;k+=sx){if(Math.abs(k)<1e-9)continue;
    svg+=`<text x="${X(k).toFixed(2)}" y="${Math.min(H-6,baseY+15).toFixed(2)}" text-anchor="middle" class="tick">${fmtTick(k)}</text>`}
  for(let k=Math.ceil(y0/sy)*sy;k<=y1+1e-9;k+=sy){if(Math.abs(k)<1e-9)continue;
    svg+=`<text x="${Math.max(4,baseX-7).toFixed(2)}" y="${(Y(k)+4).toFixed(2)}" text-anchor="end" class="tick">${fmtTick(k)}</text>`}
  for(const a of inferAsymptotes(s)){
    if(a.type==='vertical'&&Number.isFinite(Number(a.value))&&a.value>=x0&&a.value<=x1){const xx=X(Number(a.value));
      svg+=`<line x1="${xx.toFixed(2)}" y1="${p}" x2="${xx.toFixed(2)}" y2="${B}" class="asymptote" clip-path="url(#${uid})"/>`+
           `<text x="${(xx+5).toFixed(2)}" y="${p+14}" class="asymptote-label">x=${esc(snapNice(Number(a.value)))}</text>`}
    else if(a.type==='horizontal'&&Number.isFinite(Number(a.value))&&a.value>=y0&&a.value<=y1){const yy=Y(Number(a.value));
      svg+=`<line x1="${L}" y1="${yy.toFixed(2)}" x2="${R}" y2="${yy.toFixed(2)}" class="asymptote" clip-path="url(#${uid})"/>`+
           `<text x="${R-5}" y="${(yy-6).toFixed(2)}" text-anchor="end" class="asymptote-label">y=${esc(snapNice(Number(a.value)))}</text>`}
    else if(a.type==='oblique'){const slope=Number(a.slope),intercept=Number(a.intercept);if(Number.isFinite(slope)&&Number.isFinite(intercept)){
      svg+=`<line x1="${X(x0).toFixed(2)}" y1="${Y(slope*x0+intercept).toFixed(2)}" x2="${X(x1).toFixed(2)}" y2="${Y(slope*x1+intercept).toFixed(2)}" class="asymptote" clip-path="url(#${uid})"/>`+
           `<text x="${X(x1).toFixed(2)}" y="${Math.max(p+14,Math.min(B-4,Y(slope*x1+intercept)-6)).toFixed(2)}" text-anchor="end" class="asymptote-label">${esc(nhanDuongThang(slope,intercept))}</text>`}}
  }
  let plotted=0;
  for(const fn of s.functions||[]){
    let f;try{f=compileExpr(fn.expr)}catch(_){continue}
    let d='',pen=false;
    for(let i=0;i<=900;i++){const x=x0+(x1-x0)*i/900,y=f(x),ok=Number.isFinite(y)&&y>=y0-ry&&y<=y1+ry;
      if(ok){d+=(pen?'L':'M')+X(x).toFixed(2)+' '+Y(y).toFixed(2);pen=true}else pen=false}
    if(d){plotted++;svg+=`<path d="${d}" stroke="${esc(fn.color||'#176fa8')}" class="plot-path" clip-path="url(#${uid})"/>`}}
  if(!plotted)svg+=`<text x="${W/2}" y="${H/2}" text-anchor="middle" class="tick">Không dựng được đường cong — kiểm tra biểu thức</text>`;
  return svg+'</svg>';
}
function renderMathViz(){document.querySelectorAll('.mathviz').forEach(el=>{try{const s=JSON.parse(decodeURIComponent(el.dataset.spec));
  /* b21 — hình khối không gian. Dùng ĐÚNG hàm mà bộ xuất Word dùng, không dựng bản riêng:
     b20 đã cho thấy hai đường vẽ song song thì sớm muộn cũng lệch nhau. */
  if(s.type==='solid'||s.type==='hinhkhong gian'||s.type==='hinh-khong-gian'){
    const svg=buildSolidSVG(s);
    if(!svg)throw new Error('solid schema không hợp lệ');
    /* b22 — KHÔNG in thêm dòng tiêu đề ở ngoài: chính ảnh đã vẽ tiêu đề bên trong, nên bản
       trước hiện tiêu đề HAI LẦN chồng nhau — thấy rõ trong ảnh chụp màn hình thầy cô gửi. */
    el.innerHTML=`<div class="mathviz-scroll">${svg}</div>`;
  }
  else if(s.type==='graph'){el.innerHTML=`<div class="mathviz-title">${esc(s.title||'Đồ thị')}</div>`+buildGraphSVG(s)+`<div class="mathviz-legend">${(s.functions||[]).map(f=>`<span style="--c:${esc(f.color||'#176fa8')}">$${esc(f.label||f.expr)}$</span>`).join('')}</div>`}
  else if(s.type==='variation'&&Array.isArray(s.points)){const svg=buildVariationSVG(s);if(!svg)throw new Error('variation schema không hợp lệ');/* b18 — TÁCH ĐỒ THỊ RA MỘT KHUNG RIÊNG.
     Giáo viên đề nghị: "đồ thị vẽ riêng, không nằm chung với bảng biến thiên, ý là cắt ra
     làm 2 khung để đồ thị không bị co lại". Trước đây cả bảng lẫn đồ thị nhét chung một
     ô, nên đồ thị luôn phải nhường chỗ. Nay đồ thị được đặt vào một khung .mathviz riêng
     ngay bên dưới, có tiêu đề riêng, chiếm trọn bề ngang. */
    const g=graphFromVariation(s);
    el.innerHTML=`<div class="mathviz-title">${esc(s.title||'Bảng biến thiên')}</div><div class="mathviz-scroll vt-scroll">${svg}</div>`;
    if(g){
      const khung=document.createElement('figure');
      khung.className='mathviz mathviz-graph';
      khung.innerHTML=`<div class="mathviz-title">${esc(g.title)}</div>${buildGraphSVG(g)}<div class="mathviz-legend"><span style="--c:#176fa8">$${esc(g.functions[0].label)}$</span></div>`;
      el.insertAdjacentElement('afterend',khung);
    }}else{const svg=buildSignSVG(s);if(!svg)throw new Error('sign schema không hợp lệ');el.innerHTML=`<div class="mathviz-title">${esc(s.title||(s.type==='sign'?'Bảng xét dấu':'Bảng biến thiên'))}</div><div class="mathviz-scroll vt-scroll">${svg}</div>`}}catch(e){el.innerHTML='<p class="mathviz-error">Không dựng được hình toán học này. Vui lòng tạo lại nội dung.</p>'}})}
function balancedFences(s){return (String(s).match(/```/g)||[]).length%2===0}
/* Vá dấu gạch chéo trong JSON do AI sinh ra.
   VÌ SAO PHẢI VIẾT LẠI: bản cũ dùng /\\(?!["\\/bfnrtu])/ — nghĩa là để nguyên dấu gạch
   chéo khi ký tự sau nó là b, f, n, r, t, u vì đó là ký tự thoát hợp lệ của JSON.
   Nhưng đó cũng chính là chữ cái đầu của các lệnh LaTeX hay dùng nhất:
   \frac \times \to \neq \beta \text \right \forall \bar \underline...
   Hậu quả: "\frac{1}{2}" bị JSON.parse đổi thành ký tự xuống trang + "rac{1}{2}",
   công thức mất sạch mà không có thông báo lỗi nào.
   Cách phân biệt: một ký tự thoát JSON thật chỉ có ĐÚNG MỘT chữ cái (\n rồi hết);
   còn lệnh LaTeX luôn có từ hai chữ cái trở lên (\to, \frac). */
function repairJsonEscapes(raw) {
  /* Phân biệt "\\n xuống dòng thật" với "lệnh LaTeX bắt đầu bằng n" bằng danh sách lệnh có
     thật, chứ không đoán theo ký tự liền sau. Bản trước giữ \\n chỉ khi KHÔNG có chữ cái theo
     sau — nhưng mô hình viết "...trang 10:\\na) Ta có" và "\\nb) Bảng biến thiên", tức là có
     chữ cái ngay sau, nên xuống dòng bị biến thành chữ "\\na)" hiện ra giữa ô sản phẩm. */
  const CMDS = (typeof LATEX_CMDS !== 'undefined' ? LATEX_CMDS : [])
    .concat(['frac','sqrt','text','times','to','ne','nabla','begin','end','tan','theta','tau','binom','rfloor','rceil']);
  const startsWithCmd = run => CMDS.some(c => run === c || (run.startsWith(c) && c.length >= 2));
  return String(raw).replace(/\\(u[0-9a-fA-F]{4}|[a-zA-Z]+|[\s\S])/g, (m, g) => {
    if (/^u[0-9a-fA-F]{4}$/.test(g)) return m;              // \uXXXX — mã Unicode hợp lệ
    if (g === '"' || g === '\\' || g === '/') return m;      // ký tự thoát JSON hợp lệ
    if (/^[a-zA-Z]/.test(g) && startsWithCmd(g)) return '\\' + m;  // là lệnh LaTeX → nhân đôi
    if (/^[bfnrt]/.test(g)) return m;                        // \n \t \r \b \f — xuống dòng/tab thật
    return '\\' + m;                                         // còn lại coi như LaTeX
  });
}


/* Quét cả khối có dấu ``` lẫn JSON trần. Bản cũ chỉ đọc khối có dấu ```, nên khi mô hình
   trả JSON trần (rất hay xảy ra) thì flow.js vẫn dựng được bảng trên màn hình nhưng bộ
   kiểm định lại báo "Không tìm thấy bảng lessonflow" và "Tổng thời lượng 0 phút" —
   hai phần của phần mềm nhìn thấy hai thứ khác nhau. */
function findFlowBlocks(text){
  const out=[]; text=String(text||'');
  text.replace(/```(?:lessonflow|json)?\s*([\s\S]*?)```/gi,(_,raw)=>{
    if(/['"]type['"]\s*:\s*['"]lessonflow['"]/i.test(raw))out.push({raw:raw.trim(),fenced:true});
    return _;});
  let pos=0,guard=0;
  while(guard++<500){
    const hit=text.slice(pos).search(/["']type["']\s*:\s*["']lessonflow["']/i);
    if(hit<0)break;
    const marker=pos+hit;
    let start=-1,depth=0;
    for(let i=marker;i>=0;i--){const c=text[i];if(c==='}')depth++;else if(c==='{'){if(!depth){start=i;break}depth--}}
    if(start<0){pos=marker+10;continue}
    let end=-1,d=0,inStr=false,q='',esc=false;
    for(let i=start;i<text.length;i++){const c=text[i];
      if(inStr){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===q)inStr=false;continue}
      if(c==='"'||c==="'"){inStr=true;q=c;continue}
      if(c==='{')d++;else if(c==='}'&&--d===0){end=i+1;break}}
    if(end<0){pos=marker+10;continue}
    const raw=text.slice(start,end);
    if(!out.some(x=>x.raw===raw.trim()))out.push({raw:raw.trim(),fenced:false});
    pos=Math.max(end,marker+10);
  }
  return out;
}
function parseLessonFlows(md){return findFlowBlocks(md).map(b=>{try{return JSON.parse(repairJsonEscapes(b.raw))}catch(e){return {__error:e.message}}})}
function allowedNLSTokens(grade){const b=nlsLevelForGrade(grade??$('grade').value);return new Set((buildNLSText([b]).match(new RegExp(`\\b\\d\\.\\d-B${b}[a-h]\\b`,'g'))||[]))}
function allowedAITokens(grade){return new Set(((AI_YCCD[String(grade)]||'').match(/\b(?:10|11|12)\.[A-D]\d\.(?:MR)?\d+\b/g)||[]))}
/* LỖI NẶNG ĐÃ SỬA — bỏ dấu tiếng Việt:
   normalize('NFD') tách được nguyên âm có dấu (ạ → a + dấu, ê → e + dấu) nhưng chữ "đ"
   (U+0111) KHÔNG có dạng phân rã nào, nên nó sống sót qua bước xoá dấu. Hệ quả:
   "Hoạt động 1" bị bỏ dấu thành "hoat đong 1", không bao giờ khớp /hoat dong 1/.
   Vì bốn phép kiểm tra Hoạt động 1–4 không được bọc trong điều kiện aiGenerated, MỌI bản
   kế hoạch đều nhận đủ 4 lỗi chặn "Thiếu Hoạt động N" và bị khoá xuất Word vĩnh viễn —
   kể cả bản soạn đúng hoàn toàn. Phải thay đ/Đ thành d TRƯỚC khi chuẩn hoá. */
function deaccent(t){return String(t||'').replace(/đ/g,'d').replace(/Đ/g,'D').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()}
/* ===== Các phép kiểm định thêm ở b17 =====
   Nguồn: một bản in thật do giáo viên rà bằng bút đỏ. Mọi lỗi dưới đây đều có thật trong
   bản đó, và đều là loại lỗi mà máy phát hiện được nhưng b16 đã bỏ lọt. */

/* Cắt các đoạn nằm giữa $...$ hoặc $$...$$ ra để soi riêng. */
function mathSegments(text){
  const out=[];
  String(text||'').replace(/\$\$([^$]+)\$\$|\$([^$\n]+)\$/g,(m,a,b)=>{out.push(a||b);return m});
  return out;
}

/* 1) Còn sót tên lệnh LaTeX viết trần.
   Bản in có "(- infty; 0)", "D = mathbbR", "sqrt[3]" — chữ lệnh in thẳng ra giữa công thức.
   b17 đã vá được các lệnh đã biết; phép kiểm này bắt các lệnh CHƯA có trong danh sách,
   để lần sau còn biết mà bổ sung thay vì lại in ra giấy rồi mới phát hiện. */
function bareLatexLeftovers(text){
  const xau=new Set();
  for(const seg of mathSegments(text)){
    const daVa=typeof repairLatex==='function'?repairLatex(seg):seg;
    /* Sau khi vá mà vẫn còn cụm chữ cái dài từ 3 trở lên đứng ngay trước "{" hoặc "["
       thì gần như chắc chắn là một lệnh LaTeX bị mất dấu gạch chéo. */
    (daVa.replace(/\\[a-zA-Z]+/g,' ').match(/\b[a-zA-Z]{3,}(?=\s*[{[])/g)||[])
      .forEach(t=>xau.add(t));
  }
  return [...xau];
}

/* 2) Ngoặc không cân đối trong công thức.
   Bản in có "(-\infty; \dfrac{3-\sqrt3}{3} và (\dfrac{3+\sqrt3}{3}; +\infty;" và
   "y\left(\pm\sqrt{\dfrac{3}{2}} = -\dfrac{5}{4}" — thiếu hẳn dấu đóng, đọc lên vô nghĩa. */
function unbalancedMath(text){
  const loi=[];
  for(const seg of mathSegments(text)){
    const s=seg.replace(/\\left|\\right/g,'').replace(/\\[{}]/g,'');
    /* b18 — SỬA MỘT LỖI DO CHÍNH b17 GÂY RA. b17 đếm riêng "(" với ")" và "[" với "]", nên
       MỌI NỬA KHOẢNG đều bị báo sai: $(0; 2]$, $[0; +\infty)$, $(-\infty; 1]$ là cách viết
       chuẩn của SGK chứ không phải lỗi. Trên màn hình giáo viên nó hiện thành "5 công thức
       có dấu ngoặc không cân đối" và khoá luôn nút xuất Word — một cái chặn oan.
       Nay ngoặc tròn và ngoặc vuông coi như CÙNG MỘT LOẠI: mở bằng cái nào, đóng bằng cái
       nào cũng được. Vẫn bắt đúng trường hợp thiếu dấu đóng và thừa dấu đóng. */
    let mo=0,nhon=0;
    for(const c of s){
      if(c==='('||c==='[')mo++;else if(c===')'||c===']')mo--;
      else if(c==='{')nhon++;else if(c==='}')nhon--;
      if(mo<0||nhon<0)break;
    }
    if(mo||nhon)loi.push(seg.trim().slice(0,60));
  }
  return loi;
}

/* 3) Mã SP/TC đánh lại từ đầu ở mỗi hoạt động.
   Bản in có SP1..SP9 ở Hoạt động 1, rồi SP1..SP8 khác hẳn ở Hoạt động 2, SP1..SP6 ở Hoạt
   động 3... Ma trận liên kết ở đầu bài trỏ tới "SP1" thì không còn biết là SP1 nào. */
/* b23 — CHỈ MÃ SẢN PHẨM (SP) MỚI BẮT BUỘC DUY NHẤT.
   VÌ SAO tách khỏi mã tiêu chí: bản trước gộp SP với TC vào cùng một phép đếm nên một bản kế
   hoạch bị chặn chỉ vì dùng lại "TC2" ở hai hoạt động. Nhưng dùng lại một TIÊU CHÍ đánh giá cho
   nhiều hoạt động là chuyện hoàn toàn bình thường trong nghề — chẳng hạn "TC2: quan sát thái độ
   hợp tác nhóm" thì hoạt động nào cũng có thể chấm bằng nó. Ngược lại, mỗi SẢN PHẨM là một kết
   quả học tập riêng, hai sản phẩm khác nhau mà mang cùng mã thì ma trận liên kết đầu bài không
   truy được về đâu — chỗ đó vẫn phải chặn. */
function trungMaSanPham(flows){
  const dem=new Map();
  flows.forEach((f,i)=>{
    if(!f||!Array.isArray(f.rows))return;
    const ma=new Set();
    f.rows.forEach(r=>(r.product||[])
      .forEach(x=>{const m=String(x).match(/^\s*(SP\d+)/);if(m)ma.add(m[1])}));
    ma.forEach(m=>dem.set(m,(dem.get(m)||new Set()).add(i)));
  });
  return [...dem.entries()].filter(([,v])=>v.size>1).map(([k])=>k);
}
/* Mã tiêu chí: chỉ nhắc khi CÙNG MỘT MÃ lại trỏ vào hai tiêu chí KHÁC NỘI DUNG — lúc đó ma trận
   mới thật sự mơ hồ. Dùng lại đúng một tiêu chí ở nhiều hoạt động thì im lặng, không làm phiền. */
function trungMaTieuChi(flows){
  const noiDung=new Map();
  const gon=s=>deaccent(String(s).replace(/^\s*TC\d+\s*[::.\-–]?\s*/,''))
    .toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  (flows||[]).forEach(f=>{
    if(!f||!Array.isArray(f.rows))return;
    f.rows.forEach(r=>(r.assessment||[]).forEach(x=>{
      const m=String(x).match(/^\s*(TC\d+)/);
      if(!m)return;
      const t=gon(x);
      if(!t)return;
      (noiDung.set(m[1],noiDung.get(m[1])||new Set()),noiDung.get(m[1])).add(t);
    }));
  });
  return [...noiDung.entries()].filter(([,v])=>v.size>1).map(([k])=>k);
}

/* b27.4 — kiểm thời lượng THEO TỪNG TIẾT.
   Bản thực tế Bài 8 ghi tổng 135 phút nhưng Tiết 1 đã dùng đủ 45 phút cho hai
   lessonflow rồi vẫn còn Khởi động chưa ghi thời lượng; Tiết 3 chỉ nhận diện được
   40 phút. Kiểm tổng cả bài không thể tìm ra hai lỗi này. */
function auditPeriodDurations(text,periods){
  const src=String(text||''),marks=[...src.matchAll(/^\s{0,3}#{0,6}\s*TIẾT\s*(\d+)\s*:/gim)];
  /* Chỉ kết luận theo tiết khi tài liệu nhiều tiết và đã chia đủ mốc. Bản một tiết
     hoặc bản cũ chưa chia đủ vẫn đi qua phép kiểm tổng quát để tránh báo oan. */
  if(Number(periods)<=1||new Set(marks.map(m=>Number(m[1]))).size!==Number(periods))return null;
  const rows=[];
  marks.forEach((m,i)=>{
    const section=src.slice(m.index,i+1<marks.length?marks[i+1].index:src.length);
    const flowMinutes=parseLessonFlows(section).reduce((sum,f)=>sum+(!f?.__error&&Array.isArray(f.rows)
      ?f.rows.reduce((s,r)=>s+(Number(r.duration)>0?Number(r.duration):0),0):0),0);
    /* Chỉ lấy thời lượng đặt trong ngoặc của hoạt động văn xuôi; duration trong JSON
       không có dạng này nên không bị cộng hai lần. */
    const proseMinutes=[...section.matchAll(/\((?:\s*Thời lượng\s*:\s*)?(\d+)\s*phút(?:[^)]*)\)/gi)]
      .reduce((sum,x)=>sum+Number(x[1]),0);
    const missing=[];
    const heads=[...section.matchAll(/^\s{0,3}#{1,6}\s*(?:\d+\.\s*)?(HOẠT ĐỘNG KHỞI ĐỘNG(?:\s*\(MỞ ĐẦU\))?|HOẠT ĐỘNG LUYỆN TẬP|HOẠT ĐỘNG VẬN DỤNG|TỔNG KẾT VÀ KIỂM TRA ĐẦU GIỜ)[^\n]*$/gim)];
    heads.forEach(h=>{
      const near=section.slice(h.index,Math.min(section.length,h.index+h[0].length+180));
      if(!/\((?:\s*Thời lượng\s*:\s*)?\d+\s*phút(?:[^)]*)\)/i.test(near))missing.push(h[1]);
    });
    rows.push({period:Number(m[1]),minutes:flowMinutes+proseMinutes,flowMinutes,proseMinutes,missing});
  });
  return {rows,minutes:rows.reduce((s,r)=>s+r.minutes,0),expected:Number(periods)*45};
}

function validatePlan(md,v,aiGenerated=true){const blockers=[],warnings=[],text=String(md||''),plain=deaccent(text);if(text.length<900)blockers.push('Nội dung quá ngắn, có khả năng phản hồi bị thiếu hoặc bị cắt.');if(!balancedFences(text))blockers.push('Khối mã chưa đóng đầy đủ; phản hồi AI có thể đã bị cắt.');[['I. Mục tiêu','i. muc tieu'],['II. Thiết bị dạy học và học liệu','ii. thiet bi day hoc va hoc lieu'],['III. Tiến trình dạy học','iii. tien trinh day hoc']].forEach(([label,key])=>{if(!plain.includes(key))blockers.push(`Thiếu mục ${label}.`)});/* Khung mới đặt tên hoạt động theo giáo án mẫu của tổ chuyên môn (Khởi động / Hình thành kiến
   thức mới / Luyện tập / Vận dụng) thay cho cách đánh số Hoạt động 1-4, nên phải kiểm theo tên. */
[['Hoạt động Khởi động (Mở đầu)',/khoi dong|mo dau/],['Hình thành kiến thức mới',/hinh thanh kien thuc/],
 ['Hoạt động Luyện tập',/luyen tap/],['Hoạt động Vận dụng',/van dung/]]
  .forEach(([ten,re])=>{if(!re.test(plain))blockers.push(`Thiếu ${ten}.`)});
if(aiGenerated&&!/huong dan ve nha/.test(plain))warnings.push('Thiếu mục "Hướng dẫn về nhà".');
/* Chia tiết: giáo án mẫu chia rõ TIẾT 1, TIẾT 2... Không chia thì giáo viên không biết dạy đến đâu
   thì hết tiết, phải tự cắt lại toàn bộ — đây là than phiền thực tế của giáo viên. */
if(aiGenerated&&Number(v.periods)>1){const tiet=new Set((text.match(/TIẾT\s*\d+/gi)||[]).map(x=>x.toUpperCase().replace(/\s+/g,' ')));
  if(!tiet.size)blockers.push(`Bài ${v.periods} tiết nhưng tiến trình chưa chia theo tiết (thiếu các dòng "TIẾT 1:", "TIẾT 2:"...).`);
  else if(tiet.size<Number(v.periods))warnings.push(`Mới chia ${tiet.size}/${v.periods} tiết trong tiến trình.`);}
/* Đủ bốn phần a) b) c) d) cho mỗi hoạt động. */
if(aiGenerated){const abcd=(text.match(/d\)\s*Tổ chức thực hiện/gi)||[]).length;
  if(abcd<4)blockers.push(`Mới có ${abcd} hoạt động ghi đủ "a) Mục tiêu – b) Nội dung – c) Sản phẩm – d) Tổ chức thực hiện" (cần ít nhất 4).`);}const mt=[...new Set(text.match(/\bMT\d+\b/g)||[])],sp=[...new Set(text.match(/\bSP\d+\b/g)||[])],tc=[...new Set(text.match(/\bTC\d+\b/g)||[])];if(aiGenerated&&!mt.length)blockers.push('Chưa đánh mã mục tiêu MT1, MT2...');if(aiGenerated&&!/ma tran lien ket muc tieu/.test(plain))blockers.push('Thiếu ma trận liên kết mục tiêu – hoạt động – sản phẩm – đánh giá.');mt.forEach(x=>{if((text.match(new RegExp(`\\b${x}\\b`,'g'))||[]).length<2)warnings.push(`${x} chưa được liên kết rõ với hoạt động/sản phẩm.`)});if(aiGenerated&&!sp.length)blockers.push('Chưa đánh mã sản phẩm SP1, SP2...');if(aiGenerated&&!tc.length)blockers.push('Chưa đánh mã tiêu chí TC1, TC2...');const flows=parseLessonFlows(text);if(aiGenerated&&!flows.length)blockers.push('Không tìm thấy bảng lessonflow của các hoạt động.');let totalMinutes=0,hasDuration=true;flows.forEach((f,i)=>{if(f.__error){blockers.push(`JSON lessonflow ${i+1} không hợp lệ.`);return}if(!Array.isArray(f.rows)||!f.rows.length){blockers.push(`Lessonflow ${i+1} không có bước nào.`);return}
/* Theo prompt, lessonflow chỉ dùng cho các hoạt động Hình thành kiến thức mới; Khởi động,
   Luyện tập và Vận dụng viết văn xuôi. Vì vậy không được coi lessonflow cuối là Hoạt động 4. */
if(f.rows.length!==4){blockers.push(`Lessonflow ${i+1} phải có đúng 4 bước.`);return}f.rows.forEach((r,j)=>{if(!r.step||!Array.isArray(r.product))blockers.push(`Lessonflow ${i+1}, bước ${j+1} thiếu tên bước hoặc sản phẩm.`);if(!Array.isArray(r.teacherActions)||!r.teacherActions.length)blockers.push(`Lessonflow ${i+1}, bước ${j+1} thiếu hoạt động của GV.`);if(!Array.isArray(r.studentActions)||!r.studentActions.length)blockers.push(`Lessonflow ${i+1}, bước ${j+1} thiếu hoạt động của HS.`);if(!Array.isArray(r.assessment)||!r.assessment.length)blockers.push(`Lessonflow ${i+1}, bước ${j+1} thiếu cách/tiêu chí đánh giá.`);
/* Cột "Sản phẩm dự kiến" là phần giáo viên thực sự cầm lên lớp dạy. Bản trước hay trả về nhãn rỗng
   kiểu "SP1: Kết luận về tính đơn điệu" — đọc lên không dạy được gì. Đếm độ dài để bắt lỗi này. */
const spText=(r.product||[]).map(x=>typeof x==='string'?x:'').join(' ');
if(spText&&spText.length<80)warnings.push(`Lessonflow ${i+1}, bước ${j+1}: sản phẩm dự kiến quá sơ sài (${spText.length} ký tự) — cần viết ra nội dung kiến thức hoặc lời giải, không chỉ ghi nhãn.`);if(!Array.isArray(r.goalIds)||!r.goalIds.length)warnings.push(`Lessonflow ${i+1}, bước ${j+1} chưa liên kết goalIds.`);const d=Number(r.duration);if(!Number.isFinite(d)||d<=0){hasDuration=false;blockers.push(`Lessonflow ${i+1}, bước ${j+1} thiếu thời lượng hợp lệ.`)}else totalMinutes+=d})});/* Thời lượng trong lessonflow chỉ là phần Hình thành kiến thức mới; ba hoạt động còn lại
   được viết văn xuôi nên không thể cộng tự động mà vẫn bảo đảm đúng. Chỉ chặn khi riêng
   phần đã cấu trúc đã vượt toàn bộ quỹ thời gian; nếu thấp hơn thì báo rõ đây là số phút
   đã nhận diện, tránh kết luận sai rằng cả KHBD thiếu thời lượng. */
const expected=Number(v.periods)*45;
const periodAudit=aiGenerated&&hasDuration&&expected?auditPeriodDurations(text,v.periods):null;
if(periodAudit){
  periodAudit.rows.forEach(r=>{
    if(r.missing.length)blockers.push(`Tiết ${r.period}: ${r.missing.join(', ')} chưa ghi “(Thời lượng: N phút)” nên chưa thể kiểm đủ 45 phút.`);
    else if(r.minutes!==45)blockers.push(`Tiết ${r.period} mới phân bổ ${r.minutes}/45 phút (lessonflow ${r.flowMinutes} phút, hoạt động văn xuôi ${r.proseMinutes} phút).`);
  });
  totalMinutes=periodAudit.minutes;
}else if(aiGenerated&&hasDuration&&expected){const tol=Math.max(5,Math.round(expected*0.1));
  if(totalMinutes>expected+tol)blockers.push(`Riêng các bước Hình thành kiến thức mới đã có ${totalMinutes} phút, vượt quỹ ${expected} phút (${v.periods} tiết).`);
  else warnings.push(`Đã nhận diện ${totalMinutes} phút ở các bảng Hình thành kiến thức mới; hãy đối chiếu thêm thời lượng Khởi động, Luyện tập và Vận dụng để đủ ${expected} phút.`);}const nlsUsed=[...new Set(text.match(/\b\d\.\d-B\d[a-h]\b/g)||[])],nlsAllowed=allowedNLSTokens(v.grade);nlsUsed.filter(x=>!nlsAllowed.has(x)).forEach(x=>blockers.push(`Mã NLS không được phép hoặc sai bậc: ${x}.`));const aiUsed=[...new Set(text.match(/\b(?:10|11|12)\.[A-D]\d\.(?:MR)?\d+\b/g)||[])],aiAllowed=allowedAITokens(v.grade);aiUsed.filter(x=>!aiAllowed.has(x)).forEach(x=>blockers.push(`Mã NLAI không thuộc lớp ${v.grade}: ${x}.`));aiUsed.filter(x=>/\.MR\d+$/.test(x)).forEach(x=>{const pos=text.indexOf(x),near=text.slice(pos,Math.min(text.length,pos+180)).toLowerCase();if(!/mở rộng|mo rong|không bắt buộc|khong bat buoc/.test(near))warnings.push(`Mã ${x} là nội dung mở rộng nhưng chưa ghi rõ “không bắt buộc”.`)});if(!$('includeDigital').checked&&nlsUsed.length)blockers.push('Đã tắt NLS nhưng đầu ra vẫn chứa mã NLS.');if(!$('includeAI').checked&&aiUsed.length)blockers.push('Đã tắt NLAI nhưng đầu ra vẫn chứa mã NLAI.');/* Với môn Toán, một kế hoạch bài dạy không có lấy một công thức nào thì chắc chắn là bản tóm tắt
   chứ không phải giáo án. Đây đúng là tình trạng của bản sinh ra trước khi sửa khung. */
if(aiGenerated&&isMathSubject(v)&&!/\$[^$]+\$/.test(text))blockers.push('Môn Toán nhưng cả bản kế hoạch không có công thức nào — nội dung mới ở mức đề cương, chưa dạy được.');
/* Giáo viên phản ánh: bản soạn "chỉ có công thức và lời nói, không có hình ảnh trực quan".
   Yêu cầu cần đạt của các bài này ghi rõ "nhận biết qua hình ảnh đồ thị", nên thiếu đồ thị là
   thiếu phương tiện dạy học chứ không phải thiếu trang trí. Chặn để buộc soạn lại. */
if(aiGenerated&&isMathSubject(v)&&/don dieu|cuc tri|khao sat|do thi|bien thien/.test(deaccent(v.lesson||''))){
  const coGraph=/["']type["']\s*:\s*["']graph["']/i.test(text),
        coExpr=/["']expr["']\s*:/i.test(text);
  if(!coGraph&&!coExpr)blockers.push('Bài về đồ thị/tính đơn điệu/cực trị nhưng không có đồ thị hàm số nào. Mỗi khối bảng biến thiên phải khai báo thêm "expr" để phần mềm vẽ đồ thị, hoặc thêm khối mathviz type "graph".');
}
/* b21 — HÌNH HỌC KHÔNG GIAN PHẢI CÓ HÌNH.
   VÌ SAO: bản in Bài 6 "Vectơ trong không gian" mà giáo viên gửi không có LẤY MỘT HÌNH NÀO —
   đã kiểm chứng bằng máy, cả tệp Word lẫn bản IN/PDF đều chứa 0 ảnh — trong khi nội dung liên
   tục nhắc "quan sát Hình 2.2", "cho hình lập phương ABCD.A'B'C'D'". Hoạt động dựa trên hình mà
   chỉ tả bằng lời thì không dạy được, đúng như thầy cô nói: "toán là phải có hình đính kèm".
   CHẶN OAN LÀ ĐIỀU PHẢI TRÁNH NHẤT (bài học b17), nên điều kiện được siết rất chặt: chỉ chặn khi
   bài THỰC SỰ nhắc tới một khối không gian cụ thể VÀ cả bản kế hoạch không có bất kỳ hình nào —
   kể cả đồ thị. Bài giải tích có nhắc "Hình 1.2" nhưng đã có đồ thị thì không bị đụng tới. */
if(aiGenerated&&isMathSubject(v)){
  const khoiKG=/\b(hinh lap phuong|hinh hop|tu dien|hinh chop|lang tru|hinh cau|hinh tru|hinh non)\b/.test(plain);
  const coSolid=/["']type["']\s*:\s*["'](?:solid|hinh-khong-gian)["']/i.test(text);
  const coHinhBatKy=coSolid||/["']type["']\s*:\s*["'](?:graph|variation)["']/i.test(text)||/["']expr["']\s*:/i.test(text);
  if(khoiKG&&!coHinhBatKy)
    blockers.push('Bài có hình khối không gian (hình hộp, tứ diện, hình chóp, lăng trụ...) nhưng cả bản kế hoạch không có một hình vẽ nào. Mỗi hoạt động dựa trên hình của sách giáo khoa phải kèm một khối mathviz type "solid".');
  else if(khoiKG&&!coSolid)
    warnings.push('Bài nhắc tới hình khối không gian nhưng chưa có khối mathviz type "solid" nào — hình khối đang được mô tả bằng lời, giáo viên sẽ phải tự vẽ lại.');
  /* Nhắc đích danh số hiệu hình của sách mà không có hình kèm: cảnh báo, không chặn — vì có
     những hình của sách (ảnh chụp thực tế, biển chỉ đường) mà phần mềm không dựng thay được. */
  const soHieuHinh=[...new Set(text.match(/\bHình\s+\d+\.\d+/g)||[])];
  if(soHieuHinh.length&&!coSolid&&!/["']type["']\s*:\s*["']graph["']/i.test(text))
    warnings.push(`Bản kế hoạch nhắc ${soHieuHinh.length} hình của sách giáo khoa (${soHieuHinh.slice(0,3).join(', ')}${soHieuHinh.length>3?'...':''}) nhưng không kèm hình vẽ nào — hãy bổ sung hình hoặc chiếu trực tiếp hình trong sách.`);
}
if(aiGenerated&&text.length<12000)warnings.push(`Bản kế hoạch chỉ dài ${text.length} ký tự — giáo án đủ nội dung dạy thường dài hơn nhiều; hãy kiểm tra xem phần kiến thức và lời giải đã được viết ra đầy đủ chưa.`);
if(v.assessmentMode==='day-du'&&!/bảng kiểm|bang kiem|rubric/.test(plain))blockers.push('Đã chọn đánh giá đầy đủ nhưng chưa có bảng kiểm hoặc rubric.');if(aiGenerated&&!/dieu chinh sau bai day/.test(plain))warnings.push('Thiếu mục “Điều chỉnh sau bài dạy” — Phụ lục IV Công văn 5512 có mục này để giáo viên ghi sau khi dạy thực tế.');if($('traceSources').checked&&!/dau vet nguon va trach nhiem giai trinh/.test(plain))blockers.push('Thiếu mục Dấu vết nguồn và trách nhiệm giải trình.');/* Than phiền có thật: bật "khóa nguồn tuyệt đối" mà bản soạn vẫn ghi số trang sai. Nếu không đính
   kèm tài liệu nào thì mọi số trang đều là bịa, phải cảnh báo ngay. */
if(!selectedFiles.length&&/\btr\.?\s*\d+|trang\s+\d+/i.test(text))blockers.push('Bản kế hoạch có trích dẫn số trang sách nhưng không có tài liệu nguồn nào được đính kèm — các số trang này không kiểm chứng được.');
if(selectedFiles.length&&!/theo nguồn|theo nguon/.test(plain))warnings.push('Có tài liệu đính kèm nhưng chưa thấy nội dung được gắn nhãn “Theo nguồn”.');
if(/trich dan chinh xac nguyen van|doi chieu tuyet doi|kiem chung tung trang/.test(plain))
  blockers.push('Mục dấu vết nguồn đang khẳng định đã trích dẫn/đối chiếu tuyệt đối nhưng phần mềm chưa có bằng chứng so sánh đoạn-với-đoạn. Hãy đổi thành mô tả phạm vi nguồn và yêu cầu giáo viên đối chiếu trước khi sử dụng.');
/* ===== b17: các lỗi lấy từ bản in giáo viên rà bút đỏ ===== */
if(aiGenerated){
  const sot=bareLatexLeftovers(text);
  if(sot.length)warnings.push(`Có thể còn lệnh LaTeX viết trần trong công thức (${sot.slice(0,4).join(', ')}) — hãy xem lại các chỗ này trên màn hình trước khi in.`);
  const lech=unbalancedMath(text);
  if(lech.length)blockers.push(`${lech.length} công thức có dấu ngoặc không cân đối, in ra sẽ sai hoặc mất vế: “${lech[0]}...”.`);
  /* b19: bản in mới nhất có ma trận liên kết ghi "MT6, MT7, MT8, MT9" trong khi mục Mục tiêu
     chỉ khai tới MT6 — ba mã trỏ vào chỗ trống. Máy đối chiếu được việc này. */
  {
    const khai=new Set((text.match(/\bMT\d+\b/g)||[]).filter(m=>
      new RegExp('[•\\-*]\\s*(?:\\*\\*)?'+m+'\\b\\s*[::]').test(text)));
    const dung=new Set(text.match(/\bMT\d+\b/g)||[]);
    const thieu=[...dung].filter(m=>khai.size&&!khai.has(m));
    if(thieu.length)blockers.push(`Mã ${thieu.slice(0,5).join(', ')} được dùng trong bài nhưng không được định nghĩa ở mục I. Mục tiêu — người đọc không biết mục tiêu đó là gì.`);
  }
  const trung=trungMaSanPham(flows);
  if(trung.length)blockers.push(`Mã sản phẩm ${trung.slice(0,5).join(', ')} được dùng lại ở nhiều hoạt động khác nhau — ma trận liên kết đầu bài sẽ không truy được về đúng sản phẩm. Hãy đánh mã SP liên tục cho cả bài.`);
  /* b23: mã tiêu chí dùng lại chỉ CẢNH BÁO, và chỉ khi nội dung hai chỗ khác nhau. */
  const trungTC=trungMaTieuChi(flows);
  if(trungTC.length)warnings.push(`Mã tiêu chí ${trungTC.slice(0,5).join(', ')} được dùng cho hai tiêu chí có nội dung khác nhau — hãy xem lại để ma trận đánh giá trỏ đúng chỗ. (Dùng lại cùng một tiêu chí ở nhiều hoạt động thì không sao.)`);
  /* Cột NLS/NLAI của bản in bị điền toàn năng lực đặc thù môn Toán ("Giao tiếp toán học",
     "Tư duy và lập luận toán học") — đúng chỗ này phải là mã NLS/NLAI hoặc dấu "—". */
  const saiCot=[];
  flows.forEach((f,i)=>{if(!f||!Array.isArray(f.rows))return;f.rows.forEach(r=>{
    (Array.isArray(r.competency)?r.competency:[r.competency]).forEach(c=>{
      const t=String(c??'').trim();
      if(!t||t==='—'||t==='-')return;
      if(!/\b\d\.\d-B\d[a-h]\b|\b(?:10|11|12)\.[A-D]\d\.(?:MR)?\d+\b/.test(t))saiCot.push(`bảng ${i+1}: “${t.slice(0,40)}”`);
    })})});
  if(saiCot.length)blockers.push(`Cột NLS/NLAI phải ghi mã năng lực số hoặc mã năng lực AI, hoặc để dấu “—”. Đang ghi nhầm năng lực đặc thù môn học ở ${saiCot.length} ô (${saiCot[0]}).`);
  /* Mã NLS nêu ở mục Mục tiêu nhưng không hoạt động nào dùng tới thì chỉ là trang trí. */
  if($('includeDigital').checked&&nlsUsed.length){
    const trongFlow=new Set();
    flows.forEach(f=>{if(!f||!Array.isArray(f.rows))return;f.rows.forEach(r=>
      (Array.isArray(r.competency)?r.competency:[r.competency]).forEach(c=>
        (String(c??'').match(/\b\d\.\d-B\d[a-h]\b/g)||[]).forEach(m=>trongFlow.add(m))))});
    const khongDung=nlsUsed.filter(m=>!trongFlow.has(m));
    if(khongDung.length)warnings.push(`Mã NLS ${khongDung.join(', ')} có nêu ở mục Mục tiêu nhưng không hoạt động nào gắn vào — cần chỉ rõ học sinh thực hiện hành vi số đó ở bước nào.`);
  }
  /* Bản in bị giáo viên ghi "thiếu năng lực AI": bật NLAI mà đầu ra không có mục nào. */
  /* b18 — BỎ LỐI THOÁT "KHÔNG TÍCH HỢP".
     b17 cho phép ghi "Năng lực AI (NLAI): không tích hợp trong bài này" là hợp lệ. Giáo
     viên khoanh đúng dòng đó và ghi "lỗi" — theo quy định thì bài nào cũng phải có nội
     dung năng lực AI, không được bỏ trống bằng một câu từ chối. Nay bắt buộc phải có mã
     NLAI thật, và chặn thẳng câu từ chối. */
  if(aiIntegrationMode()==='required'&&clampGrade(v.grade)>=10){
    if(!/nang luc ai|nlai/.test(plain))
      blockers.push('Đã bật tích hợp NLAI nhưng cả bản kế hoạch không có mục Năng lực AI.');
    else if(/khong tich hop|khong ap dung|khong co noi dung ai/.test(plain))
      blockers.push('Đã chọn chế độ bắt buộc tích hợp NLAI nhưng kế hoạch lại không tích hợp. Hãy thêm ít nhất một hoạt động sử dụng, kiểm chứng hoặc phản biện AI và gắn mã phù hợp.');
    else if(!aiUsed.length)
      blockers.push('Mục Năng lực AI có tiêu đề nhưng không nêu mã NLAI nào theo Quyết định 2422. Hãy ghi mã dạng 12.A1.3 kèm hành vi quan sát được.');
  }else if(aiIntegrationMode()==='auto'&&clampGrade(v.grade)>=10&&!aiUsed.length&&!/khong de xuat tich hop nlai|khong tich hop/.test(plain)){
    warnings.push('Chế độ NLAI là “Đề xuất khi phù hợp” nhưng kế hoạch chưa có mã NLAI và cũng chưa nêu lý do không tích hợp.');
  }
}
/* b25 — CHẨN ĐOÁN NGUYÊN NHÂN GỐC THAY VÌ LIỆT KÊ TRIỆU CHỨNG.
   VÌ SAO: ảnh chụp bài "Tích phân" cho thấy 8 dòng lỗi cùng lúc, mà dòng đầu — "khối mã chưa
   đóng đầy đủ, phản hồi AI có thể đã bị cắt" — chính là nguyên nhân của gần hết những dòng còn
   lại. Dựng lại một phản hồi cắt ngang giữa khối mã rồi đo: 8 dòng chặn, 7 dòng là hệ quả.
   Giáo viên đọc danh sách đó không biết phải sửa gì, trong khi việc cần làm chỉ là bấm Soạn lại.
   Nay khi phát hiện phản hồi bị cắt, phần mềm nói đúng MỘT câu về nguyên nhân và cách xử lý;
   các lỗi hệ quả chuyển xuống mục nên xem lại để không mất thông tin, chứ không xoá đi. */
{
  const khoiChuaDong=!balancedFences(text);
  /* Dấu hiệu thứ hai: văn bản dừng giữa chừng — không kết thúc bằng dấu câu hay dấu đóng khối. */
  const duoiBai=text.trimEnd().slice(-1);
  const dungGiuaChung=text.length>900&&!/[.。!?:;)»”"'`\]}*_|-]/.test(duoiBai);
  const thieuCuoiBai=aiGenerated&&!/dieu chinh sau bai day/.test(plain)&&!/huong dan ve nha/.test(plain);
  if(khoiChuaDong||(dungGiuaChung&&thieuCuoiBai)){
    const heQua=blockers.filter(b=>!/bị cắt/.test(b));
    blockers.length=0;
    blockers.push('Phản hồi của AI bị cắt giữa chừng nên bản kế hoạch chưa hoàn chỉnh — đây là nguyên nhân của hầu hết các lỗi bên dưới, không phải nhiều lỗi riêng lẻ. Hãy bấm Soạn lại. Nếu lặp lại nhiều lần, hãy giảm số tiết mỗi lần soạn hoặc chọn phong cách "Gọn, dễ triển khai" để phản hồi ngắn hơn.');
    /* Giữ lại các dấu hiệu đã đo được, nhưng xếp xuống mục nên xem lại và nói rõ chúng là hệ quả. */
    heQua.slice(0,6).forEach(b=>warnings.push('(hệ quả của việc bị cắt) '+b));
  }
}
return {blockers:[...new Set(blockers)],warnings:[...new Set(warnings)],passed:!blockers.length,codes:[...nlsUsed,...aiUsed],totalMinutes,expectedMinutes:expected}}
function syncExportLock(){const approval=$('approveCompetencies'),blocked=!!lastValidation?.blockers?.length,needsApproval=!!lastValidation?.codes?.length;$('wordBtn').disabled=blocked||(needsApproval&&!approval?.checked);$('wordBtn').title=blocked?'Hãy tạo lại hoặc sửa các lỗi kiểm định trước khi xuất Word':needsApproval&&!approval?.checked?'Giáo viên cần duyệt mã NLS/NLAI trước khi xuất Word':''}
function renderValidation(report){lastValidation=report;const el=$('validationReport');el.hidden=false;el.className=`validation-report ${report.blockers.length?'block':report.warnings.length?'warn':'ok'}`;const title=report.blockers.length?'KHÔNG ĐẠT KIỂM ĐỊNH – đã khóa xuất Word':report.warnings.length?'ĐẠT CÓ ĐIỀU KIỆN – giáo viên cần rà soát':'ĐẠT KIỂM ĐỊNH CHUYÊN MÔN TỰ ĐỘNG';const time=report.expectedMinutes?`<p><b>Thời lượng:</b> ${report.totalMinutes}/${report.expectedMinutes} phút.</p>`:'';
  /* b25 — TÁCH HAI NHÓM. VÌ SAO: bản trước nối thẳng blockers với warnings thành một danh sách
     phẳng, nên trong ảnh chụp bài "Tích phân" những dòng chỉ là CẢNH BÁO (mã tiêu chí dùng lại,
     mã NLS chưa gắn hoạt động) nằm lẫn dưới tiêu đề "đã khóa xuất Word". Giáo viên tưởng phải
     sửa hết mới xuất được, trong khi cảnh báo không hề khoá gì. Nay ghi rõ nhóm nào là nhóm nào. */
  const nhom=(ten,ds)=>ds.length?`<p class="vr-nhom">${esc(ten)}</p><ul>${ds.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'';
  const than=(report.blockers.length||report.warnings.length)
    ? nhom(report.blockers.length?'Phải sửa — đang khóa xuất Word:':'',report.blockers)
      +nhom(report.blockers.length?'Nên xem lại — không khóa xuất Word:':'Nên xem lại — vẫn xuất Word được:',report.warnings)
    : '<span>Đủ cấu trúc, liên kết mục tiêu, thời lượng, đánh giá và mã tham chiếu.</span>';
  const approval=report.codes.length?`<label class="check competency-approval"><input id="approveCompetencies" type="checkbox"> Tôi đã đọc, đối chiếu và duyệt các mã NLS/NLAI: ${report.codes.map(esc).join(', ')}</label>`:'';el.innerHTML=`<strong>${esc(title)}</strong>${time}${than}${approval}`;$('approveCompetencies')?.addEventListener('change',syncExportLock);syncExportLock()}
function showResult(md,report){rawMarkdown=md;$('progress').hidden=true;$('emptyState').hidden=true;$('result').innerHTML=mdToHtml(md);renderMathViz();$('result').hidden=false;$('resultActions').hidden=false;$('draftNotice').hidden=false;renderValidation(report||validatePlan(md,values(),false));const typeset=()=>window.MathJax?.typesetPromise?window.MathJax.typesetPromise([$('result')]).catch(()=>{}):null;typeset()||setTimeout(typeset,800);$('validationReport').scrollIntoView({behavior:'smooth',block:'start'});saveDraft()}
$('lessonForm').onsubmit=async e=>{e.preventDefault();const v=values(),key=$('apiKey').value.trim();if(selectedFiles.length&&!$('privacyConfirm').checked){toast('Vui lòng xác nhận tài liệu đã được ẩn danh và có quyền sử dụng');$('privacyConfirm').focus();return}$('generateBtn').disabled=true;try{setProgress(10,'Đang kiểm tra nguồn...','Chuẩn bị dữ liệu bài dạy');let md;if(key){md=await callGemini(v,key);if(!md)throw new Error('AI chưa trả về nội dung')}else{await new Promise(r=>setTimeout(r,350));setProgress(70,'Đang tạo khung dự thảo...','Dùng chế độ cơ bản không cần API key');md=fallback(v)}setProgress(94,'Đang kiểm định đầu ra...','Đối chiếu cấu trúc, lessonflow và mã NLS/NLAI');const report=validatePlan(md,v,!!key);showResult(md,report);toast(report.blockers.length?'Bản dự thảo chưa đạt kiểm định':report.warnings.length?'Đã tạo – cần rà soát cảnh báo':'Đã tạo và đạt kiểm định tự động')}catch(err){$('progress').hidden=true;$('emptyState').hidden=false;toast(err.message||'Có lỗi xảy ra')}finally{$('generateBtn').disabled=false}}
$('lessonForm').addEventListener('submit',e=>{if($('sourceMode').value==='strict'&&!selectedFiles.length&&!$('notes').value.trim()){e.preventDefault();e.stopImmediatePropagation();toast('Chế độ khóa nguồn tuyệt đối yêu cầu ít nhất một tài liệu hoặc nội dung nguồn');$('dropZone').focus()}},true);
$('copyBtn').onclick=async()=>{await navigator.clipboard.writeText(rawMarkdown);toast('Đã sao chép nội dung')};
$('printBtn').onclick=()=>window.print();
/* ĐÃ GỠ: trình xuất .doc cũ (HTML đội lốt Word). Nó dựng tệp từ innerHTML sau khi MathJax
   đã vẽ, nên mọi công thức chỉ còn <svg> và biến mất khi mở bằng Word. Việc xuất nay do
   docx-export.js đảm nhiệm: dựng .docx thật từ markdown gốc, công thức chuyển sang OMML.
   Giữ lại đoạn này chỉ gây nhầm lẫn khi bảo trì vì nó bị ghi đè ngay lúc nạp trang. */


/* ===== Tự động lưu nháp (localStorage) =====
   Lưu dữ liệu form + kết quả vừa soạn để giáo viên không mất công nếu lỡ tay refresh/đóng tab.
   KHÔNG lưu apiKey — giữ đúng cam kết "khóa chỉ tồn tại trong phiên trình duyệt" đã ghi trong giao diện.
   Không lưu tệp đính kèm (File object không phù hợp để lưu localStorage và có thể rất nặng). */
const DRAFT_KEY='khbd_draft_v1';
function saveDraft(){try{const draft={values:values(),includeDigital:$('includeDigital').checked,includeAI:$('includeAI').checked,aiIntegrationMode:aiIntegrationMode(),traceSources:$('traceSources').checked,style:$('style').value,resultMd:rawMarkdown||null,ts:Date.now()};localStorage.setItem(DRAFT_KEY,JSON.stringify(draft))}catch(_){/* localStorage đầy hoặc bị chặn (chế độ ẩn danh) — bỏ qua, không ảnh hưởng chức năng chính */}}
function loadDraft(){try{const raw=localStorage.getItem(DRAFT_KEY);return raw?JSON.parse(raw):null}catch(_){return null}}
function clearDraft(){try{localStorage.removeItem(DRAFT_KEY)}catch(_){}}
function scheduleDraftSave(){clearTimeout(draftTimer);draftTimer=setTimeout(saveDraft,500)}
$('lessonForm').addEventListener('input',scheduleDraftSave);
$('lessonForm').addEventListener('change',scheduleDraftSave);
function initDraft(){const d=loadDraft();if(!d)return;try{Object.entries(d.values||{}).forEach(([k,v])=>{if(v&&fields.includes(k)&&$(k))$(k).value=v});if(typeof d.includeDigital==='boolean')$('includeDigital').checked=d.includeDigital;if(typeof d.includeAI==='boolean')$('includeAI').checked=d.includeAI;if(typeof d.traceSources==='boolean')$('traceSources').checked=d.traceSources;if(d.style)$('style').value=d.style;$('grade').dispatchEvent(new Event('change'));if(d.resultMd)showResult(d.resultMd);$('clearDraftBtn').hidden=false;toast('Đã khôi phục bản nháp gần nhất (chưa gồm tệp đính kèm)')}catch(_){}}
$('clearDraftBtn').onclick=()=>{clearDraft();location.reload()};
initDraft();
